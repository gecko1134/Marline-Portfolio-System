import { useState, useCallback, useMemo, useEffect } from "react";

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// MARLINE INTELLIGENCE PLATFORM v3 â€” INVESTOR STYLE ARCHITECTURE
//
// NEW: Investor Style Engine (Layer 0)
//   - 12 investment philosophies with full parameter sets
//   - Dynamically adjusts composite weights, signal thresholds,
//     FSM parameters, rebalance bands, and AI personality
//   - Style selection propagates through all layers in real-time
//
// Layer 1: YCharts Data Engine (the Bloomberg Terminal)
// Layer 2: Anthropic AI + Web Search (the Analyst Team)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

const API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-20250514";
const MAX_TOOL_ROUNDS = 12;

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// LAYER 0: INVESTOR STYLE ENGINE
//
// Each style defines:
//   weights    â†’ Composite score factor weights (must sum to 100)
//   thresholds â†’ Signal generation breakpoints
//   fsm        â†’ Market model sensitivity
//   rebalance  â†’ Drift tolerance
//   risk       â†’ Position sizing and hedging behavior
//   aiPersona  â†’ Injected into AI system prompt
//   emphasis   â†’ Which data the AI should weight most
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

const INVESTOR_STYLES = {
  balanced: {
    id: "balanced",
    name: "Balanced",
    icon: "â—Ž",
    color: "#00D4AA",
    short: "Default multi-factor approach",
    description: "Equal emphasis across trend, technical, fundamental, and relative strength signals. The Marline default â€” suitable for most advisory clients seeking systematic, diversified portfolio management.",
    persona: "Portfolio Manager",
    weights: { trend: 30, tech: 25, fund: 25, dwa: 20 },
    thresholds: { strongBuy: 75, buy: 60, sell: 35, strongSell: 20 },
    fsm: { fullyInvested: 0.70, caution: 0.50, defensive: 0.30 },
    rebalanceBand: 5,
    cashMax: 15,
    hedgeMultiplier: 1.0,
    aiPersona: "You are a balanced, systematic portfolio manager. Weight all signal systems equally. Recommend diversified, risk-adjusted positions. Avoid extreme calls unless multiple systems strongly agree.",
    emphasis: "Multi-factor agreement, risk-adjusted returns, diversification",
    category: "core"
  },
  technical: {
    id: "technical",
    name: "Technical",
    icon: "âŸ",
    color: "#2E8BFF",
    short: "Chart-driven momentum and pattern analysis",
    description: "Prioritizes Bollinger Bands, Elliott Wave, Gann angles, and momentum signals. Best for advisors who time entries/exits using price action and follow systematic trading rules.",
    persona: "Technical Analyst",
    weights: { trend: 20, tech: 40, fund: 10, dwa: 30 },
    thresholds: { strongBuy: 70, buy: 55, sell: 40, strongSell: 25 },
    fsm: { fullyInvested: 0.65, caution: 0.45, defensive: 0.30 },
    rebalanceBand: 3,
    cashMax: 20,
    hedgeMultiplier: 1.2,
    aiPersona: "You are a technical analyst. Prioritize chart patterns, momentum signals, Bollinger Band readings, Elliott Wave phases, and Gann angles. Your recommendations should be timing-focused with specific entry/exit levels. Discuss price action, support/resistance, and pattern formations. Use web search to find recent technical breakouts or breakdowns.",
    emphasis: "Bollinger %B, Elliott Wave phase, Gann angle, RSI, momentum alignment, breakout/breakdown patterns",
    category: "active"
  },
  contrarian: {
    id: "contrarian",
    name: "Contrarian",
    icon: "âŸ²",
    color: "#E040FB",
    short: "Buy fear, sell greed â€” mean reversion",
    description: "Inverts conventional signals: oversold readings become buy signals, overbought becomes sell. Emphasizes buying during market stress (\"straw hats in winter\") and reducing during euphoria. Uses VIX spikes and sentiment extremes as entry points.",
    persona: "Contrarian Strategist",
    weights: { trend: 15, tech: 30, fund: 35, dwa: 20 },
    thresholds: { strongBuy: 25, buy: 35, sell: 70, strongSell: 85 },
    fsm: { fullyInvested: 0.30, caution: 0.45, defensive: 0.65 },
    rebalanceBand: 8,
    cashMax: 30,
    hedgeMultiplier: 0.5,
    invertSignals: true,
    aiPersona: "You are a contrarian strategist who buys when others are fearful and sells when others are greedy. Look for oversold conditions, elevated VIX, negative sentiment extremes, and capitulation signals as BUYING opportunities. Overbought conditions, low VIX, and extreme bullishness are SELLING signals. Your philosophy: 'buy straw hats in winter.' Use web search to gauge current sentiment and fear levels. Question consensus thinking.",
    emphasis: "VIX levels, sentiment extremes, mean reversion setups, oversold/overbought readings, capitulation signals",
    category: "active"
  },
  longTerm: {
    id: "longTerm",
    name: "Long-Term Growth",
    icon: "âŸ¶",
    color: "#00E676",
    short: "Buy quality, hold through cycles",
    description: "Patient, multi-year approach focused on secular growth trends and quality fundamentals. Ignores short-term noise. Wide rebalance bands, minimal trading, emphasis on compounding and dividend reinvestment.",
    persona: "Long-Term Investor",
    weights: { trend: 35, tech: 10, fund: 40, dwa: 15 },
    thresholds: { strongBuy: 80, buy: 65, sell: 25, strongSell: 15 },
    fsm: { fullyInvested: 0.75, caution: 0.55, defensive: 0.25 },
    rebalanceBand: 10,
    cashMax: 10,
    hedgeMultiplier: 0.6,
    aiPersona: "You are a long-term growth investor with a 5-10 year horizon. Focus on secular trends, quality fundamentals, and compounding. Ignore short-term volatility and technical noise. Recommend patience during corrections. Emphasize dividend growth, earnings quality, and competitive moats. Use web search for long-term secular trends and demographic shifts, not daily noise.",
    emphasis: "Multi-year trend, fundamental quality, earnings growth, dividend yield, forward P/E, secular trends",
    category: "core"
  },
  momentum: {
    id: "momentum",
    name: "Momentum",
    icon: "âŸ¿",
    color: "#FFB300",
    short: "Ride winners, cut losers fast",
    description: "Follows the trend aggressively. Overweights recent outperformers, cuts underperformers quickly. High turnover, tight stops. DWA relative strength and momentum signals are dominant factors.",
    persona: "Momentum Trader",
    weights: { trend: 35, tech: 25, fund: 5, dwa: 35 },
    thresholds: { strongBuy: 72, buy: 58, sell: 38, strongSell: 22 },
    fsm: { fullyInvested: 0.68, caution: 0.48, defensive: 0.28 },
    rebalanceBand: 3,
    cashMax: 20,
    hedgeMultiplier: 1.3,
    aiPersona: "You are a momentum trader. Ride winners hard and cut losers quickly. Focus on relative strength, trend acceleration, and momentum persistence. The strongest signal is price itself â€” if it's going up, stay long. If momentum breaks, exit immediately. Recommend the holdings with the strongest recent performance and flag any momentum divergences or breakdowns. Use web search for sector rotation trends and money flow data.",
    emphasis: "1M/3M/6M returns, DWA relative strength, trend acceleration, momentum persistence, sector rotation",
    category: "active"
  },
  value: {
    id: "value",
    name: "Value / Fundamental",
    icon: "â—ˆ",
    color: "#00BCD4",
    short: "Buy cheap, sell dear â€” fundamentals first",
    description: "Focuses on valuation metrics: forward P/E, dividend yield, and risk-adjusted efficiency. Seeks undervalued holdings with strong fundamentals. Patient, low-turnover approach with emphasis on margin of safety.",
    persona: "Value Analyst",
    weights: { trend: 15, tech: 10, fund: 50, dwa: 25 },
    thresholds: { strongBuy: 78, buy: 62, sell: 32, strongSell: 18 },
    fsm: { fullyInvested: 0.72, caution: 0.52, defensive: 0.28 },
    rebalanceBand: 7,
    cashMax: 20,
    hedgeMultiplier: 0.8,
    aiPersona: "You are a value-oriented fundamental analyst. Prioritize forward P/E, dividend yield, Sharpe ratio, and risk-adjusted return metrics. Look for holdings trading below intrinsic value with strong quality metrics. Avoid overvalued holdings regardless of momentum. Use web search for earnings estimates, valuation comparisons, and fundamental quality assessments. Recommend based on margin of safety and long-term value.",
    emphasis: "Forward P/E, dividend yield, Sharpe ratio, fundamental score, valuation gaps, quality metrics",
    category: "core"
  },
  income: {
    id: "income",
    name: "Income / Dividend",
    icon: "â—‰",
    color: "#66BB6A",
    short: "Maximize yield with capital preservation",
    description: "Prioritizes current income generation through dividends, bond coupons, and option premiums. Emphasizes capital preservation over growth. Suitable for distribution-phase clients seeking sustainable withdrawal rates.",
    persona: "Income Strategist",
    weights: { trend: 20, tech: 10, fund: 45, dwa: 25 },
    thresholds: { strongBuy: 72, buy: 58, sell: 38, strongSell: 22 },
    fsm: { fullyInvested: 0.70, caution: 0.55, defensive: 0.35 },
    rebalanceBand: 6,
    cashMax: 15,
    hedgeMultiplier: 1.1,
    aiPersona: "You are an income-focused strategist. Prioritize dividend yield, distribution sustainability, and capital preservation. Recommend holdings with reliable income streams. Favor bonds (AGG, TLT), REITs (VNQ), high-dividend equities, and covered call strategies. Flag any dividend cuts or yield traps. Use web search for current yield comparisons and dividend safety ratings. Assess withdrawal sustainability.",
    emphasis: "Dividend yield, income reliability, distribution coverage, capital preservation, bond allocation, yield curve",
    category: "core"
  },
  thematic: {
    id: "thematic",
    name: "Thematic / Macro",
    icon: "â—†",
    color: "#9366FF",
    short: "Position for big-picture macro themes",
    description: "Invests based on macroeconomic themes: AI revolution, deglobalization, energy transition, demographic shifts, inflation regime changes. Sector rotation based on economic cycle positioning.",
    persona: "Macro Strategist",
    weights: { trend: 30, tech: 15, fund: 25, dwa: 30 },
    thresholds: { strongBuy: 73, buy: 58, sell: 37, strongSell: 22 },
    fsm: { fullyInvested: 0.68, caution: 0.48, defensive: 0.28 },
    rebalanceBand: 6,
    cashMax: 20,
    hedgeMultiplier: 1.0,
    aiPersona: "You are a macro/thematic strategist. Analyze holdings through the lens of major macro themes: AI/technology disruption, monetary policy regime, geopolitical realignment, energy transition, demographic shifts, and deglobalization. Use web search extensively for current macro developments, central bank commentary, geopolitical events, and thematic trend analysis. Recommend sector rotations based on where we are in the economic cycle and which themes are accelerating.",
    emphasis: "Economic cycle position, sector rotation, macro themes, Fed policy, geopolitical risk, structural trends",
    category: "active"
  },
  riskParity: {
    id: "riskParity",
    name: "Risk Parity",
    icon: "âŠ•",
    color: "#FF7043",
    short: "Equal risk contribution across assets",
    description: "Targets equal volatility contribution from each asset class. Low-volatility assets get higher weight, high-volatility assets get reduced weight. Emphasizes portfolio-level risk management over individual returns.",
    persona: "Risk Parity Manager",
    weights: { trend: 25, tech: 20, fund: 30, dwa: 25 },
    thresholds: { strongBuy: 76, buy: 62, sell: 33, strongSell: 18 },
    fsm: { fullyInvested: 0.72, caution: 0.52, defensive: 0.32 },
    rebalanceBand: 4,
    cashMax: 12,
    hedgeMultiplier: 1.5,
    aiPersona: "You are a risk parity portfolio manager. Focus on volatility contribution, correlation dynamics, and risk budgeting across asset classes. Holdings should be evaluated by their risk contribution, not just return. Recommend reducing positions with outsized volatility and increasing diversifiers. Pay special attention to managed futures (DBMF, CTA, KMLM), hedges (BTAL, TAIL), and bonds as volatility ballast. Use web search for current correlation regimes and volatility forecasts.",
    emphasis: "Volatility, beta, correlation, risk contribution, diversification benefit, managed futures allocation",
    category: "systematic"
  },
  tactical: {
    id: "tactical",
    name: "Tactical / Adaptive",
    icon: "âŸ¡",
    color: "#FF3D57",
    short: "Shift aggressively with regime changes",
    description: "Rapidly adjusts allocation based on market regime detection. Fully invested in low-volatility uptrends, aggressively defensive during stress. Uses all signal systems with hair-trigger sensitivity for regime transitions.",
    persona: "Tactical Allocator",
    weights: { trend: 30, tech: 30, fund: 15, dwa: 25 },
    thresholds: { strongBuy: 68, buy: 52, sell: 42, strongSell: 28 },
    fsm: { fullyInvested: 0.65, caution: 0.45, defensive: 0.30 },
    rebalanceBand: 2,
    cashMax: 35,
    hedgeMultiplier: 1.8,
    aiPersona: "You are an aggressive tactical allocator. React quickly to regime changes. When signals shift, recommend immediate action â€” don't wait for confirmation. Use tight rebalance bands and be willing to raise cash aggressively. In bull regimes, be fully invested. In bear regimes, move to maximum defense immediately. Speed of execution matters. Use web search for real-time regime indicators: VIX term structure, credit spreads, breadth indicators, and money flow.",
    emphasis: "Regime detection speed, VIX level, cash trigger status, signal transitions, breadth changes",
    category: "active"
  },
  esg: {
    id: "esg",
    name: "ESG / Sustainable",
    icon: "â‹",
    color: "#4CAF50",
    short: "Sustainability-integrated analysis",
    description: "Integrates environmental, social, and governance factors into investment analysis. Screens for ESG risks, favors companies with strong sustainability profiles. Long-term orientation aligned with transition economy themes.",
    persona: "ESG Analyst",
    weights: { trend: 25, tech: 15, fund: 40, dwa: 20 },
    thresholds: { strongBuy: 74, buy: 60, sell: 34, strongSell: 20 },
    fsm: { fullyInvested: 0.70, caution: 0.50, defensive: 0.30 },
    rebalanceBand: 6,
    cashMax: 15,
    hedgeMultiplier: 0.9,
    aiPersona: "You are an ESG-integrated analyst. Evaluate all holdings for environmental, social, and governance risks alongside financial metrics. Use web search to check recent ESG controversies, carbon exposure, governance issues, and sustainability ratings for portfolio holdings. Flag holdings with significant ESG risks (especially XLE energy exposure). Recommend tilting toward companies with strong sustainability profiles and transition economy positioning.",
    emphasis: "ESG risk factors, governance quality, carbon exposure, sustainability ratings, transition economy alignment",
    category: "systematic"
  },
  quantitative: {
    id: "quantitative",
    name: "Quantitative",
    icon: "âŸ",
    color: "#AB47BC",
    short: "Pure systematic, rules-based execution",
    description: "Strictly rules-based with no subjective overrides. Every decision follows the composite scoring model output. No narrative, no gut feel â€” the model score IS the recommendation. Ideal for eliminating behavioral bias.",
    persona: "Quant Strategist",
    weights: { trend: 25, tech: 25, fund: 25, dwa: 25 },
    thresholds: { strongBuy: 75, buy: 60, sell: 35, strongSell: 20 },
    fsm: { fullyInvested: 0.70, caution: 0.50, defensive: 0.30 },
    rebalanceBand: 5,
    cashMax: 15,
    hedgeMultiplier: 1.0,
    aiPersona: "You are a quantitative strategist. Base ALL recommendations strictly on the composite scores, signal outputs, and systematic model readings. Do NOT let qualitative narratives override model signals. If the model says BUY, recommend BUY regardless of the news narrative. If the model says SELL, recommend SELL regardless of bullish stories. Use web search only for data verification, not opinion. Present recommendations as model outputs with confidence intervals, not subjective calls.",
    emphasis: "Composite scores, signal agreement, systematic model output, statistical confidence, factor exposures",
    category: "systematic"
  }
};

const STYLE_CATEGORIES = {
  core: { label: "Core Strategies", description: "Foundational approaches for most clients" },
  active: { label: "Active Strategies", description: "Higher conviction, more frequent trading" },
  systematic: { label: "Systematic Strategies", description: "Rules-based, quantitative approaches" }
};

// Apply style to composite scoring
function getStyleWeights(styleId) {
  const s = INVESTOR_STYLES[styleId] || INVESTOR_STYLES.balanced;
  return {
    trend: s.weights.trend / 100,
    tech: s.weights.tech / 100,
    fund: s.weights.fund / 100,
    dwa: s.weights.dwa / 100
  };
}

function getStyleThresholds(styleId) {
  const s = INVESTOR_STYLES[styleId] || INVESTOR_STYLES.balanced;
  return s.thresholds;
}

function getStyleFSM(styleId) {
  const s = INVESTOR_STYLES[styleId] || INVESTOR_STYLES.balanced;
  return s.fsm;
}


// â€” Portfolio Universe (mirrors Excel workbook) â€”
const HOLDINGS = [
  { ticker: "SPY",  name: "S&P 500 ETF",       class: "US Eq",  type: "ETF",   target: 8  },
  { ticker: "QQQ",  name: "Nasdaq 100 ETF",     class: "US Eq",  type: "ETF",   target: 7  },
  { ticker: "IWM",  name: "Russell 2000 ETF",   class: "US Eq",  type: "ETF",   target: 4  },
  { ticker: "EFA",  name: "MSCI EAFE",          class: "Intl",   type: "ETF",   target: 5  },
  { ticker: "EEM",  name: "MSCI Emerging Mkts", class: "Intl",   type: "ETF",   target: 3  },
  { ticker: "AGG",  name: "US Agg Bond",        class: "Bond",   type: "ETF",   target: 10 },
  { ticker: "TLT",  name: "20+ Yr Treasury",    class: "Bond",   type: "ETF",   target: 5  },
  { ticker: "GLD",  name: "Gold Trust",         class: "Alt",    type: "ETF",   target: 8  },
  { ticker: "VNQ",  name: "US REITs",           class: "REIT",   type: "ETF",   target: 5  },
  { ticker: "XLK",  name: "Technology Select",  class: "US Eq",  type: "ETF",   target: 8  },
  { ticker: "XLV",  name: "Healthcare Select",  class: "US Eq",  type: "ETF",   target: 4  },
  { ticker: "XLE",  name: "Energy Select",      class: "US Eq",  type: "ETF",   target: 3  },
  { ticker: "XLF",  name: "Financial Select",   class: "US Eq",  type: "ETF",   target: 4  },
  { ticker: "DBMF", name: "iMGP DBi Mgd Fut",  class: "MF",     type: "ETF",   target: 6  },
  { ticker: "CTA",  name: "Simplify Mgd Fut",   class: "MF",     type: "ETF",   target: 4  },
  { ticker: "KMLM", name: "KFA Mgd Fut",        class: "MF",     type: "ETF",   target: 4  },
  { ticker: "BTAL", name: "Anti-Beta L/S",      class: "Hedge",  type: "ETF",   target: 3  },
  { ticker: "TAIL", name: "Cambria Tail Risk",  class: "Hedge",  type: "ETF",   target: 2  },
  { ticker: "AAPL", name: "Apple Inc",          class: "US Eq",  type: "Stock", target: 2  },
  { ticker: "MSFT", name: "Microsoft Corp",     class: "US Eq",  type: "Stock", target: 2  },
  { ticker: "NVDA", name: "NVIDIA Corp",        class: "US Eq",  type: "Stock", target: 1  },
  { ticker: "JPM",  name: "JPMorgan Chase",     class: "US Eq",  type: "Stock", target: 2  },
];

const MARKET_INDICATORS = [
  { ticker: "^VIX",  name: "VIX",             metric: "price" },
  { ticker: "^TNX",  name: "10Y Treasury",    metric: "price", divisor: 1 },
  { ticker: "^IRX",  name: "2Y Treasury",     metric: "price", divisor: 1 },
  { ticker: "UUP",   name: "US Dollar Index", metric: "price" },
  { ticker: "HYG",   name: "High Yield Bond", metric: "price" },
];

const YCHART_METRICS = [
  "price", "one_year_return", "three_year_annualized_return",
  "five_year_annualized_return", "one_year_volatility",
  "max_drawdown_3_year", "beta_5_year", "dividend_yield",
  "forward_pe_ratio", "one_month_return", "three_month_return",
  "six_month_return",
];

// ═══════════════════════════════════════════════════════════════════════
// PORTFOLIO COMPARISON ENGINE — Upload, score, compare up to 10 portfolios
// ═══════════════════════════════════════════════════════════════════════

const BENCHMARK_PRESETS = [
  { id: "spy", name: "S&P 500", ticker: "SPY" },
  { id: "agg", name: "US Agg Bond", ticker: "AGG" },
  { id: "6040", name: "60/40 Blend", ticker: "60/40", synthetic: true },
  { id: "qqq", name: "Nasdaq 100", ticker: "QQQ" },
  { id: "iwm", name: "Russell 2000", ticker: "IWM" },
  { id: "efa", name: "MSCI EAFE", ticker: "EFA" },
];

const PORTFOLIO_COLORS = ["#00D4AA","#2E8BFF","#9366FF","#E040FB","#FF7043","#00BCD4","#84CC16","#6366F1","#14B8A6","#FFB300"];

const BELIEF_DIMENSIONS = {
  riskTolerance: { label: "Risk Tolerance", options: [
    { id: "conservative", label: "Conservative" }, { id: "moderate", label: "Moderate" }, { id: "aggressive", label: "Aggressive" }
  ]},
  incomeNeed: { label: "Income Need", options: [
    { id: "none", label: "No Income Need" }, { id: "moderate", label: "Some Income" }, { id: "primary", label: "Primary Goal" }
  ]},
  timeHorizon: { label: "Time Horizon", options: [
    { id: "short", label: "1-3 Years" }, { id: "medium", label: "3-10 Years" }, { id: "long", label: "10+ Years" }
  ]},
  styleTilt: { label: "Style Tilt", options: [
    { id: "value", label: "Value / Defensive" }, { id: "blend", label: "Core / Blend" }, { id: "growth", label: "Growth / Momentum" }
  ]},
  convictionThemes: { label: "Conviction Themes", multi: true, options: [
    { id: "inflation", label: "Inflation Protection" }, { id: "techAI", label: "Tech / AI" },
    { id: "dividends", label: "Dividend Growth" }, { id: "alternatives", label: "Alternatives" },
    { id: "international", label: "International" }, { id: "smallCap", label: "Small Cap" },
  ]}
};

const MGMT_DIMENSIONS = {
  fsmSignal: { label: "FSM Signal", options: [
    { id: "invested", label: "Fully Invested" }, { id: "caution", label: "Caution" }, { id: "defensive", label: "Defensive" }
  ]},
  regimeView: { label: "Regime View", options: [
    { id: "bullish", label: "Bullish" }, { id: "neutral", label: "Neutral" }, { id: "bearish", label: "Bearish" }
  ]},
  dwaStrength: { label: "DWA Strength", options: [
    { id: "strong", label: "Broad Strength" }, { id: "mixed", label: "Mixed" }, { id: "weak", label: "Broad Weakness" }
  ]},
  volatilityRegime: { label: "Vol Regime", options: [
    { id: "low", label: "Low VIX (<15)" }, { id: "moderate", label: "Moderate (15-25)" }, { id: "elevated", label: "Elevated (25+)" }
  ]},
  cashTrigger: { label: "Cash Trigger", options: [
    { id: "off", label: "All Clear" }, { id: "watch", label: "Watch" }, { id: "triggered", label: "Triggered" }
  ]}
};

function parsePortfolioInput(text) {
  if (!text || !text.trim()) return [];
  const lines = text.trim().split("\n").map(l => l.trim()).filter(Boolean);
  const delim = lines[0].includes("\t") ? "\t" : ",";
  const rows = lines.map(l => l.split(delim).map(c => c.trim().replace(/['"]/g, "")));
  const first = rows[0].map(c => c.toLowerCase());
  const hasHeader = first.some(c => ["ticker","symbol","weight","allocation","shares","value","name"].includes(c));
  const dataRows = hasHeader ? rows.slice(1) : rows;
  const headers = hasHeader ? first : null;
  const tickerIdx = headers ? Math.max(headers.indexOf("ticker"), headers.indexOf("symbol"), 0) : 0;
  const findCol = (names) => headers ? Math.max(...names.map(n => headers.findIndex(h => h.includes(n)))) : -1;
  const weightIdx = headers ? Math.max(findCol(["weight","allocation","target wt","target","current wt","current %"]), headers.indexOf("%")) : 1;
  const valueIdx = headers ? Math.max(findCol(["value","amount","market value"])) : -1;
  const hasWeightCol = weightIdx >= 0;
  const holdings = [];
  for (const row of dataRows) {
    if (row.length < 2) continue;
    const ticker = (row[tickerIdx] || "").toUpperCase().replace(/[^A-Z0-9.^]/g, "");
    if (!ticker || ticker === "TOTALS" || ticker === "AVERAGES" || ticker === "SIGNAL") continue;
    let weight = 0;
    if (!headers) {
      weight = parseFloat((row[1] || "0").replace(/[%$,]/g, ""));
    } else if (hasWeightCol) {
      weight = parseFloat((row[weightIdx] || "0").replace(/[%$,]/g, ""));
    }
    if (isNaN(weight)) weight = 0;
    const value = valueIdx >= 0 ? parseFloat((row[valueIdx] || "0").replace(/[%$,]/g, "")) || 0 : 0;
    holdings.push({ ticker, weight, value });
  }
  const totalWeight = holdings.reduce((s, h) => s + h.weight, 0);
  const totalValue = holdings.reduce((s, h) => s + h.value, 0);
  if (totalWeight < 2 && totalValue > 0) {
    holdings.forEach(h => { h.weight = (h.value / totalValue) * 100; });
  } else if (totalWeight > 0 && totalWeight <= 1.05) {
    holdings.forEach(h => { h.weight = h.weight * 100; });
  } else if (totalWeight === 0 && holdings.length > 0) {
    // No weight column found (e.g. YCharts export) — assign equal weights
    const eqWt = 100 / holdings.length;
    holdings.forEach(h => { h.weight = eqWt; });
  }
  return holdings;
}

function scorePortfolioVsBeliefs(holdings, ycData, investorBeliefs, mgmtBeliefs) {
  if (!holdings || !holdings.length) return null;
  const totalW = holdings.reduce((s, h) => s + (h.weight || 0), 0) || 100;
  let wtdReturn=0, wtdVol=0, wtdBeta=0, wtdDrawdown=0, wtdYield=0, wtdSharpe=0;
  let wtd1M=0, wtd3M=0, wtd6M=0, wtd3Y=0, wtd5Y=0, compositeSum=0, compositeCount=0;
  let dataHits = 0;
  for (const h of holdings) {
    const d = ycData && ycData[h.ticker];
    if (!d) continue;
    dataHits++;
    const w = (h.weight || 0) / totalW;
    wtdReturn += (d.one_year_return || 0) * w;
    wtdVol += (d.one_year_volatility || 0) * w;
    wtdBeta += (d.beta_5_year || 0) * w;
    wtdDrawdown += (d.max_drawdown_3_year || 0) * w;
    wtdYield += (d.dividend_yield || 0) * w;
    wtdSharpe += (d.sharpe || 0) * w;
    wtd1M += (d.one_month_return || 0) * w;
    wtd3M += (d.three_month_return || 0) * w;
    wtd6M += (d.six_month_return || 0) * w;
    wtd3Y += (d.three_year_annualized_return || 0) * w;
    wtd5Y += (d.five_year_annualized_return || 0) * w;
    if (d.composite != null) { compositeSum += d.composite; compositeCount++; }
  }
  const metrics = { wtdReturn, wtdVol, wtdBeta, wtdDrawdown, wtdYield, wtdSharpe, wtd1M, wtd3M, wtd6M, wtd3Y, wtd5Y,
    avgComposite: compositeCount > 0 ? compositeSum / compositeCount : 50, dataHits, dataCoverage: dataHits / holdings.length };
  const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
  const scores = { investor: {}, management: {} };
  const rp = investorBeliefs?.riskTolerance || "moderate";
  scores.investor.riskAlignment = Math.round(rp === "conservative"
    ? clamp(100 - Math.abs(wtdVol * 100) * 3 - Math.abs(wtdDrawdown * 100) * 2, 0, 100)
    : rp === "aggressive" ? clamp(wtdReturn * 200 + 40, 0, 100) : clamp(70 + wtdSharpe * 20 - Math.abs(wtdDrawdown * 50), 0, 100));
  const ip = investorBeliefs?.incomeNeed || "none";
  scores.investor.incomeAlignment = Math.round(ip === "primary" ? clamp(wtdYield * 100 * 8, 0, 100)
    : ip === "moderate" ? clamp(50 + wtdYield * 100 * 5, 0, 100) : 70);
  const hp = investorBeliefs?.timeHorizon || "medium";
  scores.investor.horizonAlignment = Math.round(hp === "long" ? clamp(50 + wtdReturn * 150, 0, 100)
    : hp === "short" ? clamp(80 - wtdVol * 100 * 2.5, 0, 100) : clamp(60 + wtdSharpe * 25, 0, 100));
  const maxWeight = Math.max(...holdings.map(h => h.weight || 0), 0);
  scores.investor.diversification = Math.round(clamp(100 - (maxWeight - 10) * 2 + Math.min(holdings.length, 20) * 2, 0, 100));
  scores.management.momentumAlignment = Math.round(clamp(50 + wtd1M * 500 + wtd3M * 200 + wtd6M * 100, 0, 100));
  scores.management.riskAdjQuality = Math.round(clamp(wtdSharpe * 40 + 40, 0, 100));
  scores.management.drawdownResilience = Math.round(clamp(100 + wtdDrawdown * 200, 0, 100));
  const rv = mgmtBeliefs?.regimeView || "neutral";
  scores.management.regimeFit = Math.round(rv === "bullish" ? clamp(50 + wtdBeta * 30 + wtdReturn * 100, 0, 100)
    : rv === "bearish" ? clamp(80 - wtdBeta * 50 + wtdYield * 300, 0, 100) : clamp(60 + wtdSharpe * 25, 0, 100));
  scores.management.compositeScore = Math.round(clamp(metrics.avgComposite, 0, 100));
  const invVals = Object.values(scores.investor);
  const mgmtVals = Object.values(scores.management);
  scores.investorTotal = Math.round(invVals.reduce((a,b) => a+b, 0) / invVals.length);
  scores.managementTotal = Math.round(mgmtVals.reduce((a,b) => a+b, 0) / mgmtVals.length);
  scores.overall = Math.round(scores.investorTotal * 0.5 + scores.managementTotal * 0.5);
  scores.metrics = metrics;
  return scores;
}

function compGrade(score) {
  if (score >= 85) return { grade: "A", color: "#00E676" };
  if (score >= 70) return { grade: "B", color: "#2E8BFF" };
  if (score >= 55) return { grade: "C", color: "#FFB300" };
  return { grade: "D", color: "#FF3D57" };
}



// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// LAYER 1: YCharts Data Engine
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

async function fetchYChartsData(apiKey) {
  if (!apiKey) return null;
  const allTickers = HOLDINGS.map(h => h.ticker).join(",");
  const results = {};
  try {
    for (const metric of YCHART_METRICS) {
      const resp = await fetch(
        `https://api.ycharts.com/v4/companies/${allTickers}/points/${metric}`,
        { headers: { "X-YCHARTSAUTHORIZATION": apiKey, "Accept": "application/json" } }
      );
      if (resp.ok) {
        const data = await resp.json();
        if (data?.response) {
          for (const item of data.response) {
            const ticker = item?.meta?.identifier;
            if (ticker) {
              if (!results[ticker]) results[ticker] = {};
              results[ticker][metric] = item?.data?.[0]?.[1] ?? null;
            }
          }
        }
      }
    }
    for (const ind of MARKET_INDICATORS) {
      const resp = await fetch(
        `https://api.ycharts.com/v4/indices/${ind.ticker}/points/${ind.metric}`,
        { headers: { "X-YCHARTSAUTHORIZATION": apiKey, "Accept": "application/json" } }
      );
      if (resp.ok) {
        const data = await resp.json();
        const val = data?.response?.[0]?.data?.[0]?.[1];
        results[ind.ticker] = { [ind.metric]: val ? val / (ind.divisor || 1) : null };
      }
    }
    return results;
  } catch (e) { console.error("YCharts API error:", e); return null; }
}

function parseYChartsPaste(text) {
  if (!text?.trim()) return null;
  const results = {};
  const lines = text.trim().split("\n");
  if (lines.length < 2) return null;
  const headers = lines[0].split(/[,\t]/).map(h => h.trim().toLowerCase());
  const tickerCol = headers.findIndex(h => h === "ticker" || h === "symbol" || h === "name");
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(/[,\t]/).map(c => c.trim());
    const ticker = cols[tickerCol]?.toUpperCase();
    if (!ticker) continue;
    results[ticker] = {};
    headers.forEach((h, idx) => {
      if (idx === tickerCol) return;
      const val = parseFloat(cols[idx]?.replace(/[%$,]/g, ""));
      if (!isNaN(val)) {
        const key = mapHeader(h);
        if (key) results[ticker][key] = h.includes("%") || h.includes("return") || h.includes("yield") ? val / 100 : val;
      }
    });
  }
  return Object.keys(results).length > 0 ? results : null;
}

function mapHeader(h) {
  const m = {
    "price": "price", "last price": "price", "close": "price",
    "1 year return": "one_year_return", "1y return": "one_year_return",
    "3 year return": "three_year_annualized_return",
    "5 year return": "five_year_annualized_return",
    "volatility": "one_year_volatility", "1y volatility": "one_year_volatility",
    "max drawdown": "max_drawdown_3_year", "beta": "beta_5_year",
    "dividend yield": "dividend_yield", "div yield": "dividend_yield",
    "forward p/e": "forward_pe_ratio", "fwd pe": "forward_pe_ratio",
    "1 month return": "one_month_return", "1m return": "one_month_return",
    "3 month return": "three_month_return", "3m return": "three_month_return",
    "6 month return": "six_month_return", "6m return": "six_month_return",
  };
  return m[h] || null;
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// STYLE-AWARE SCORING ENGINE
// Composite weights and signal thresholds change per investor style
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function computeDerivedMetrics(ycData, styleId = "balanced", riskFreeRate = 0.045) {
  const w = getStyleWeights(styleId);
  const t = getStyleThresholds(styleId);
  const style = INVESTOR_STYLES[styleId] || INVESTOR_STYLES.balanced;
  const enriched = {};

  for (const [ticker, data] of Object.entries(ycData)) {
    const d = { ...data };
    const ret = d.one_year_return;
    const vol = d.one_year_volatility;
    const beta = d.beta_5_year;

    // Risk-adjusted metrics (style-independent)
    d.sharpe = vol && vol !== 0 ? (ret - riskFreeRate) / vol : null;
    d.sortino = d.sharpe ? d.sharpe * 1.3 : null;
    d.treynor = beta && beta !== 0 ? (ret - riskFreeRate) / beta : null;

    // Sub-scores (style-independent computation)
    const mom12 = d.one_year_return;
    if (mom12 != null) d.trendScore = Math.min(100, Math.max(0, Math.round(50 + mom12 * 150 + (ret > 0 ? 15 : 0) + (beta > 0 ? 5 : -5))));
    const mom1 = d.one_month_return;
    const mom3 = d.three_month_return;
    if (mom1 != null) d.techScore = Math.min(100, Math.max(0, Math.round(50 + mom1 * 200 + (mom1 > 0 && mom3 > 0 ? 10 : -5) + (vol < 0.20 ? 10 : -5))));
    if (ret != null && vol != null) d.fundScore = Math.min(100, Math.max(0, Math.round(30 + (vol > 0 ? ret / vol : 0) * 40 + (Math.abs(beta || 1) < 0.5 ? 15 : 0) + (ret > 0.08 ? 10 : 0))));
    const m1 = d.one_month_return || 0, m3 = d.three_month_return || 0, m6 = d.six_month_return || 0, m12 = d.one_year_return || 0;
    d.dwaProxy = Math.min(100, Math.max(0, Math.round(50 + (m1*0.4 + m3*0.3 + m6*0.2 + m12*0.1) * 200)));

    // STYLE-WEIGHTED COMPOSITE
    d.composite = Math.round(
      (d.trendScore || 50) * w.trend +
      (d.techScore || 50) * w.tech +
      (d.fundScore || 50) * w.fund +
      (d.dwaProxy || 50) * w.dwa
    );

    // Technicals (style-independent)
    if (d.price && mom1 != null && vol != null) {
      const sma = d.price / (1 + mom1);
      const dv = vol / Math.sqrt(252);
      const upper = sma + 2 * sma * dv * Math.sqrt(20);
      const lower = sma - 2 * sma * dv * Math.sqrt(20);
      d.bbPercentB = upper !== lower ? (d.price - lower) / (upper - lower) : 0.5;
      d.bbWidth = sma ? (upper - lower) / sma : 0;
      d.bbSignal = d.bbPercentB < 0.05 && d.bbWidth < 0.04 ? "SQUEEZE BUY" : d.bbPercentB < 0.1 ? "OVERSOLD BUY" : d.bbPercentB > 0.95 ? "OVERBOUGHT SELL" : d.bbPercentB >= 0.5 ? "TREND HOLD" : "NEUTRAL";
    }
    if (m12 != null && m3 != null && m1 != null) {
      if (m12 > 0 && m3 > 0 && m1 > 0) d.wavePhase = "IMPULSE UP";
      else if (m12 > 0 && m3 < 0) d.wavePhase = "CORRECTIVE";
      else if (m12 < 0 && m1 > 0) d.wavePhase = "WAVE 1 START";
      else if (m12 < 0 && m1 < 0) d.wavePhase = "DECLINE";
      else d.wavePhase = "TRANSITION";
    }
    d.rsiProxy = Math.min(100, Math.max(0, 50 + (m1 || 0) * 500));
    d.gannAngle = Math.round(Math.atan((m1 || 0) * 12 / 0.1) * 180 / Math.PI * 10) / 10;
    d.above1x1 = (d.gannAngle || 0) >= 45;

    // STYLE-AWARE SIGNAL GENERATION
    if (style.invertSignals) {
      // Contrarian: invert the signal logic
      if (d.composite <= t.strongBuy) d.signal = "STRONG BUY";
      else if (d.composite <= t.buy) d.signal = "BUY";
      else if (d.composite >= t.strongSell) d.signal = "STRONG SELL";
      else if (d.composite >= t.sell) d.signal = "SELL";
      else d.signal = "HOLD";
    } else {
      if (d.composite >= t.strongBuy) d.signal = "STRONG BUY";
      else if (d.composite >= t.buy) d.signal = "BUY";
      else if (d.composite <= t.strongSell) d.signal = "STRONG SELL";
      else if (d.composite <= t.sell) d.signal = "SELL";
      else d.signal = "HOLD";
    }

    d.priority = d.signal.includes("STRONG") ? "P1 â€” IMMEDIATE" : ["BUY","SELL"].includes(d.signal) ? "P2 â€” THIS WEEK" : "P3 â€” MONITOR";
    enriched[ticker] = d;
  }
  return enriched;
}

function computePortfolioMetrics(enrichedData, styleId = "balanced") {
  const fsmThresholds = getStyleFSM(styleId);
  let wtdReturn = 0, wtdVol = 0, wtdBeta = 0, wtdSharpe = 0, wtdYield = 0, compositeAvg = 0, count = 0;
  for (const h of HOLDINGS) {
    const d = enrichedData[h.ticker]; if (!d) continue;
    const wt = h.target / 100;
    if (d.one_year_return != null) wtdReturn += wt * d.one_year_return;
    if (d.one_year_volatility != null) wtdVol += wt * d.one_year_volatility;
    if (d.beta_5_year != null) wtdBeta += wt * d.beta_5_year;
    if (d.sharpe != null) wtdSharpe += wt * d.sharpe;
    if (d.dividend_yield != null) wtdYield += wt * d.dividend_yield;
    if (d.composite != null) { compositeAvg += d.composite; count++; }
  }
  const avgComposite = count > 0 ? compositeAvg / count : 50;
  const bullishPct = HOLDINGS.filter(h => (enrichedData[h.ticker]?.composite || 0) >= 60).length / HOLDINGS.length;

  // STYLE-AWARE FSM THRESHOLDS
  let fsmSignal;
  if (bullishPct >= fsmThresholds.fullyInvested) fsmSignal = "FULLY INVESTED";
  else if (bullishPct >= fsmThresholds.caution) fsmSignal = "CAUTION";
  else if (bullishPct >= fsmThresholds.defensive) fsmSignal = "DEFENSIVE";
  else fsmSignal = "RISK OFF";

  const signals = { strongBuy: 0, buy: 0, hold: 0, sell: 0, strongSell: 0 };
  HOLDINGS.forEach(h => { const s = enrichedData[h.ticker]?.signal;
    if (s === "STRONG BUY") signals.strongBuy++;
    else if (s === "BUY") signals.buy++;
    else if (s === "SELL") signals.sell++;
    else if (s === "STRONG SELL") signals.strongSell++;
    else signals.hold++;
  });

  const pctAbove50 = HOLDINGS.filter(h => (enrichedData[h.ticker]?.composite || 0) >= 50).length / HOLDINGS.length;
  const pctAbove70 = HOLDINGS.filter(h => (enrichedData[h.ticker]?.composite || 0) >= 70).length / HOLDINGS.length;
  const cashTriggers = {
    mmpr50: pctAbove50 < 0.40, mmpr70: pctAbove70 < 0.25,
    pr4050: avgComposite < 45, pr4080: avgComposite < 40,
    anyActive: false
  };
  cashTriggers.anyActive = cashTriggers.mmpr50 || cashTriggers.mmpr70 || cashTriggers.pr4050 || cashTriggers.pr4080;

  return { wtdReturn, wtdVol, wtdBeta, wtdSharpe, wtdYield, avgComposite, bullishPct, fsmSignal, signals, cashTriggers, styleId };
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// LAYER 2: AGENTIC AI ENGINE WITH STYLE-AWARE PROMPTS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

const YCHARTS_TOOLS = [
  {
    name: "query_holding",
    description: "Get complete YCharts data for one or more specific holdings. Returns all metrics: price, returns (1M/3M/6M/1Y/3Y/5Y), volatility, beta, Sharpe, Sortino, Treynor, max drawdown, dividend yield, forward P/E, composite score, trend/tech/fundamental/DWA sub-scores, Bollinger Band %B and signal, Elliott Wave phase, Gann angle, RSI proxy, signal, and priority. Use this to deep-dive into specific positions.",
    input_schema: {
      type: "object",
      properties: {
        tickers: { type: "array", items: { type: "string" }, description: "Array of ticker symbols, e.g. ['SPY', 'QQQ', 'AAPL']" }
      },
      required: ["tickers"]
    }
  },
  {
    name: "query_sector",
    description: "Get aggregated metrics for an asset class or sector. Computes weighted averages across all holdings in that class. Valid classes: 'US Eq', 'Intl', 'Bond', 'Alt', 'REIT', 'MF' (Managed Futures), 'Hedge'. Also accepts 'all' for portfolio-wide aggregates, or 'ETF'/'Stock' to filter by type.",
    input_schema: {
      type: "object",
      properties: {
        class_filter: { type: "string", description: "Asset class name or 'all', 'ETF', 'Stock'" }
      },
      required: ["class_filter"]
    }
  },
  {
    name: "compare_holdings",
    description: "Side-by-side comparison of 2-6 holdings across specific metrics. Returns a comparison table.",
    input_schema: {
      type: "object",
      properties: {
        tickers: { type: "array", items: { type: "string" }, description: "2-6 tickers to compare" },
        metrics: { type: "array", items: { type: "string" }, description: "Metrics to compare. Use 'all' for everything." }
      },
      required: ["tickers"]
    }
  },
  {
    name: "screen_holdings",
    description: "Filter holdings by metric thresholds. Returns only holdings matching ALL conditions.",
    input_schema: {
      type: "object",
      properties: {
        conditions: {
          type: "array",
          items: {
            type: "object",
            properties: {
              metric: { type: "string" },
              operator: { type: "string", enum: [">", "<", ">=", "<=", "==", "!=", "contains"] },
              value: { type: "number" }
            },
            required: ["metric", "operator", "value"]
          }
        }
      },
      required: ["conditions"]
    }
  },
  {
    name: "query_market_indicators",
    description: "Get current market regime indicators: VIX, yields, USD, HY bond proxy. Also returns FSM signal, cash trigger status, and regime assessment.",
    input_schema: { type: "object", properties: {} }
  },
  {
    name: "query_signals",
    description: "Get the complete signal distribution and multi-system agreement matrix.",
    input_schema: { type: "object", properties: {} }
  },
  {
    name: "query_technicals",
    description: "Get detailed technical analysis: Bollinger Bands, Elliott Wave, Gann, RSI, MACD proxies.",
    input_schema: {
      type: "object",
      properties: {
        tickers: { type: "array", items: { type: "string" } }
      },
      required: ["tickers"]
    }
  },
  {
    name: "run_scenario",
    description: "Run a what-if scenario: equity shock, rate shock, vol spike, sector rotation.",
    input_schema: {
      type: "object",
      properties: {
        scenario_type: { type: "string", enum: ["equity_shock", "rate_shock", "vol_spike", "sector_rotation", "custom"] },
        magnitude: { type: "number" },
        description: { type: "string" }
      },
      required: ["scenario_type", "magnitude"]
    }
  }
];

// â€” Tool Execution Handler â€”
function executeYChartsTool(toolName, toolInput, ycData, pm) {
  const hasData = ycData && Object.keys(ycData).length > 0;
  if (!hasData) return { error: "No YCharts data loaded. Use web_search for market data instead." };
  const fmt = (v, d = 4) => v != null ? Number(v.toFixed ? v.toFixed(d) : v) : null;
  const pct = (v) => v != null ? Number((v * 100).toFixed(2)) : null;
  const holdingProfile = (ticker) => {
    const d = ycData[ticker];
    const h = HOLDINGS.find(x => x.ticker === ticker);
    if (!d) return { ticker, error: "No data available" };
    return {
      ticker, name: h?.name, assetClass: h?.class, type: h?.type, targetWeight: h?.target,
      price: fmt(d.price, 2),
      returns: { oneMonth: pct(d.one_month_return), threeMonth: pct(d.three_month_return), sixMonth: pct(d.six_month_return), oneYear: pct(d.one_year_return), threeYear: pct(d.three_year_annualized_return), fiveYear: pct(d.five_year_annualized_return) },
      risk: { volatility: pct(d.one_year_volatility), beta: fmt(d.beta_5_year, 2), maxDrawdown3Y: pct(d.max_drawdown_3_year), sharpe: fmt(d.sharpe, 2), sortino: fmt(d.sortino, 2), treynor: fmt(d.treynor, 2) },
      fundamentals: { dividendYield: pct(d.dividend_yield), forwardPE: fmt(d.forward_pe_ratio, 1) },
      scores: { trend: d.trendScore, technical: d.techScore, fundamental: d.fundScore, dwaProxy: d.dwaProxy, composite: d.composite },
      technicals: { bbPercentB: fmt(d.bbPercentB, 3), bbWidth: fmt(d.bbWidth, 3), bbSignal: d.bbSignal, wavePhase: d.wavePhase, gannAngle: d.gannAngle, above1x1: d.above1x1, rsiProxy: fmt(d.rsiProxy, 0) },
      signal: d.signal, priority: d.priority
    };
  };

  switch (toolName) {
    case "query_holding": {
      const tickers = toolInput.tickers?.map(t => t.toUpperCase()) || [];
      return { holdings: tickers.map(holdingProfile) };
    }
    case "query_sector": {
      const filter = toolInput.class_filter;
      let filtered;
      if (filter === "all") filtered = HOLDINGS;
      else if (filter === "ETF" || filter === "Stock") filtered = HOLDINGS.filter(h => h.type === filter);
      else filtered = HOLDINGS.filter(h => h.class === filter);
      if (filtered.length === 0) return { error: `No holdings match filter '${filter}'` };
      const agg = { count: filtered.length, tickers: filtered.map(h => h.ticker), totalWeight: filtered.reduce((s, h) => s + h.target, 0) };
      const metrics = ["one_year_return", "one_year_volatility", "beta_5_year", "sharpe", "composite"];
      metrics.forEach(m => {
        const vals = filtered.map(h => ycData[h.ticker]?.[m]).filter(v => v != null);
        agg[m] = { avg: vals.length ? fmt(vals.reduce((a,b) => a+b, 0) / vals.length, 3) : null, min: vals.length ? fmt(Math.min(...vals), 3) : null, max: vals.length ? fmt(Math.max(...vals), 3) : null };
      });
      const signalDist = {};
      filtered.forEach(h => { const s = ycData[h.ticker]?.signal || "UNKNOWN"; signalDist[s] = (signalDist[s] || 0) + 1; });
      agg.signals = signalDist;
      return { sector: filter, aggregates: agg };
    }
    case "compare_holdings": {
      const tickers = toolInput.tickers?.map(t => t.toUpperCase()) || [];
      const useAll = !toolInput.metrics || toolInput.metrics.includes("all");
      const comparison = {};
      tickers.forEach(t => {
        const d = ycData[t]; if (!d) { comparison[t] = { error: "No data" }; return; }
        if (useAll) { comparison[t] = holdingProfile(t); }
        else { comparison[t] = {}; toolInput.metrics.forEach(m => { comparison[t][m] = d[m] ?? null; }); comparison[t].signal = d.signal; }
      });
      return { comparison };
    }
    case "screen_holdings": {
      const conditions = toolInput.conditions || [];
      const matches = HOLDINGS.filter(h => {
        const d = ycData[h.ticker]; if (!d) return false;
        return conditions.every(c => {
          const val = d[c.metric]; if (val == null) return false;
          if (c.operator === "contains") return String(val).toLowerCase().includes(String(c.value).toLowerCase());
          const numVal = typeof val === "number" ? val : parseFloat(val);
          if (isNaN(numVal)) return false;
          switch (c.operator) {
            case ">": return numVal > c.value; case "<": return numVal < c.value;
            case ">=": return numVal >= c.value; case "<=": return numVal <= c.value;
            case "==": return numVal === c.value; case "!=": return numVal !== c.value;
            default: return false;
          }
        });
      });
      return { matchCount: matches.length, holdings: matches.map(h => holdingProfile(h.ticker)) };
    }
    case "query_market_indicators": {
      const vix = ycData["^VIX"], t10 = ycData["^TNX"], t2 = ycData["^IRX"], uup = ycData["UUP"], hyg = ycData["HYG"];
      const spread = (t10?.price ?? 0) - (t2?.price ?? 0);
      return {
        indicators: { vix: fmt(vix?.price, 1), tenYearYield: fmt(t10?.price, 2), twoYearYield: fmt(t2?.price, 2), yieldCurveSpread: fmt(spread, 2), yieldCurveInverted: spread < 0, usdIndex: fmt(uup?.price, 2), highYieldBond: fmt(hyg?.price, 2) },
        regime: { fsmSignal: pm?.fsmSignal, bullishPercent: pct(pm?.bullishPct), avgComposite: fmt(pm?.avgComposite, 0), cashTriggers: pm?.cashTriggers, volatilityRegime: (vix?.price || 0) < 15 ? "LOW" : (vix?.price || 0) < 20 ? "MODERATE" : (vix?.price || 0) < 30 ? "ELEVATED" : "EXTREME" }
      };
    }
    case "query_signals": {
      const waveDist = {}, bbSignalDist = {};
      let p1 = 0, p2 = 0, p3 = 0, squeezes = 0, impulses = 0;
      HOLDINGS.forEach(h => {
        const d = ycData[h.ticker]; if (!d) return;
        waveDist[d.wavePhase || "UNKNOWN"] = (waveDist[d.wavePhase || "UNKNOWN"] || 0) + 1;
        bbSignalDist[d.bbSignal || "UNKNOWN"] = (bbSignalDist[d.bbSignal || "UNKNOWN"] || 0) + 1;
        if (d.priority?.startsWith("P1")) p1++; else if (d.priority?.startsWith("P2")) p2++; else p3++;
        if (d.bbSignal?.includes("SQUEEZE")) squeezes++;
        if (d.wavePhase === "IMPULSE UP") impulses++;
      });
      return {
        signalDistribution: pm?.signals, fsmSignal: pm?.fsmSignal, cashTriggers: pm?.cashTriggers,
        wavePhaseDistribution: waveDist, bollingerSignalDistribution: bbSignalDist,
        priorities: { p1_immediate: p1, p2_thisWeek: p2, p3_monitor: p3 },
        squeezeCount: squeezes, impulseCount: impulses,
        consensus: pm?.avgComposite >= 65 ? "BULLISH" : pm?.avgComposite >= 45 ? "NEUTRAL" : "BEARISH",
        consensusScore: fmt(pm?.avgComposite, 0)
      };
    }
    case "query_technicals": {
      const tickers = toolInput.tickers?.map(t => t.toUpperCase()) || [];
      return {
        technicals: tickers.map(t => {
          const d = ycData[t]; if (!d) return { ticker: t, error: "No data" };
          return {
            ticker: t,
            bollingerBands: { percentB: fmt(d.bbPercentB, 3), width: fmt(d.bbWidth, 3), signal: d.bbSignal, score: d.bbPercentB < 0.05 ? 85 : d.bbPercentB < 0.1 ? 80 : d.bbPercentB > 0.95 ? 15 : d.bbPercentB >= 0.5 ? 65 : 50 },
            elliottWave: { phase: d.wavePhase, isImpulse: d.wavePhase === "IMPULSE UP", score: d.wavePhase === "WAVE 1 START" ? 90 : d.wavePhase === "IMPULSE UP" ? 80 : d.wavePhase === "CORRECTIVE" ? 55 : d.wavePhase === "DECLINE" ? 15 : 50 },
            gann: { angle: d.gannAngle, above1x1: d.above1x1, score: d.above1x1 && d.gannAngle > 50 ? 90 : d.above1x1 ? 75 : d.gannAngle < -45 ? 15 : 45 },
            momentum: { rsiProxy: fmt(d.rsiProxy, 0), macdProxy: fmt(((d.one_month_return || 0) - (d.three_month_return || 0)) * 100, 2) },
            scores: { trend: d.trendScore, tech: d.techScore, fund: d.fundScore, dwa: d.dwaProxy, composite: d.composite },
            signal: d.signal, priority: d.priority
          };
        })
      };
    }
    case "run_scenario": {
      const { scenario_type, magnitude } = toolInput;
      const style = INVESTOR_STYLES[pm?.styleId] || INVESTOR_STYLES.balanced;
      const results = HOLDINGS.map(h => {
        const d = ycData[h.ticker]; if (!d) return { ticker: h.ticker, impact: 0 };
        let impact = 0;
        const beta = d.beta_5_year || 0.5;
        if (scenario_type === "equity_shock") impact = magnitude * beta;
        else if (scenario_type === "rate_shock") {
          const duration = h.class === "Bond" ? -7 : h.class === "REIT" ? -3 : h.class === "US Eq" ? -0.5 : 0;
          impact = magnitude * duration * 100;
        }
        else if (scenario_type === "vol_spike") {
          const vixDelta = magnitude - 18;
          impact = -(vixDelta / 100) * Math.abs(beta);
          if (h.class === "Hedge" || h.class === "MF") impact = Math.abs(impact) * 0.5 * style.hedgeMultiplier;
        }
        else impact = magnitude * beta;
        return { ticker: h.ticker, class: h.class, beta, impact: fmt(impact * 100, 2), dollarImpact: fmt(impact * h.target * 1000, 0) };
      });
      const totalImpact = results.reduce((s, r) => s + (r.impact || 0), 0) / HOLDINGS.length;
      results.sort((a, b) => (a.impact || 0) - (b.impact || 0));
      return {
        scenario: toolInput.description || scenario_type,
        magnitude, portfolioImpact: fmt(totalImpact, 2) + "%",
        mostImpacted: results.slice(0, 5), leastImpacted: results.slice(-5).reverse(),
        recommendedActions: totalImpact < -10 ? ["Activate defensive allocation", "Deploy BTAL/TAIL hedges", `Raise cash to ${style.cashMax}%+`] :
          totalImpact < -5 ? ["Tighten rebalance bands", "Review buffered ETF allocation", "Add to managed futures"] :
          ["Monitor positions", "No immediate action required"]
      };
    }
    default: return { error: `Unknown tool: ${toolName}` };
  }
}


// â€” Style-Aware Agentic Loop â€”
async function runAgenticAnalysis(ycData, pm, reportType, styleId, onProgress) {
  const hasData = ycData && Object.keys(ycData).length > 0;
  const summaryContext = hasData ? buildSummaryContext(ycData, pm) : "No YCharts data loaded. Use web_search for all market data.";
  const style = INVESTOR_STYLES[styleId] || INVESTOR_STYLES.balanced;

  // STYLE-INJECTED SYSTEM PROMPT
  const systemPrompt = `You are a senior analyst at Marline Wealth Management operating as a ${style.persona}.

INVESTMENT STYLE: ${style.name.toUpperCase()}
${style.aiPersona}

PRIMARY ANALYTICAL EMPHASIS: ${style.emphasis}

STYLE PARAMETERS IN EFFECT:
- Composite Weights: Trend ${style.weights.trend}%, Technical ${style.weights.tech}%, Fundamental ${style.weights.fund}%, DWA ${style.weights.dwa}%
- Signal Thresholds: Strong Buy â‰¥${style.thresholds.strongBuy}, Buy â‰¥${style.thresholds.buy}, Sell â‰¤${style.thresholds.sell}, Strong Sell â‰¤${style.thresholds.strongSell}
- FSM Sensitivity: Fully Invested at ${(style.fsm.fullyInvested*100).toFixed(0)}%, Caution at ${(style.fsm.caution*100).toFixed(0)}%, Defensive at ${(style.fsm.defensive*100).toFixed(0)}%
- Rebalance Band: Â±${style.rebalanceBand}%
- Max Cash: ${style.cashMax}%
- Hedge Multiplier: ${style.hedgeMultiplier}x
${style.invertSignals ? '- CONTRARIAN MODE: Signal logic is INVERTED â€” low scores = buy opportunities, high scores = sell signals\n' : ''}
IMPORTANT: All recommendations MUST be consistent with the ${style.name} investment philosophy. Frame analysis through this lens.

WORKFLOW:
1. Use YCharts query tools to examine portfolio data. Don't guess â€” query it.
2. Use web_search for current news, Fed commentary, economic data, and qualitative context.
3. Synthesize precise YCharts numbers with qualitative research through your ${style.persona} lens.

PORTFOLIO SUMMARY:
${summaryContext}

Today's date: ${new Date().toISOString().split("T")[0]}`;

  const reportPrompts = {
    daily: `Produce a comprehensive daily market intelligence report through your ${style.name} lens.

Start by querying market indicators and signal distribution. Then use web_search for today's major news. Query specific holdings showing extreme signals.

STYLE GUIDANCE: ${style.aiPersona}

After gathering all data, respond with ONLY a JSON object (no markdown, no backticks):
{
  "date": "YYYY-MM-DD",
  "investorStyle": "${style.name}",
  "marketNarrative": "3-4 sentence synthesis through ${style.name} lens",
  "regimeAssessment": {
    "regime": "BULLISH|BEARISH|NEUTRAL|CAUTIOUS",
    "regimeScore": 0, "confidence": "HIGH|MEDIUM|LOW",
    "trendDirection": "UP|DOWN|SIDEWAYS",
    "volatilityRegime": "LOW|MODERATE|ELEVATED|EXTREME",
    "breadthAssessment": "STRONG|MODERATE|WEAK|DETERIORATING",
    "momentumRegime": "ACCELERATING|STEADY|DECELERATING|REVERSING",
    "creditConditions": "TIGHT|NORMAL|LOOSE",
    "recessionProbability": 0, "selloffRisk": "LOW|MODERATE|ELEVATED|HIGH",
    "rationale": "WHY â€” cite specific metrics and interpret through ${style.name} philosophy"
  },
  "cycleDiagnosis": {
    "currentCycle": "EARLY EXPANSION|MID EXPANSION|LATE EXPANSION|PEAK|EARLY CONTRACTION|RECESSION|RECOVERY",
    "cycleAge": "string", "leadingIndicators": "string", "transitionRisk": "LOW|MODERATE|HIGH",
    "nextPhaseETA": "string", "historicalAnalog": "string"
  },
  "sectorRotation": { "favored": [], "disfavored": [], "rotationSignal": "string" },
  "keyRisks": [{"risk": "str", "probability": "LOW|MEDIUM|HIGH", "impact": "LOW|MEDIUM|HIGH"}],
  "catalysts": ["string"],
  "forwardOutlook": { "daily": "str", "weekly": "str", "monthly": "str", "quarterly": "str" },
  "portfolioActions": [{"action": "str", "urgency": "IMMEDIATE|THIS WEEK|THIS MONTH", "rationale": "str"}]
}`,
    equity: `Produce ${style.name}-perspective buy/sell analysis for all portfolio holdings.

Query signal distribution first, then detailed technicals for priority holdings. Use web_search for recent news on extreme-signal tickers.

STYLE GUIDANCE: ${style.aiPersona}

After gathering all data, respond with ONLY a JSON object:
{
  "analysisDate": "YYYY-MM-DD",
  "investorStyle": "${style.name}",
  "marketContext": "2-3 sentence overview through ${style.name} lens",
  "equities": [
    {
      "ticker": "SPY", "ychartComposite": 0, "ychartSignal": "str",
      "analystSignal": "STRONG BUY|BUY|HOLD|SELL|STRONG SELL",
      "technicalView": "BULLISH|NEUTRAL|BEARISH",
      "fundamentalView": "BULLISH|NEUTRAL|BEARISH",
      "catalystView": "POSITIVE|NEUTRAL|NEGATIVE",
      "relativeStrength": "OUTPERFORM|INLINE|UNDERPERFORM",
      "conviction": "HIGH|MEDIUM|LOW",
      "bollingerRead": "str", "elliottWaveRead": "str", "gannRead": "str",
      "newsContext": "str", "keyLevels": "str",
      "recommendation": "str â€” framed through ${style.name} philosophy",
      "riskFlag": "str"
    }
  ]
}`,
    portfolio: `Produce a Morningstar-style portfolio analysis through your ${style.name} lens.

Query aggregates, sector breakdowns, market indicators, signals. Use web_search for benchmarks and economic data. Run a scenario analysis.

STYLE GUIDANCE: ${style.aiPersona}

After gathering all data, respond with ONLY a JSON object:
{
  "reportDate": "YYYY-MM-DD",
  "investorStyle": "${style.name}",
  "benchmarkData": { "sp500Ytd": 0, "aggBondYtd": 0, "sixtyFortyYtd": 0, "portfolioVsBenchmark": 0 },
  "economicSnapshot": {
    "gdpGrowth": 0, "cpiInflation": 0, "corePCE": 0, "fedFundsRate": 0,
    "unemploymentRate": 0, "ismManufacturing": 0, "ismServices": 0,
    "leadingIndicators": "EXPANDING|STABLE|CONTRACTING", "economicSummary": "str"
  },
  "styleAnalysis": {
    "overallStyle": "str â€” describe through ${style.name} lens", "equityStyle": "str", "fixedIncomeStyle": "str",
    "riskLevel": 3, "styleDrift": "str"
  },
  "performanceAttribution": {
    "topContributors": [{"ticker": "X", "contribution": "str"}],
    "topDetractors": [{"ticker": "X", "detraction": "str"}],
    "allocationEffect": "str", "selectionEffect": "str"
  },
  "riskAssessment": {
    "portfolioRiskLevel": "str", "var95Commentary": "str",
    "drawdownRisk": "str", "tailRiskAssessment": "str", "correlationRisk": "str"
  },
  "quarterlyOutlook": "4-5 sentences through ${style.name} philosophy",
  "strategicRecommendations": [
    {"priority": 1, "recommendation": "str", "rationale": "str", "impact": "str"}
  ],
  "portfolioGrade": "A|B|C|D", "gradeRationale": "str"
}`
  };

  const tools = [
    ...YCHARTS_TOOLS.map(t => ({ name: t.name, description: t.description, input_schema: t.input_schema })),
    { type: "web_search_20250305", name: "web_search" }
  ];

  let messages = [{ role: "user", content: reportPrompts[reportType] }];
  let finalResult = null;
  let rounds = 0;

  onProgress?.({ phase: "starting", message: `Initializing ${style.name} analysis...`, round: 0 });

  while (rounds < MAX_TOOL_ROUNDS) {
    rounds++;
    onProgress?.({ phase: "calling_api", message: `${style.persona} thinking (round ${rounds})...`, round: rounds });
    try {
      const resp = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: MODEL, max_tokens: 4096, system: systemPrompt, tools, messages }),
      });
      const data = await resp.json();
      if (!data.content || data.content.length === 0) { onProgress?.({ phase: "error", message: "Empty API response" }); break; }
      const toolUseBlocks = data.content.filter(b => b.type === "tool_use");
      const textBlocks = data.content.filter(b => b.type === "text");
      if (toolUseBlocks.length === 0) {
        const text = textBlocks.map(b => b.text).join("\n");
        const clean = text.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
        const match = clean.match(/\{[\s\S]*\}/);
        if (match) { try { finalResult = JSON.parse(match[0]); } catch { finalResult = null; } }
        onProgress?.({ phase: "complete", message: `${style.name} analysis complete (${rounds} rounds)`, round: rounds });
        break;
      }
      messages.push({ role: "assistant", content: data.content });
      const toolResults = [];
      for (const toolBlock of toolUseBlocks) {
        const { id, name, input } = toolBlock;
        if (name === "web_search") {
          onProgress?.({ phase: "web_search", message: `Searching: ${input?.query || "..."}`, round: rounds, tool: name });
          toolResults.push({ type: "tool_result", tool_use_id: id, content: "Web search executed by API" });
        } else {
          onProgress?.({ phase: "tool_call", message: `${name}(${JSON.stringify(input).substring(0, 80)}...)`, round: rounds, tool: name });
          const result = executeYChartsTool(name, input, ycData, pm);
          toolResults.push({ type: "tool_result", tool_use_id: id, content: JSON.stringify(result) });
        }
      }
      messages.push({ role: "user", content: toolResults });
    } catch (e) { onProgress?.({ phase: "error", message: `API error: ${e.message}`, round: rounds }); break; }
  }
  return finalResult;
}

function buildSummaryContext(ycData, pm) {
  if (!pm) return "No portfolio metrics computed.";
  const styleLabel = INVESTOR_STYLES[pm.styleId]?.name || "Balanced";
  let s = `Style: ${styleLabel} | Holdings: ${HOLDINGS.length} | FSM: ${pm.fsmSignal} | `;
  s += `Composite: ${pm.avgComposite.toFixed(0)}/100 | Bullish: ${(pm.bullishPct*100).toFixed(0)}%\n`;
  s += `Signals: ${pm.signals.strongBuy} SB, ${pm.signals.buy} B, ${pm.signals.hold} H, ${pm.signals.sell} S, ${pm.signals.strongSell} SS\n`;
  s += `Cash Triggers: ${pm.cashTriggers.anyActive ? "ACTIVE" : "ALL CLEAR"}\n`;
  s += `Weighted: Return ${(pm.wtdReturn*100).toFixed(1)}%, Vol ${(pm.wtdVol*100).toFixed(1)}%, Beta ${pm.wtdBeta.toFixed(2)}, Sharpe ${pm.wtdSharpe.toFixed(2)}\n`;
  s += `Holdings: ${HOLDINGS.map(h => h.ticker).join(", ")}\n`;
  s += `Asset classes: ${[...new Set(HOLDINGS.map(h => h.class))].join(", ")}`;
  return s;
}

// — Comparison Agentic Analysis —
async function runComparisonAnalysis(portfolios, ycData, pm, investorBeliefs, mgmtBeliefs, styleId, onProgress) {
  const style = INVESTOR_STYLES[styleId] || INVESTOR_STYLES.balanced;

  const portfolioSummaries = portfolios.map(p => ({
    name: p.name,
    holdings: p.holdings.map(h => `${h.ticker} (${(h.weight||0).toFixed(1)}%)`).join(", "),
    holdingCount: p.holdings.length,
    metrics: p.scores?.metrics || {},
    investorScore: p.scores?.investorTotal || 0,
    managementScore: p.scores?.managementTotal || 0,
    overallScore: p.scores?.overall || 0,
    investorDetail: p.scores?.investor || {},
    managementDetail: p.scores?.management || {},
  }));

  const systemPrompt = `You are a senior portfolio analyst at Marline Wealth Management operating as a ${style.persona}.
Your task: Compare multiple portfolios and provide optimization recommendations.
Investment Style: ${style.name} — ${style.aiPersona}
Use the query tools to look up specific holdings data, then synthesize a comprehensive comparison.`;

  const userPrompt = `Analyze and compare these portfolios, then provide optimization recommendations.

PORTFOLIOS WITH SCORES:
${JSON.stringify(portfolioSummaries, null, 2)}

INVESTOR BELIEFS: ${JSON.stringify(investorBeliefs)}
MANAGEMENT BELIEFS (${style.name}): ${JSON.stringify(mgmtBeliefs)}

INSTRUCTIONS:
1. Use query_holding to look up key tickers from each portfolio
2. Use query_market_indicators to understand current regime
3. Use web_search for current market context
4. Compare portfolios through the ${style.name} lens

After gathering data, respond with ONLY a JSON object (no markdown):
{
  "overallWinner": "portfolio name",
  "winnerRationale": "2-3 sentences why this portfolio is best given both belief frameworks",
  "investorBestFit": "portfolio name best for investor beliefs",
  "managementBestFit": "portfolio name best for management systematic signals",
  "portfolioRankings": [
    { "name": "str", "rank": 1, "strengths": ["str"], "weaknesses": ["str"],
      "investorNotes": "alignment with investor beliefs", "managementNotes": "alignment with systematic signals" }
  ],
  "optimizationSwaps": [
    { "portfolio": "str", "sell": "TICKER", "buy": "TICKER", "rationale": "str", "impact": "str" }
  ],
  "blendedRecommendation": "3-4 sentences describing optimal blend from all portfolios",
  "keyInsight": "single most important insight",
  "riskWarnings": ["str"],
  "actionPriorities": [
    { "priority": 1, "action": "str", "urgency": "IMMEDIATE|THIS WEEK|THIS MONTH" }
  ]
}`;

  const tools = [
    ...YCHARTS_TOOLS.map(t => ({ name: t.name, description: t.description, input_schema: t.input_schema })),
    { type: "web_search_20250305", name: "web_search" }
  ];

  let messages = [{ role: "user", content: userPrompt }];
  let finalResult = null;
  let rounds = 0;

  onProgress?.({ phase: "starting", message: "Initializing comparison analysis..." });

  while (rounds < MAX_TOOL_ROUNDS) {
    rounds++;
    onProgress?.({ phase: "calling_api", message: `${style.persona} comparing (round ${rounds})...`, round: rounds });
    try {
      const resp = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: MODEL, max_tokens: 4096, system: systemPrompt, tools, messages }),
      });
      const data = await resp.json();
      if (!data.content || data.content.length === 0) break;
      const toolUseBlocks = data.content.filter(b => b.type === "tool_use");
      const textBlocks = data.content.filter(b => b.type === "text");
      if (toolUseBlocks.length === 0) {
        const text = textBlocks.map(b => b.text).join("\n");
        const clean = text.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
        const match = clean.match(/\{[\s\S]*\}/);
        if (match) { try { finalResult = JSON.parse(match[0]); } catch (e) { /* parse error */ } }
        onProgress?.({ phase: "complete", message: `Comparison complete (${rounds} rounds)` });
        break;
      }
      messages.push({ role: "assistant", content: data.content });
      const toolResults = [];
      for (const toolBlock of toolUseBlocks) {
        const { id, name, input } = toolBlock;
        if (name === "web_search") {
          onProgress?.({ phase: "web_search", message: `Searching: ${input?.query || "..."}`, tool: name });
          toolResults.push({ type: "tool_result", tool_use_id: id, content: "Web search executed by API" });
        } else {
          onProgress?.({ phase: "tool_call", message: `${name}(${JSON.stringify(input).substring(0, 60)}...)`, tool: name });
          const result = executeYChartsTool(name, input, ycData, pm);
          toolResults.push({ type: "tool_result", tool_use_id: id, content: JSON.stringify(result) });
        }
      }
      messages.push({ role: "user", content: toolResults });
    } catch (e) { onProgress?.({ phase: "error", message: e.message }); break; }
  }
  return finalResult;
}



// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// UI COMPONENTS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

const C = {
  bg: "#060A10", card: "#0C1018", header: "#0E1320",
  border: "#161D2E", borderLight: "#1E2740",
  accent: "#00D4AA", blue: "#2E8BFF", purple: "#9366FF", cyan: "#00BCD4", magenta: "#E040FB",
  green: "#00E676", red: "#FF3D57", amber: "#FFB300", orange: "#FF7043",
  text: "#CDD6E4", textDim: "#6A7590", textMuted: "#3D4A63",
};

const sigColor = (s) => {
  if (!s) return C.textDim;
  const u = s.toUpperCase();
  if (/STRONG BUY|BULLISH|EXPANSION|RECOVERY|ACCELERAT|OUTPERFORM|IMPULSE UP|STRONG|EXPANDING/.test(u)) return C.green;
  if (/^BUY$|GROWTH|STEADY|INLINE|WAVE 1/.test(u)) return "#66BB6A";
  if (/STRONG SELL|BEARISH|RECESSION|DECLINE|EXTREME|DETERIORAT|CONTRACT/.test(u)) return C.red;
  if (/^SELL$|UNDERPERFORM|REVERSING|TIGHT/.test(u)) return "#FF7043";
  if (/CAUTIOUS|ELEVATED|LATE|PEAK|MEDIUM|MODERATE|CORRECTIVE/.test(u)) return C.amber;
  if (/HOLD|NEUTRAL|SIDEWAYS|TRANSITION|NORMAL|STABLE/.test(u)) return C.textDim;
  return C.text;
};

const Pill = ({ children, color }) => (
  <span style={{ display: "inline-block", padding: "2px 8px", borderRadius: 3, fontSize: 10, fontWeight: 700, letterSpacing: 0.6, color: color || C.text, background: `${color || C.textDim}15`, border: `1px solid ${color || C.textDim}30` }}>{children}</span>
);
const Metric = ({ label, value, sub, color, large }) => (
  <div style={{ padding: "5px 0", borderBottom: `1px solid ${C.border}` }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
      <span style={{ fontSize: 11, color: C.textDim }}>{label}</span>
      <span style={{ fontSize: large ? 16 : 12, fontWeight: large ? 700 : 500, color: color || C.text }}>{value}</span>
    </div>
    {sub && <div style={{ fontSize: 9, color: C.textMuted, textAlign: "right" }}>{sub}</div>}
  </div>
);
const Gauge = ({ value, max = 100, label, color }) => (
  <div style={{ marginBottom: 8 }}>
    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: C.textDim, marginBottom: 2 }}>
      <span>{label}</span><span style={{ color, fontWeight: 600 }}>{typeof value === "number" ? value.toFixed(0) : value}</span>
    </div>
    <div style={{ height: 4, background: C.border, borderRadius: 2, overflow: "hidden" }}>
      <div style={{ height: "100%", width: `${Math.min(100, Math.max(0, typeof value === "number" ? value : 50))}%`, background: `linear-gradient(90deg, ${color}90, ${color})`, borderRadius: 2, transition: "width 0.8s ease" }} />
    </div>
  </div>
);
const Card = ({ title, children, accent = C.accent, span = 1, row = 1 }) => (
  <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, padding: "14px 16px", gridColumn: `span ${span}`, gridRow: `span ${row}`, borderTop: `2px solid ${accent}` }}>
    {title && <div style={{ fontSize: 10, fontWeight: 700, color: accent, letterSpacing: 1.4, textTransform: "uppercase", marginBottom: 10, opacity: 0.9 }}>{title}</div>}
    {children}
  </div>
);
const Btn = ({ onClick, loading, children, accent = C.accent }) => (
  <button onClick={onClick} disabled={loading} style={{ padding: "7px 18px", border: `1px solid ${accent}40`, borderRadius: 4, background: loading ? C.card : `${accent}10`, color: accent, fontSize: 10, fontWeight: 700, cursor: loading ? "wait" : "pointer", fontFamily: "inherit", letterSpacing: 0.6 }}>{children}</button>
);
const StatusDot = ({ active, color = C.green }) => (
  <span style={{ display: "inline-block", width: 6, height: 6, borderRadius: "50%", background: active ? color : C.textMuted, boxShadow: active ? `0 0 8px ${color}60` : "none", marginRight: 6 }} />
);

const pctFmt = (v) => v != null ? `${v >= 0 ? "+" : ""}${(Number(v) * 100).toFixed(2)}%` : "\u2014";
const pctRaw = (v) => v != null ? `${v >= 0 ? "+" : ""}${Number(v).toFixed(2)}%` : "\u2014";
const usd = (v) => v != null ? `$${Number(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "\u2014";
const n = (v, d = 2) => v != null ? Number(v).toFixed(d) : "\u2014";


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// INVESTOR STYLE SELECTOR COMPONENT
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function StyleSelector({ styleId, onChange, expanded, onToggle }) {
  const style = INVESTOR_STYLES[styleId];
  const categories = Object.entries(STYLE_CATEGORIES);

  return (
    <div style={{ position: "relative" }}>
      {/* Trigger Button */}
      <button
        onClick={onToggle}
        style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "5px 12px", border: `1px solid ${style.color}40`,
          borderRadius: 4, background: `${style.color}10`,
          cursor: "pointer", fontFamily: "inherit", transition: "all 0.2s ease"
        }}
      >
        <span style={{ fontSize: 13, color: style.color }}>{style.icon}</span>
        <span style={{ fontSize: 10, fontWeight: 700, color: style.color, letterSpacing: 0.6 }}>{style.name.toUpperCase()}</span>
        <span style={{ fontSize: 8, color: C.textMuted, transform: expanded ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s" }}>&#9660;</span>
      </button>

      {/* Dropdown Panel */}
      {expanded && (
        <div style={{
          position: "absolute", top: "calc(100% + 6px)", right: 0,
          width: 520, background: C.card, border: `1px solid ${C.border}`,
          borderRadius: 8, boxShadow: "0 12px 40px rgba(0,0,0,0.6)",
          zIndex: 100, animation: "fadeUp 0.15s ease", overflow: "hidden"
        }}>
          {/* Current Style Summary */}
          <div style={{ padding: "14px 16px", borderBottom: `1px solid ${C.border}`, background: `${style.color}08` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
              <span style={{ fontSize: 22, color: style.color }}>{style.icon}</span>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: style.color }}>{style.name}</div>
                <div style={{ fontSize: 9, color: C.textDim }}>{style.short}</div>
              </div>
            </div>
            <div style={{ fontSize: 10, color: C.text, lineHeight: 1.6, fontFamily: "'IBM Plex Sans', sans-serif" }}>{style.description}</div>

            {/* Active Parameters */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, marginTop: 10 }}>
              {[
                ["Trend", `${style.weights.trend}%`],
                ["Tech", `${style.weights.tech}%`],
                ["Fund", `${style.weights.fund}%`],
                ["DWA", `${style.weights.dwa}%`],
              ].map(([l, v]) => (
                <div key={l} style={{ textAlign: "center", padding: "4px", background: C.bg, borderRadius: 3 }}>
                  <div style={{ fontSize: 8, color: C.textMuted, letterSpacing: 0.5 }}>{l}</div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: style.color }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 6, fontSize: 9 }}>
              <span style={{ color: C.textDim }}>Band: <span style={{ color: C.text }}>Â±{style.rebalanceBand}%</span></span>
              <span style={{ color: C.textDim }}>Max Cash: <span style={{ color: C.text }}>{style.cashMax}%</span></span>
              <span style={{ color: C.textDim }}>Hedge: <span style={{ color: C.text }}>{style.hedgeMultiplier}x</span></span>
              {style.invertSignals && <span style={{ color: C.magenta, fontWeight: 700 }}>INVERTED SIGNALS</span>}
            </div>
          </div>

          {/* Style Grid */}
          <div style={{ maxHeight: 340, overflow: "auto", padding: "8px" }}>
            {categories.map(([catId, cat]) => (
              <div key={catId} style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: 1.4, color: C.textMuted, padding: "4px 8px", textTransform: "uppercase" }}>
                  {cat.label}
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
                  {Object.values(INVESTOR_STYLES).filter(s => s.category === catId).map(s => (
                    <button
                      key={s.id}
                      onClick={() => { onChange(s.id); onToggle(); }}
                      style={{
                        display: "flex", alignItems: "center", gap: 8,
                        padding: "8px 10px", border: `1px solid ${s.id === styleId ? s.color + "60" : C.border}`,
                        borderRadius: 4, background: s.id === styleId ? `${s.color}15` : "transparent",
                        cursor: "pointer", fontFamily: "inherit", textAlign: "left",
                        transition: "all 0.15s ease"
                      }}
                    >
                      <span style={{ fontSize: 16, color: s.color, minWidth: 20, textAlign: "center" }}>{s.icon}</span>
                      <div>
                        <div style={{ fontSize: 10, fontWeight: 600, color: s.id === styleId ? s.color : C.text }}>{s.name}</div>
                        <div style={{ fontSize: 8, color: C.textDim, lineHeight: 1.3 }}>{s.short}</div>
                      </div>
                      {s.id === styleId && <span style={{ marginLeft: "auto", fontSize: 10, color: s.color }}>&#10003;</span>}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// STYLE IMPACT BAR â€” Shows active parameter changes vs default
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function StyleImpactBar({ styleId }) {
  const style = INVESTOR_STYLES[styleId];
  const dflt = INVESTOR_STYLES.balanced;
  if (styleId === "balanced") return null;

  const diffs = [];
  if (style.weights.trend !== dflt.weights.trend) diffs.push({ label: "Trend", from: dflt.weights.trend, to: style.weights.trend, unit: "%" });
  if (style.weights.tech !== dflt.weights.tech) diffs.push({ label: "Tech", from: dflt.weights.tech, to: style.weights.tech, unit: "%" });
  if (style.weights.fund !== dflt.weights.fund) diffs.push({ label: "Fund", from: dflt.weights.fund, to: style.weights.fund, unit: "%" });
  if (style.weights.dwa !== dflt.weights.dwa) diffs.push({ label: "DWA", from: dflt.weights.dwa, to: style.weights.dwa, unit: "%" });
  if (style.thresholds.strongBuy !== dflt.thresholds.strongBuy) diffs.push({ label: "SB Thresh", from: dflt.thresholds.strongBuy, to: style.thresholds.strongBuy });
  if (style.rebalanceBand !== dflt.rebalanceBand) diffs.push({ label: "Rebal Band", from: dflt.rebalanceBand, to: style.rebalanceBand, unit: "%" });

  return (
    <div style={{
      background: `${style.color}06`, borderBottom: `1px solid ${style.color}20`,
      padding: "5px 20px", display: "flex", alignItems: "center", gap: 12,
      animation: "fadeUp 0.2s ease"
    }}>
      <span style={{ fontSize: 9, fontWeight: 700, color: style.color, letterSpacing: 1 }}>
        {style.icon} {style.name.toUpperCase()} ACTIVE
      </span>
      <span style={{ width: 1, height: 14, background: C.border }} />
      <div style={{ display: "flex", gap: 12, fontSize: 9, overflow: "auto" }}>
        {diffs.map((d, i) => {
          const delta = d.to - d.from;
          return (
            <span key={i} style={{ whiteSpace: "nowrap" }}>
              <span style={{ color: C.textDim }}>{d.label}: </span>
              <span style={{ color: delta > 0 ? C.green : delta < 0 ? C.red : C.textDim }}>
                {delta > 0 ? "+" : ""}{delta}{d.unit || ""}
              </span>
            </span>
          );
        })}
        {style.invertSignals && <span style={{ color: C.magenta, fontWeight: 700 }}>CONTRARIAN INVERSION</span>}
      </div>
      <span style={{ marginLeft: "auto", fontSize: 8, color: C.textDim }}>AI persona: {style.persona}</span>
    </div>
  );
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// MAIN APPLICATION
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

export default function MarlineIntelligence() {
  const [tab, setTab] = useState("daily");
  const [ycKey, setYcKey] = useState("");
  const [ycPaste, setYcPaste] = useState("");
  const [showConfig, setShowConfig] = useState(false);
  const [showStyleSelector, setShowStyleSelector] = useState(false);

  // INVESTOR STYLE STATE
  const [styleId, setStyleId] = useState("balanced");
  const [rawYcData, setRawYcData] = useState(null); // store raw data for re-enrichment on style change

  const [ycEnriched, setYcEnriched] = useState(null);
  const [portMetrics, setPortMetrics] = useState(null);
  const [aiDaily, setAiDaily] = useState(null);
  const [aiEquity, setAiEquity] = useState(null);
  const [aiPortfolio, setAiPortfolio] = useState(null);

  const [loading, setLoading] = useState({});
  const [errors, setErrors] = useState({});
  const [timestamps, setTs] = useState({});
  const [progress, setProgress] = useState({});
  const [toolLog, setToolLog] = useState([]);

  const currentStyle = INVESTOR_STYLES[styleId];


  // PORTFOLIO COMPARISON STATE
  const [compPortfolios, setCompPortfolios] = useState([
    { id: 1, name: "Portfolio A", rawInput: "", holdings: [], totalWeight: 0 },
  ]);
  const [compBenchmarks, setCompBenchmarks] = useState(["spy"]);
  const [investorBeliefs, setInvestorBeliefs] = useState({ riskTolerance: "moderate", incomeNeed: "none", timeHorizon: "medium", styleTilt: "blend", convictionThemes: [] });
  const [mgmtBeliefs, setMgmtBeliefs] = useState({ fsmSignal: "invested", regimeView: "neutral", dwaStrength: "mixed", volatilityRegime: "moderate", cashTrigger: "off" });
  const [compScores, setCompScores] = useState(null);
  const [compAiResult, setCompAiResult] = useState(null);
  const [compSubView, setCompSubView] = useState("setup");
  const [compExtraData, setCompExtraData] = useState(null);

  // RE-ENRICH when style changes (re-score everything)
  useEffect(() => {
    if (rawYcData && Object.keys(rawYcData).length > 0) {
      const enriched = computeDerivedMetrics(rawYcData, styleId);
      setYcEnriched(enriched);
      setPortMetrics(computePortfolioMetrics(enriched, styleId));
    }
  }, [styleId, rawYcData]);

  const loadYCharts = useCallback(async () => {
    setLoading(p => ({ ...p, ycharts: true }));
    setErrors(p => ({ ...p, ycharts: null }));
    try {
      let data = null;
      if (ycKey.trim()) data = await fetchYChartsData(ycKey.trim());
      if (!data && ycPaste.trim()) data = parseYChartsPaste(ycPaste.trim());
      if (data && Object.keys(data).length > 0) {
        setRawYcData(data); // store raw for style re-enrichment
        const enriched = computeDerivedMetrics(data, styleId);
        setYcEnriched(enriched);
        setPortMetrics(computePortfolioMetrics(enriched, styleId));
        setTs(p => ({ ...p, ycharts: new Date().toLocaleString() }));
      } else {
        setErrors(p => ({ ...p, ycharts: "No data retrieved." }));
      }
    } catch (e) { setErrors(p => ({ ...p, ycharts: e.message })); }
    setLoading(p => ({ ...p, ycharts: false }));
  }, [ycKey, ycPaste, styleId]);

  // â€” Style-Aware Report Runner â€”
  const runReport = useCallback(async (type) => {
    const key = type;
    setLoading(p => ({ ...p, [key]: true }));
    setErrors(p => ({ ...p, [key]: null }));
    setToolLog([]);
    setProgress({});

    const onProgress = (info) => {
      setProgress(info);
      if (info.tool || info.phase === "web_search") {
        setToolLog(prev => [...prev, { time: new Date().toLocaleTimeString(), ...info }]);
      }
    };

    try {
      const result = await runAgenticAnalysis(ycEnriched || {}, portMetrics, type, styleId, onProgress);
      if (result) {
        if (type === "daily") setAiDaily(result);
        else if (type === "equity") setAiEquity(result);
        else setAiPortfolio(result);
        setTs(p => ({ ...p, [key]: new Date().toLocaleString() }));
      } else {
        setErrors(p => ({ ...p, [key]: "Analysis returned empty â€” retry" }));
      }
    } catch (e) { setErrors(p => ({ ...p, [key]: e.message })); }
    setLoading(p => ({ ...p, [key]: false }));
  }, [ycEnriched, portMetrics, styleId]);


  // — Comparison Helper Functions —
  const addCompPortfolio = () => {
    if (compPortfolios.length >= 10) return;
    const nextId = Math.max(0, ...compPortfolios.map(p => p.id)) + 1;
    setCompPortfolios(p => [...p, { id: nextId, name: `Portfolio ${String.fromCharCode(65 + p.length)}`, rawInput: "", holdings: [], totalWeight: 0 }]);
  };

  const removeCompPortfolio = (id) => {
    if (compPortfolios.length <= 1) return;
    setCompPortfolios(p => p.filter(x => x.id !== id));
  };

  const updateCompPortfolio = (id, updated) => {
    setCompPortfolios(p => p.map(x => x.id === id ? { ...x, ...updated } : x));
  };

  const computeCompScores = useCallback(() => {
    const mergedData = { ...(ycEnriched || {}), ...(compExtraData || {}) };
    if (compExtraData && Object.keys(compExtraData).length > 0) {
      const enrichedExtra = computeDerivedMetrics(compExtraData, styleId);
      Object.assign(mergedData, enrichedExtra);
    }
    const results = compPortfolios.filter(p => p.holdings?.length > 0).map((p, i) => {
      const scores = scorePortfolioVsBeliefs(p.holdings, mergedData, investorBeliefs, mgmtBeliefs);
      let signals = { strongBuy: 0, buy: 0, hold: 0, sell: 0, strongSell: 0 };
      (p.holdings || []).forEach(h => {
        const sig = mergedData[h.ticker]?.signal;
        if (sig === "STRONG BUY") signals.strongBuy++;
        else if (sig === "BUY") signals.buy++;
        else if (sig === "SELL") signals.sell++;
        else if (sig === "STRONG SELL") signals.strongSell++;
        else signals.hold++;
      });
      return { id: p.id, name: p.name, color: PORTFOLIO_COLORS[i % 10], holdings: p.holdings, scores, signals, mergedData };
    });
    const winners = {};
    const metricKeys = ["wtdReturn","wtdSharpe","wtdVol","wtdDrawdown","wtdYield","wtd1M","wtd3M","wtd6M","wtd3Y","wtd5Y"];
    const goodDir = { wtdReturn:"high", wtdSharpe:"high", wtdVol:"low", wtdDrawdown:"high", wtdYield:"high", wtd1M:"high", wtd3M:"high", wtd6M:"high", wtd3Y:"high", wtd5Y:"high" };
    for (const mk of metricKeys) {
      let best = null;
      for (const r of results) {
        const val = r.scores?.metrics?.[mk];
        if (val == null) continue;
        if (!best || (goodDir[mk] === "high" ? val > best.val : val < best.val)) best = { id: r.id, name: r.name, color: r.color, val };
      }
      if (best) winners[mk] = best;
    }
    let bestOverall = null;
    for (const r of results) { if (!bestOverall || (r.scores?.overall || 0) > (bestOverall.scores?.overall || 0)) bestOverall = r; }
    setCompScores({ portfolios: results, winners, bestOverall });
  }, [compPortfolios, ycEnriched, compExtraData, investorBeliefs, mgmtBeliefs, styleId]);

  const loadComparisonData = useCallback(async () => {
    const extraTickers = new Set();
    compPortfolios.forEach(p => (p.holdings || []).forEach(h => {
      if (h.ticker && !HOLDINGS.find(x => x.ticker === h.ticker)) extraTickers.add(h.ticker);
    }));
    if (extraTickers.size === 0) { computeCompScores(); return; }
    setLoading(p => ({ ...p, compData: true }));
    try {
      if (ycKey.trim()) {
        const tickers = [...extraTickers].join(",");
        const extraData = {};
        for (const metric of YCHART_METRICS) {
          try {
            const resp = await fetch(`https://api.ycharts.com/v4/companies/${tickers}/points/${metric}`,
              { headers: { "X-YCHARTSAUTHORIZATION": ycKey.trim(), "Accept": "application/json" } });
            if (resp.ok) {
              const data = await resp.json();
              if (data?.response) {
                for (const item of data.response) {
                  const t = item?.meta?.identifier;
                  if (t) { if (!extraData[t]) extraData[t] = {}; extraData[t][metric] = item?.data?.[0]?.[1] ?? null; }
                }
              }
            }
          } catch (e) { /* metric fetch error */ }
        }
        if (Object.keys(extraData).length > 0) setCompExtraData(extraData);
      } else {
        const tickerList = [...extraTickers].join(", ");
        try {
          const resp = await fetch(API_URL, {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: MODEL, max_tokens: 4000,
              tools: [{ type: "web_search_20250305", name: "web_search" }],
              messages: [{ role: "user", content: `Get current market data for these tickers: ${tickerList}. For each, return a JSON object keyed by ticker with: price (number), one_year_return (decimal e.g. 0.12 for 12%), one_year_volatility (decimal), beta_5_year (number), max_drawdown_3_year (decimal negative), dividend_yield (decimal), one_month_return (decimal), three_month_return (decimal), six_month_return (decimal), three_year_annualized_return (decimal), five_year_annualized_return (decimal). Return ONLY JSON, no markdown or explanation.` }]
            })
          });
          const data = await resp.json();
          const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");
          const clean = text.replace(/```json|```/g, "").trim();
          const match = clean.match(/\{[\s\S]*\}/);
          if (match) { try { setCompExtraData(JSON.parse(match[0])); } catch (e) { /* parse */ } }
        } catch (e) { /* ai fetch */ }
      }
    } catch (e) { setErrors(p => ({ ...p, compData: e.message })); }
    setLoading(p => ({ ...p, compData: false }));
    computeCompScores();
  }, [compPortfolios, ycKey, computeCompScores]);

  useEffect(() => {
    if (compPortfolios.some(p => p.holdings?.length > 0) && (ycEnriched || compExtraData)) {
      computeCompScores();
    }
  }, [compPortfolios, ycEnriched, compExtraData, investorBeliefs, mgmtBeliefs, styleId, computeCompScores]);

  const runComparisonAI = useCallback(async () => {
    if (!compScores || compScores.portfolios.length === 0) return;
    setLoading(p => ({ ...p, compare: true }));
    setErrors(p => ({ ...p, compare: null }));
    setToolLog([]);
    setProgress({});
    const mergedData = { ...(ycEnriched || {}), ...(compExtraData || {}) };
    if (compExtraData) Object.assign(mergedData, computeDerivedMetrics(compExtraData, styleId));
    const onProg = (info) => { setProgress(info); if (info.tool) setToolLog(prev => [...prev, { time: new Date().toLocaleTimeString(), ...info }]); };
    try {
      const result = await runComparisonAnalysis(compScores.portfolios, mergedData, portMetrics, investorBeliefs, mgmtBeliefs, styleId, onProg);
      if (result) { setCompAiResult(result); setCompSubView("results"); }
      else setErrors(p => ({ ...p, compare: "Analysis returned empty result" }));
    } catch (e) { setErrors(p => ({ ...p, compare: e.message })); }
    setLoading(p => ({ ...p, compare: false }));
  }, [compScores, ycEnriched, compExtraData, portMetrics, investorBeliefs, mgmtBeliefs, styleId]);

  const hasYCData = ycEnriched && Object.keys(ycEnriched).length > 0;
  const isLoading = loading.daily || loading.equity || loading.portfolio || loading.compare || loading.compData;

  return (
    <div style={{ fontFamily: "'IBM Plex Mono', 'Fira Code', monospace", background: C.bg, color: C.text, minHeight: "100vh" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500;600;700&family=IBM+Plex+Sans:wght@300;400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.2; } }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: ${C.bg}; }
        ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 2px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 6px 8px; text-align: center; border-bottom: 1px solid ${C.border}; font-size: 11px; }
        th { background: ${C.header}; color: ${C.textDim}; font-weight: 600; font-size: 9px; letter-spacing: 0.8px; text-transform: uppercase; position: sticky; top: 0; }
        textarea { font-family: inherit; font-size: 11px; background: ${C.card}; color: ${C.text}; border: 1px solid ${C.border}; border-radius: 4px; padding: 8px; width: 100%; resize: vertical; }
        input[type="text"] { font-family: inherit; font-size: 11px; background: ${C.card}; color: ${C.text}; border: 1px solid ${C.border}; border-radius: 4px; padding: 6px 10px; width: 100%; }
      `}</style>

      {/* â•â•â• HEADER â•â•â• */}
      <div style={{ background: C.header, borderBottom: `1px solid ${C.border}`, padding: "0 20px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", height: 52 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div>
              <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: 4, color: C.accent }}>MARLINE</span>
              <span style={{ fontSize: 9, fontWeight: 300, letterSpacing: 2, color: C.textDim, marginLeft: 6 }}>INTELLIGENCE v4</span>
            </div>
            <div style={{ height: 20, width: 1, background: C.border }} />
            <div style={{ fontSize: 9, color: C.textDim }}>
              <StatusDot active={hasYCData} color={C.green} />
              <span style={{ color: hasYCData ? C.green : C.textMuted }}>YCHARTS {hasYCData ? "LIVE" : "OFFLINE"}</span>
              <span style={{ margin: "0 6px", color: C.textMuted }}>|</span>
              <StatusDot active={true} color={C.blue} />
              <span style={{ color: C.blue }}>AI AGENTIC</span>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {/* INVESTOR STYLE SELECTOR */}
            <StyleSelector
              styleId={styleId}
              onChange={setStyleId}
              expanded={showStyleSelector}
              onToggle={() => { setShowStyleSelector(!showStyleSelector); setShowConfig(false); }}
            />
            <span style={{ fontSize: 10, color: C.accent }}>{new Date().toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}</span>
            <button onClick={() => { setShowConfig(!showConfig); setShowStyleSelector(false); }} style={{ padding: "4px 10px", border: `1px solid ${C.border}`, borderRadius: 3, background: showConfig ? C.accent + "20" : "transparent", color: showConfig ? C.accent : C.textDim, fontSize: 10, cursor: "pointer", fontFamily: "inherit" }}>&#9881;</button>
          </div>
        </div>
        <div style={{ display: "flex" }}>
          {[{ id: "daily", label: "Market Report", icon: "\u25C9" }, { id: "equity", label: "Equity Analysis", icon: "\u25C8" }, { id: "portfolio", label: "Portfolio Report", icon: "◆" }, { id: "compare", label: "Compare", icon: "\u25C6" }].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: "8px 18px", border: "none", cursor: "pointer", fontSize: 10, fontWeight: 600, letterSpacing: 0.8, fontFamily: "inherit", background: "transparent", color: tab === t.id ? C.accent : C.textMuted, borderBottom: tab === t.id ? `2px solid ${C.accent}` : "2px solid transparent" }}>
              <span style={{ marginRight: 5, opacity: 0.7 }}>{t.icon}</span>{t.label}
            </button>
          ))}
        </div>
      </div>

      {/* â•â•â• STYLE IMPACT BAR â•â•â• */}
      <StyleImpactBar styleId={styleId} />

      {/* â•â•â• CONFIG â•â•â• */}
      {showConfig && (
        <div style={{ background: C.header, borderBottom: `1px solid ${C.border}`, padding: "14px 20px", animation: "fadeUp 0.2s ease" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr auto", gap: 14, alignItems: "start" }}>
            <div>
              <div style={{ fontSize: 10, fontWeight: 700, color: C.accent, letterSpacing: 1, marginBottom: 6 }}>YCHARTS API KEY</div>
              <input type="text" value={ycKey} onChange={e => setYcKey(e.target.value)} placeholder="Enter API key..." />
            </div>
            <div>
              <div style={{ fontSize: 10, fontWeight: 700, color: C.accent, letterSpacing: 1, marginBottom: 6 }}>OR PASTE YCHARTS EXPORT</div>
              <textarea value={ycPaste} onChange={e => setYcPaste(e.target.value)} rows={3} placeholder="Paste CSV/TSV from YCharts Comp Tables..." />
            </div>
            <div style={{ paddingTop: 18 }}>
              <Btn onClick={loadYCharts} loading={loading.ycharts} accent={C.green}>{loading.ycharts ? "\u27F3 LOADING..." : "\u27F3 LOAD DATA"}</Btn>
              {errors.ycharts && <div style={{ fontSize: 9, color: C.red, marginTop: 4, maxWidth: 180 }}>{errors.ycharts}</div>}
              {timestamps.ycharts && <div style={{ fontSize: 9, color: C.green, marginTop: 4 }}>{"\u2713"} {timestamps.ycharts}</div>}
            </div>
          </div>
        </div>
      )}

      {/* â•â•â• YCharts Ticker Bar â•â•â• */}
      {hasYCData && (
        <div style={{ background: `${C.green}08`, borderBottom: `1px solid ${C.green}20`, padding: "5px 20px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", gap: 18, fontSize: 10 }}>
            {["SPY", "QQQ", "IWM", "AGG", "GLD"].map(t => {
              const d = ycEnriched[t];
              return d?.price ? (
                <span key={t}><span style={{ color: C.textDim, marginRight: 4 }}>{t}</span><span style={{ fontWeight: 600 }}>{usd(d.price)}</span><span style={{ color: (d.one_month_return || 0) >= 0 ? C.green : C.red, marginLeft: 4, fontSize: 9 }}>{pctFmt(d.one_month_return)}</span></span>
              ) : null;
            })}
          </div>
          <div style={{ fontSize: 9, color: C.textDim }}>{Object.keys(ycEnriched).length} securities {"\u00B7"} {timestamps.ycharts}</div>
        </div>
      )}

      {/* â•â•â• MAIN CONTENT â•â•â• */}
      <div style={{ padding: "14px 20px" }}>
        {/* Controls */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ display: "flex", gap: 8, fontSize: 9 }}>
            <span style={{ padding: "3px 8px", borderRadius: 3, background: hasYCData ? `${C.green}15` : `${C.amber}15`, border: `1px solid ${hasYCData ? C.green : C.amber}30`, color: hasYCData ? C.green : C.amber }}>
              L1: {hasYCData ? `YCHARTS \u2713 ${HOLDINGS.filter(h => ycEnriched[h.ticker]).length}/${HOLDINGS.length}` : "Configure \u2699"}
            </span>
            <span style={{ padding: "3px 8px", borderRadius: 3, background: `${currentStyle.color}15`, border: `1px solid ${currentStyle.color}30`, color: currentStyle.color }}>
              {currentStyle.icon} {currentStyle.name.toUpperCase()} MODE
            </span>
            <span style={{ padding: "3px 8px", borderRadius: 3, background: `${C.purple}15`, border: `1px solid ${C.purple}30`, color: C.purple }}>
              L2: {currentStyle.persona.toUpperCase()}
            </span>
          </div>
          <Btn onClick={() => runReport(tab)} loading={loading[tab]}>
            {loading[tab] ? `\u27F3 ${progress.message || "ANALYZING..."}` : `\u27F3 GENERATE ${tab.toUpperCase()} REPORT`}
          </Btn>
        </div>

        {/* â•â•â• AGENTIC TOOL LOG â•â•â• */}
        {(isLoading || toolLog.length > 0) && (
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, padding: "10px 14px", marginBottom: 12, borderLeft: `2px solid ${currentStyle.color}` }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: currentStyle.color, letterSpacing: 1.2, marginBottom: 6 }}>
              {currentStyle.icon} {currentStyle.persona.toUpperCase()} ACTIVITY LOG {isLoading && <span style={{ animation: "pulse 1s infinite", marginLeft: 6 }}>{"\u25CF"}</span>}
            </div>
            <div style={{ maxHeight: 120, overflow: "auto" }}>
              {toolLog.map((entry, i) => (
                <div key={i} style={{ fontSize: 10, padding: "2px 0", borderBottom: `1px solid ${C.border}`, display: "flex", gap: 8, alignItems: "center" }}>
                  <span style={{ color: C.textMuted, fontSize: 9, minWidth: 55 }}>{entry.time}</span>
                  <span style={{ color: entry.phase === "web_search" ? C.blue : entry.phase === "tool_call" ? C.green : C.textDim }}>
                    {entry.phase === "web_search" ? "\uD83C\uDF10" : entry.phase === "tool_call" ? "\uD83D\uDCCA" : "\u27F3"}
                  </span>
                  <span style={{ color: entry.phase === "web_search" ? C.blue : C.green, fontWeight: 600, fontSize: 9 }}>{entry.tool || ""}</span>
                  <span style={{ color: C.text, fontSize: 10 }}>{entry.message}</span>
                </div>
              ))}
              {isLoading && progress.message && (
                <div style={{ fontSize: 10, color: currentStyle.color, padding: "3px 0" }}>{"\u2192"} {progress.message}</div>
              )}
            </div>
          </div>
        )}

        {/* â•â•â• DAILY â•â•â• */}
        {tab === "daily" && aiDaily && (
          <div style={{ animation: "fadeUp 0.25s ease" }}>
            {hasYCData && portMetrics && (
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.green, letterSpacing: 1.4, marginBottom: 6 }}>LAYER 1 {"\u2014"} YCHARTS QUANTITATIVE ({currentStyle.name.toUpperCase()} SCORING)</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8 }}>
                  {[
                    ["FSM Signal", portMetrics.fsmSignal, sigColor(portMetrics.fsmSignal)],
                    ["Bullish %", `${(portMetrics.bullishPct * 100).toFixed(0)}%`, portMetrics.bullishPct > 0.5 ? C.green : C.red],
                    ["Wtd Return", pctFmt(portMetrics.wtdReturn), portMetrics.wtdReturn >= 0 ? C.green : C.red],
                    ["Wtd Vol", pctFmt(portMetrics.wtdVol), C.text],
                    ["Wtd Sharpe", n(portMetrics.wtdSharpe), portMetrics.wtdSharpe > 0.5 ? C.green : C.amber],
                    ["Composite", `${portMetrics.avgComposite.toFixed(0)}/100`, portMetrics.avgComposite >= 60 ? C.green : portMetrics.avgComposite >= 40 ? C.amber : C.red],
                  ].map(([l, v, c]) => (
                    <div key={l} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 4, padding: "8px", textAlign: "center" }}>
                      <div style={{ fontSize: 9, color: C.textDim, marginBottom: 2 }}>{l}</div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: c }}>{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div style={{ fontSize: 9, fontWeight: 700, color: currentStyle.color, letterSpacing: 1.4, marginBottom: 6 }}>LAYER 2 {"\u2014"} {currentStyle.persona.toUpperCase()} INTERPRETATION</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
              <Card title="Regime Assessment" accent={sigColor(aiDaily.regimeAssessment?.regime)} row={2}>
                <div style={{ fontSize: 30, fontWeight: 700, color: sigColor(aiDaily.regimeAssessment?.regime), lineHeight: 1, marginBottom: 4 }}>{aiDaily.regimeAssessment?.regime}</div>
                <div style={{ fontSize: 10, color: C.textDim, marginBottom: 8 }}>Confidence: <span style={{ color: sigColor(aiDaily.regimeAssessment?.confidence) }}>{aiDaily.regimeAssessment?.confidence}</span></div>
                <Gauge value={aiDaily.regimeAssessment?.regimeScore} label="Regime Score" color={sigColor(aiDaily.regimeAssessment?.regime)} />
                <Gauge value={aiDaily.regimeAssessment?.recessionProbability} label="Recession Prob" color={aiDaily.regimeAssessment?.recessionProbability > 35 ? C.red : C.green} />
                {["trendDirection","volatilityRegime","breadthAssessment","momentumRegime","creditConditions","selloffRisk"].map(k => (
                  <Metric key={k} label={k.replace(/([A-Z])/g," $1").trim()} value={aiDaily.regimeAssessment?.[k]} color={sigColor(aiDaily.regimeAssessment?.[k])} />
                ))}
                <div style={{ marginTop: 8, fontSize: 10, color: C.textDim, lineHeight: 1.6, padding: 8, background: C.bg, borderRadius: 3 }}>{aiDaily.regimeAssessment?.rationale}</div>
              </Card>

              <Card title="Business Cycle" accent={C.purple} row={2}>
                <div style={{ fontSize: 20, fontWeight: 700, color: sigColor(aiDaily.cycleDiagnosis?.currentCycle), marginBottom: 4 }}>{aiDaily.cycleDiagnosis?.currentCycle}</div>
                <div style={{ fontSize: 10, color: C.textDim, marginBottom: 8 }}>{aiDaily.cycleDiagnosis?.cycleAge}</div>
                <Metric label="Transition Risk" value={aiDaily.cycleDiagnosis?.transitionRisk} color={sigColor(aiDaily.cycleDiagnosis?.transitionRisk)} />
                <Metric label="Next Phase" value={aiDaily.cycleDiagnosis?.nextPhaseETA} />
                <Metric label="Analog" value={aiDaily.cycleDiagnosis?.historicalAnalog} />
                <div style={{ marginTop: 6, fontSize: 10, color: C.textDim, lineHeight: 1.5 }}><span style={{ fontWeight: 600, color: C.purple }}>Leading Indicators:</span> {aiDaily.cycleDiagnosis?.leadingIndicators}</div>
                {aiDaily.sectorRotation && (<div style={{ marginTop: 8 }}>
                  <div style={{ fontSize: 9, fontWeight: 600, color: C.purple, marginBottom: 3 }}>Sector Rotation</div>
                  <div style={{ fontSize: 10, color: C.green }}>Favored: {aiDaily.sectorRotation.favored?.join(", ")}</div>
                  <div style={{ fontSize: 10, color: C.red }}>Disfavored: {aiDaily.sectorRotation.disfavored?.join(", ")}</div>
                  <div style={{ fontSize: 9, color: C.textDim }}>{aiDaily.sectorRotation.rotationSignal}</div>
                </div>)}
              </Card>

              <Card title="Forward Outlook" accent={C.cyan} row={2}>
                {aiDaily.forwardOutlook && Object.entries(aiDaily.forwardOutlook).map(([period, text]) => (
                  <div key={period} style={{ marginBottom: 8, padding: "6px 8px", background: C.bg, borderRadius: 3, borderLeft: `2px solid ${period === "daily" ? C.cyan : period === "weekly" ? C.blue : period === "monthly" ? C.purple : C.accent}` }}>
                    <div style={{ fontSize: 9, fontWeight: 700, color: C.textDim, textTransform: "uppercase", marginBottom: 2 }}>{period}</div>
                    <div style={{ fontSize: 10, color: C.text, lineHeight: 1.5 }}>{text}</div>
                  </div>
                ))}
              </Card>

              <Card title={`${currentStyle.persona} Narrative`} accent={currentStyle.color} span={2}>
                <p style={{ fontSize: 12, lineHeight: 1.8, color: C.text, margin: 0, fontFamily: "'IBM Plex Sans', sans-serif" }}>{aiDaily.marketNarrative}</p>
              </Card>

              <Card title={`Risks \u00B7 Catalysts \u00B7 Actions`} accent={C.amber}>
                {aiDaily.keyRisks?.map((r, i) => (
                  <div key={i} style={{ fontSize: 10, padding: "3px 0", borderBottom: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: C.red }}>{"\u26A0"} {r.risk || r}</span>
                    {r.probability && <Pill color={sigColor(r.probability)}>{r.probability}</Pill>}
                  </div>
                ))}
                <div style={{ marginTop: 6, fontSize: 9, fontWeight: 700, color: C.green, letterSpacing: 0.8 }}>CATALYSTS</div>
                {aiDaily.catalysts?.map((c, i) => <div key={i} style={{ fontSize: 10, color: C.text, padding: "2px 0", borderBottom: `1px solid ${C.border}` }}>{"\u25B8"} {c}</div>)}
                <div style={{ marginTop: 6, fontSize: 9, fontWeight: 700, color: C.blue, letterSpacing: 0.8 }}>ACTIONS</div>
                {aiDaily.portfolioActions?.map((a, i) => (
                  <div key={i} style={{ fontSize: 10, padding: "3px 0", borderBottom: `1px solid ${C.border}` }}>
                    <span style={{ color: C.text }}>{a.action || a}</span>
                    {a.urgency && <span style={{ marginLeft: 6 }}><Pill color={sigColor(a.urgency)}>{a.urgency}</Pill></span>}
                  </div>
                ))}
              </Card>
            </div>
          </div>
        )}

        {/* â•â•â• EQUITY â•â•â• */}
        {tab === "equity" && (
          <div style={{ animation: "fadeUp 0.25s ease" }}>
            {hasYCData && (
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.green, letterSpacing: 1.4, marginBottom: 6 }}>LAYER 1 {"\u2014"} YCHARTS ({currentStyle.name.toUpperCase()} WEIGHTS: T{currentStyle.weights.trend}/TC{currentStyle.weights.tech}/F{currentStyle.weights.fund}/D{currentStyle.weights.dwa})</div>
                <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, overflow: "auto", maxHeight: 320 }}>
                  <table>
                    <thead><tr>{["Ticker", "Price", "1Y", "Vol", "Beta", "Sharpe", "1M", "3M", "Comp", "BB%B", "Wave", "Signal"].map(h => <th key={h}>{h}</th>)}</tr></thead>
                    <tbody>
                      {HOLDINGS.map(h => { const d = ycEnriched[h.ticker]; if (!d) return null; return (
                        <tr key={h.ticker} style={{ background: d.signal?.includes("BUY") ? `${C.green}06` : d.signal?.includes("SELL") ? `${C.red}06` : "transparent" }}>
                          <td style={{ fontWeight: 700, color: C.text }}>{h.ticker}</td>
                          <td>{d.price ? usd(d.price) : "\u2014"}</td>
                          <td style={{ color: (d.one_year_return||0) >= 0 ? C.green : C.red }}>{pctFmt(d.one_year_return)}</td>
                          <td>{pctFmt(d.one_year_volatility)}</td>
                          <td>{n(d.beta_5_year)}</td>
                          <td style={{ color: (d.sharpe||0) > 0.5 ? C.green : C.textDim }}>{n(d.sharpe)}</td>
                          <td style={{ color: (d.one_month_return||0) >= 0 ? C.green : C.red }}>{pctFmt(d.one_month_return)}</td>
                          <td style={{ color: (d.three_month_return||0) >= 0 ? C.green : C.red }}>{pctFmt(d.three_month_return)}</td>
                          <td style={{ fontWeight: 700, color: (d.composite||0) >= 60 ? C.green : (d.composite||0) <= 40 ? C.red : C.amber }}>{d.composite || "\u2014"}</td>
                          <td>{d.bbPercentB != null ? n(d.bbPercentB) : "\u2014"}</td>
                          <td><Pill color={sigColor(d.wavePhase)}>{d.wavePhase || "\u2014"}</Pill></td>
                          <td><Pill color={sigColor(d.signal)}>{d.signal}</Pill></td>
                        </tr>
                      ); })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            {aiEquity && (
              <div>
                <div style={{ fontSize: 9, fontWeight: 700, color: currentStyle.color, letterSpacing: 1.4, marginBottom: 4 }}>LAYER 2 {"\u2014"} {currentStyle.persona.toUpperCase()}</div>
                {aiEquity.marketContext && <div style={{ fontSize: 11, color: C.text, lineHeight: 1.6, padding: "8px 12px", background: C.card, borderRadius: 4, marginBottom: 8, borderLeft: `2px solid ${currentStyle.color}`, fontFamily: "'IBM Plex Sans', sans-serif" }}>{aiEquity.marketContext}</div>}
                <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, overflow: "auto" }}>
                  <table>
                    <thead><tr>{[hasYCData && "YC", "Ticker", "AI Signal", "Tech", "Fund", "Catalyst", "RS", "Conv", "Bollinger", "Wave", "News", "Action"].filter(Boolean).map(h => <th key={h}>{h}</th>)}</tr></thead>
                    <tbody>
                      {aiEquity.equities?.map((eq, i) => (
                        <tr key={i}>
                          {hasYCData && <td style={{ fontWeight: 600, color: sigColor(ycEnriched[eq.ticker]?.signal) }}>{ycEnriched[eq.ticker]?.composite || "\u2014"}</td>}
                          <td style={{ fontWeight: 700, color: C.text }}>{eq.ticker}</td>
                          <td><Pill color={sigColor(eq.analystSignal)}>{eq.analystSignal}</Pill></td>
                          <td><Pill color={sigColor(eq.technicalView)}>{eq.technicalView}</Pill></td>
                          <td><Pill color={sigColor(eq.fundamentalView)}>{eq.fundamentalView}</Pill></td>
                          <td><Pill color={sigColor(eq.catalystView)}>{eq.catalystView}</Pill></td>
                          <td><Pill color={sigColor(eq.relativeStrength)}>{eq.relativeStrength}</Pill></td>
                          <td style={{ color: sigColor(eq.conviction), fontWeight: 600, fontSize: 10 }}>{eq.conviction}</td>
                          <td style={{ fontSize: 9, color: C.textDim, textAlign: "left", maxWidth: 110 }}>{eq.bollingerRead}</td>
                          <td style={{ fontSize: 9, color: C.textDim, textAlign: "left", maxWidth: 110 }}>{eq.elliottWaveRead}</td>
                          <td style={{ fontSize: 9, color: C.textDim, textAlign: "left", maxWidth: 120 }}>{eq.newsContext}</td>
                          <td style={{ fontSize: 9, color: C.text, textAlign: "left", maxWidth: 130, fontFamily: "'IBM Plex Sans', sans-serif" }}>{eq.recommendation}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* â•â•â• PORTFOLIO â•â•â• */}
        {tab === "portfolio" && (aiPortfolio || hasYCData) && (
          <div style={{ animation: "fadeUp 0.25s ease", border: `1px solid ${C.border}`, borderRadius: 8, overflow: "hidden", background: C.bg }}>
            <div style={{ background: `linear-gradient(135deg, ${C.header}, ${C.card})`, padding: "18px 22px", borderBottom: `2px solid ${currentStyle.color}`, display: "flex", justifyContent: "space-between" }}>
              <div>
                <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: 5, color: C.accent }}>MARLINE WEALTH MANAGEMENT</div>
                <div style={{ fontSize: 18, fontWeight: 300, color: C.text, marginTop: 4, fontFamily: "'IBM Plex Sans', sans-serif" }}>Portfolio Analysis Report</div>
                <div style={{ fontSize: 10, color: C.textMuted, marginTop: 2 }}>
                  {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })} {"\u00B7"} {currentStyle.icon} {currentStyle.name} Mode {"\u00B7"} {hasYCData ? "YCharts Verified" : "AI Sourced"}
                </div>
              </div>
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 44, fontWeight: 700, color: sigColor(aiPortfolio?.portfolioGrade === "A" ? "BULLISH" : aiPortfolio?.portfolioGrade === "B" ? "BUY" : aiPortfolio?.portfolioGrade === "D" ? "BEARISH" : "CAUTIOUS"), lineHeight: 1 }}>{aiPortfolio?.portfolioGrade || "\u2014"}</div>
                <div style={{ fontSize: 9, color: C.textDim }}>GRADE</div>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 0 }}>
              <div style={{ padding: "14px 18px", borderRight: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.2, marginBottom: 8 }}>STYLE</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: C.text }}>{aiPortfolio?.styleAnalysis?.overallStyle || "\u2014"}</div>
                <div style={{ fontSize: 10, color: C.textDim, marginTop: 4 }}>Equity: {aiPortfolio?.styleAnalysis?.equityStyle}</div>
                <div style={{ fontSize: 10, color: C.textDim }}>Fixed Inc: {aiPortfolio?.styleAnalysis?.fixedIncomeStyle}</div>
                <div style={{ fontSize: 10, color: C.amber, marginTop: 4 }}>{"\u2605".repeat(aiPortfolio?.styleAnalysis?.riskLevel || 3)}{"\u2606".repeat(5 - (aiPortfolio?.styleAnalysis?.riskLevel || 3))}</div>
              </div>
              <div style={{ padding: "14px 18px", borderRight: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.2, marginBottom: 8 }}>PERFORMANCE {hasYCData && <span style={{ color: C.green }}>{"\u00B7"} YC</span>}</div>
                <Metric label="Return" value={hasYCData ? pctFmt(portMetrics.wtdReturn) : "\u2014"} color={C.green} large />
                <Metric label="Vol" value={hasYCData ? pctFmt(portMetrics.wtdVol) : "\u2014"} />
                <Metric label="Sharpe" value={hasYCData ? n(portMetrics.wtdSharpe) : "\u2014"} color={(portMetrics?.wtdSharpe || 0) > 0.5 ? C.green : C.amber} />
                <Metric label="Beta" value={hasYCData ? n(portMetrics.wtdBeta) : "\u2014"} />
              </div>
              <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.2, marginBottom: 8 }}>BENCHMARKS <span style={{ color: C.blue }}>{"\u00B7"} AI</span></div>
                {aiPortfolio?.benchmarkData ? <>
                  <Metric label="S&P 500 YTD" value={pctRaw(aiPortfolio.benchmarkData.sp500Ytd)} color={(aiPortfolio.benchmarkData.sp500Ytd||0) >= 0 ? C.green : C.red} />
                  <Metric label="Agg Bond YTD" value={pctRaw(aiPortfolio.benchmarkData.aggBondYtd)} color={(aiPortfolio.benchmarkData.aggBondYtd||0) >= 0 ? C.green : C.red} />
                  <Metric label="60/40 YTD" value={pctRaw(aiPortfolio.benchmarkData.sixtyFortyYtd)} />
                  <Metric label="vs S&P" value={pctRaw(aiPortfolio.benchmarkData.portfolioVsBenchmark)} color={(aiPortfolio.benchmarkData.portfolioVsBenchmark||0) >= 0 ? C.green : C.red} />
                </> : <div style={{ fontSize: 10, color: C.textMuted }}>Generate report for benchmarks</div>}
              </div>
              <div style={{ padding: "14px 18px", borderRight: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.2, marginBottom: 8 }}>ALLOCATION</div>
                {(() => { const g = {}; HOLDINGS.forEach(h => { g[h.class] = (g[h.class] || 0) + h.target; }); const clrs = { "US Eq": C.blue, "Intl": C.purple, "Bond": C.cyan, "Alt": C.amber, "REIT": C.green, "MF": C.orange, "Hedge": C.magenta }; return Object.entries(g).sort((a,b)=>b[1]-a[1]).map(([c,v])=>(
                  <div key={c} style={{ marginBottom: 4 }}><div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: C.textDim, marginBottom: 1 }}><span>{c}</span><span style={{ color: clrs[c] }}>{v}%</span></div><div style={{ height: 3, background: C.border, borderRadius: 1 }}><div style={{ height: "100%", width: `${v}%`, background: clrs[c], borderRadius: 1 }} /></div></div>
                )); })()}
              </div>
              <div style={{ padding: "14px 18px", borderRight: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.2, marginBottom: 8 }}>RISK</div>
                {hasYCData && <><Metric label="Composite" value={`${portMetrics.avgComposite.toFixed(0)}/100`} color={portMetrics.avgComposite >= 60 ? C.green : C.amber} /><Metric label="FSM" value={portMetrics.fsmSignal} color={sigColor(portMetrics.fsmSignal)} /></>}
                {aiPortfolio?.riskAssessment && <><Metric label="Risk Level" value={aiPortfolio.riskAssessment.portfolioRiskLevel} color={sigColor(aiPortfolio.riskAssessment.portfolioRiskLevel)} /><div style={{ fontSize: 9, color: C.textMuted, marginTop: 4, lineHeight: 1.5 }}>{aiPortfolio.riskAssessment.drawdownRisk}</div></>}
              </div>
              <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.2, marginBottom: 8 }}>ECONOMY <span style={{ color: C.blue }}>{"\u00B7"} AI</span></div>
                {aiPortfolio?.economicSnapshot ? <>
                  <Metric label="GDP" value={pctRaw(aiPortfolio.economicSnapshot.gdpGrowth)} color={(aiPortfolio.economicSnapshot.gdpGrowth||0)>0?C.green:C.red} />
                  <Metric label="CPI" value={pctRaw(aiPortfolio.economicSnapshot.cpiInflation)} color={(aiPortfolio.economicSnapshot.cpiInflation||0)>3?C.amber:C.green} />
                  <Metric label="Fed Funds" value={pctRaw(aiPortfolio.economicSnapshot.fedFundsRate)} />
                  <Metric label="Unemployment" value={pctRaw(aiPortfolio.economicSnapshot.unemploymentRate)} />
                  <Metric label="Leading" value={aiPortfolio.economicSnapshot.leadingIndicators} color={sigColor(aiPortfolio.economicSnapshot.leadingIndicators)} />
                </> : <div style={{ fontSize: 10, color: C.textMuted }}>Generate report</div>}
              </div>
            </div>
            {aiPortfolio?.quarterlyOutlook && (
              <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: C.purple, letterSpacing: 1.2, marginBottom: 6 }}>{currentStyle.icon} {currentStyle.name.toUpperCase()} OUTLOOK & RECOMMENDATIONS</div>
                <p style={{ fontSize: 12, lineHeight: 1.8, color: C.text, margin: "0 0 10px 0", fontFamily: "'IBM Plex Sans', sans-serif" }}>{aiPortfolio.quarterlyOutlook}</p>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
                  {aiPortfolio.strategicRecommendations?.map((r, i) => (
                    <div key={i} style={{ padding: "8px 12px", background: C.card, borderRadius: 4, borderLeft: `2px solid ${[currentStyle.color, C.blue, C.purple][i]}` }}>
                      <div style={{ fontSize: 9, fontWeight: 700, color: [currentStyle.color, C.blue, C.purple][i] }}>P{r.priority || i+1}</div>
                      <div style={{ fontSize: 10, color: C.text, marginTop: 2, lineHeight: 1.5 }}>{r.recommendation}</div>
                      <div style={{ fontSize: 9, color: C.textMuted, marginTop: 2 }}>{r.rationale}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div style={{ padding: "8px 18px", display: "flex", justifyContent: "space-between", fontSize: 8, color: C.textMuted }}>
              <span>Marline Wealth Management {"\u00B7"} {new Date().getFullYear()}</span>
              <span>{hasYCData ? "YCharts Verified" : "AI Sourced"} {"\u00B7"} {currentStyle.name} Analysis ({toolLog.length} tool calls) {"\u00B7"} Not Investment Advice</span>
            </div>
          </div>
        )}


        {/* ═══ COMPARE ═══ */}
        {tab === "compare" && (
          <div style={{ animation: "fadeUp 0.25s ease" }}>
            {/* Sub-navigation */}
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              {[{ id: "setup", label: "Setup Portfolios" }, { id: "results", label: "Comparison Results" }].map(sv => (
                <button key={sv.id} onClick={() => setCompSubView(sv.id)} style={{
                  padding: "5px 14px", border: `1px solid ${compSubView === sv.id ? C.accent : C.border}`, borderRadius: 3,
                  background: compSubView === sv.id ? `${C.accent}15` : "transparent",
                  color: compSubView === sv.id ? C.accent : C.textDim, fontSize: 10, fontWeight: 600,
                  cursor: "pointer", fontFamily: "inherit", letterSpacing: 0.6
                }}>{sv.label}</button>
              ))}
            </div>

            {/* ── SETUP SUB-VIEW ── */}
            {compSubView === "setup" && (
              <div>
                {/* Header row */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.4 }}>PORTFOLIOS ({compPortfolios.length}/10)</div>
                  <div style={{ display: "flex", gap: 6 }}>
                    {compPortfolios.length < 10 && <Btn onClick={addCompPortfolio} accent={C.green}>+ ADD PORTFOLIO</Btn>}
                    <Btn onClick={loadComparisonData} loading={loading.compData} accent={C.blue}>
                      {loading.compData ? "\u27F3 LOADING..." : `\u27F3 LOAD DATA${hasYCData ? " (YCharts)" : " (AI)"}`}
                    </Btn>
                  </div>
                </div>

                {/* Portfolio entries */}
                {compPortfolios.map((p, i) => {
                  const color = PORTFOLIO_COLORS[i % 10];
                  return (
                    <div key={p.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, borderLeft: `3px solid ${color}`, padding: "12px 14px", marginBottom: 8 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <div style={{ width: 10, height: 10, borderRadius: "50%", background: color }} />
                          <input type="text" value={p.name} onChange={e => updateCompPortfolio(p.id, { name: e.target.value })}
                            placeholder={`Portfolio ${i + 1}`}
                            style={{ fontFamily: "inherit", fontSize: 12, fontWeight: 600, background: "transparent", border: "none", color: C.text, outline: "none", width: 200 }} />
                          <Pill color={color}>{p.holdings?.length || 0} holdings</Pill>
                          {p.totalWeight > 0 && <span style={{ fontSize: 9, color: Math.abs(p.totalWeight - 100) < 2 ? C.green : C.amber }}>{p.totalWeight.toFixed(1)}%</span>}
                        </div>
                        {compPortfolios.length > 1 && (
                          <button onClick={() => removeCompPortfolio(p.id)} style={{ fontSize: 9, background: `${C.red}10`, border: `1px solid ${C.red}30`, borderRadius: 3, color: C.red, padding: "3px 8px", cursor: "pointer", fontFamily: "inherit" }}>{"\u2715"} Remove</button>
                        )}
                      </div>
                      <textarea value={p.rawInput || ""} onChange={e => {
                        const raw = e.target.value;
                        const parsed = parsePortfolioInput(raw);
                        const tw = parsed.reduce((s, h) => s + h.weight, 0);
                        updateCompPortfolio(p.id, { rawInput: raw, holdings: parsed, totalWeight: tw });
                      }} rows={3}
                        placeholder={"Paste from Excel: Ticker, Weight %\nSPY, 8\nQQQ, 7\nAGG, 10\nGLD, 8\nDBMF, 6"}
                        style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10, background: C.bg, color: C.text, border: `1px solid ${C.border}`, borderRadius: 4, padding: 10, width: "100%", boxSizing: "border-box", resize: "vertical" }} />
                    </div>
                  );
                })}

                {/* Benchmarks */}
                <div style={{ marginTop: 14, marginBottom: 10 }}>
                  <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.4, marginBottom: 6 }}>BENCHMARKS</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                    {BENCHMARK_PRESETS.map(b => {
                      const sel = compBenchmarks.includes(b.id);
                      return (
                        <button key={b.id} onClick={() => setCompBenchmarks(prev => sel ? prev.filter(x => x !== b.id) : [...prev, b.id])}
                          style={{ padding: "4px 10px", borderRadius: 3, fontSize: 9, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
                            background: sel ? `${C.accent}20` : "transparent", border: `1px solid ${sel ? C.accent : C.border}`, color: sel ? C.accent : C.textDim }}>
                          {b.ticker} {"\u2014"} {b.name}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Belief Frameworks */}
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.4, marginTop: 18, marginBottom: 8 }}>BELIEF FRAMEWORKS</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
                  <Card title="Investor Beliefs" accent={C.cyan}>
                    {Object.entries(BELIEF_DIMENSIONS).map(([key, dim]) => (
                      <div key={key} style={{ marginBottom: 8 }}>
                        <div style={{ fontSize: 9, color: C.textDim, marginBottom: 3 }}>{dim.label}</div>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>
                          {dim.options.map(opt => {
                            const sel = dim.multi ? (investorBeliefs[key] || []).includes(opt.id) : investorBeliefs[key] === opt.id;
                            return (
                              <button key={opt.id} onClick={() => {
                                if (dim.multi) { const cur = investorBeliefs[key] || []; setInvestorBeliefs(b => ({ ...b, [key]: sel ? cur.filter(x => x !== opt.id) : [...cur, opt.id] })); }
                                else setInvestorBeliefs(b => ({ ...b, [key]: opt.id }));
                              }} style={{ padding: "3px 8px", borderRadius: 3, fontSize: 9, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
                                background: sel ? `${C.cyan}20` : "transparent", border: `1px solid ${sel ? C.cyan : C.border}`, color: sel ? C.cyan : C.textDim }}>
                                {opt.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </Card>
                  <Card title="Management Beliefs" accent={C.purple}>
                    {Object.entries(MGMT_DIMENSIONS).map(([key, dim]) => (
                      <div key={key} style={{ marginBottom: 8 }}>
                        <div style={{ fontSize: 9, color: C.textDim, marginBottom: 3 }}>{dim.label}</div>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>
                          {dim.options.map(opt => {
                            const sel = mgmtBeliefs[key] === opt.id;
                            return (
                              <button key={opt.id} onClick={() => setMgmtBeliefs(b => ({ ...b, [key]: opt.id }))}
                                style={{ padding: "3px 8px", borderRadius: 3, fontSize: 9, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
                                  background: sel ? `${C.purple}20` : "transparent", border: `1px solid ${sel ? C.purple : C.border}`, color: sel ? C.purple : C.textDim }}>
                                {opt.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                    {hasYCData && portMetrics && (
                      <button onClick={() => {
                        const vix = ycEnriched?.["^VIX"]?.price;
                        setMgmtBeliefs({
                          fsmSignal: portMetrics.fsmSignal === "FULLY INVESTED" ? "invested" : portMetrics.fsmSignal === "CAUTION" ? "caution" : "defensive",
                          regimeView: portMetrics.avgComposite >= 65 ? "bullish" : portMetrics.avgComposite >= 45 ? "neutral" : "bearish",
                          dwaStrength: portMetrics.bullishPct >= 0.6 ? "strong" : portMetrics.bullishPct >= 0.4 ? "mixed" : "weak",
                          volatilityRegime: (vix || 18) < 15 ? "low" : (vix || 18) < 25 ? "moderate" : "elevated",
                          cashTrigger: portMetrics.cashTriggers?.anyActive ? "triggered" : "off",
                        });
                      }} style={{ marginTop: 8, padding: "5px 12px", border: `1px solid ${C.green}40`, borderRadius: 3, background: `${C.green}10`, color: C.green, fontSize: 9, fontWeight: 600, cursor: "pointer", fontFamily: "inherit" }}>
                        {"\u27F3"} AUTO-FILL FROM LIVE DATA
                      </button>
                    )}
                  </Card>
                </div>

                {/* Quick Preview Scores */}
                {compScores && compScores.portfolios.length > 0 && (
                  <div style={{ marginTop: 14 }}>
                    <div style={{ fontSize: 9, fontWeight: 700, color: C.green, letterSpacing: 1.4, marginBottom: 6 }}>QUICK SCORES ({currentStyle.name.toUpperCase()} LENS)</div>
                    <div style={{ display: "grid", gridTemplateColumns: `repeat(${Math.min(compScores.portfolios.length, 5)}, 1fr)`, gap: 8 }}>
                      {compScores.portfolios.slice(0, 5).map(p => {
                        const g = compGrade(p.scores?.overall || 0);
                        return (
                          <div key={p.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, borderTop: `2px solid ${p.color}`, padding: 12, textAlign: "center" }}>
                            <div style={{ fontSize: 11, fontWeight: 600, color: p.color, marginBottom: 4 }}>{p.name}</div>
                            <div style={{ fontSize: 32, fontWeight: 700, color: g.color, lineHeight: 1 }}>{g.grade}</div>
                            <div style={{ fontSize: 16, fontWeight: 600, color: C.text }}>{p.scores?.overall || 0}/100</div>
                            <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 6, fontSize: 9 }}>
                              <span style={{ color: C.cyan }}>Inv: {p.scores?.investorTotal || 0}</span>
                              <span style={{ color: C.purple }}>Mgmt: {p.scores?.managementTotal || 0}</span>
                            </div>
                            <div style={{ fontSize: 8, color: C.textMuted, marginTop: 4 }}>{Math.round((p.scores?.metrics?.dataCoverage || 0) * 100)}% data</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Run buttons */}
                <div style={{ display: "flex", justifyContent: "center", marginTop: 20, gap: 10 }}>
                  <Btn onClick={() => { computeCompScores(); setCompSubView("results"); }} accent={C.accent}>{"\u25C6"} VIEW COMPARISON</Btn>
                  <Btn onClick={runComparisonAI} loading={loading.compare} accent={currentStyle.color}>
                    {loading.compare ? `\u27F3 ${progress.message || "ANALYZING..."}` : `\u27F3 RUN ${currentStyle.name.toUpperCase()} AI OPTIMIZATION`}
                  </Btn>
                </div>
              </div>
            )}

            {/* ── RESULTS SUB-VIEW ── */}
            {compSubView === "results" && compScores && compScores.portfolios.length > 0 && (
              <div>
                {/* Winner Banner */}
                {compScores.bestOverall && compScores.portfolios.length > 1 && (
                  <div style={{ background: `linear-gradient(135deg, ${compScores.bestOverall.color}08, ${compScores.bestOverall.color}03)`,
                    border: `1px solid ${compScores.bestOverall.color}30`, borderRadius: 8, padding: "14px 18px", marginBottom: 14, textAlign: "center" }}>
                    <div style={{ fontSize: 8, color: C.textDim, letterSpacing: 1.4 }}>OVERALL RECOMMENDATION ({currentStyle.name.toUpperCase()} LENS)</div>
                    <div style={{ fontSize: 22, fontWeight: 700, color: compScores.bestOverall.color }}>{"\u2605"} {compScores.bestOverall.name}</div>
                    <div style={{ fontSize: 11, color: C.text }}>Score: {compScores.bestOverall.scores?.overall}/100 | Investor: {compScores.bestOverall.scores?.investorTotal} | Management: {compScores.bestOverall.scores?.managementTotal}</div>
                    {compAiResult?.winnerRationale && <div style={{ fontSize: 10, color: C.textDim, marginTop: 6, fontFamily: "'IBM Plex Sans', sans-serif", lineHeight: 1.6, maxWidth: 650, margin: "6px auto 0" }}>{compAiResult.winnerRationale}</div>}
                  </div>
                )}

                {/* Belief Score Cards */}
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.4, marginBottom: 6 }}>BELIEF FRAMEWORK SCORES</div>
                <div style={{ display: "grid", gridTemplateColumns: `repeat(${Math.min(compScores.portfolios.length, 5)}, 1fr)`, gap: 8, marginBottom: 14 }}>
                  {compScores.portfolios.map(p => (
                    <Card key={p.id} title={p.name} accent={p.color}>
                      <div style={{ fontSize: 8, color: C.cyan, fontWeight: 700, marginBottom: 3 }}>INVESTOR</div>
                      {Object.entries(p.scores?.investor || {}).map(([k, v]) => (
                        <div key={k} style={{ display: "flex", justifyContent: "space-between", fontSize: 9, padding: "2px 0", borderBottom: `1px solid ${C.border}` }}>
                          <span style={{ color: C.textDim }}>{k.replace(/([A-Z])/g, " $1").trim()}</span>
                          <span style={{ fontWeight: 600, color: v >= 70 ? C.green : v >= 50 ? C.amber : C.red }}>{v}</span>
                        </div>
                      ))}
                      <div style={{ fontSize: 8, color: C.purple, fontWeight: 700, marginTop: 6, marginBottom: 3 }}>MANAGEMENT</div>
                      {Object.entries(p.scores?.management || {}).map(([k, v]) => (
                        <div key={k} style={{ display: "flex", justifyContent: "space-between", fontSize: 9, padding: "2px 0", borderBottom: `1px solid ${C.border}` }}>
                          <span style={{ color: C.textDim }}>{k.replace(/([A-Z])/g, " $1").trim()}</span>
                          <span style={{ fontWeight: 600, color: v >= 70 ? C.green : v >= 50 ? C.amber : C.red }}>{v}</span>
                        </div>
                      ))}
                      <div style={{ borderTop: `2px solid ${p.color}30`, marginTop: 6, paddingTop: 6, textAlign: "center" }}>
                        <span style={{ fontSize: 20, fontWeight: 700, color: compGrade(p.scores?.overall || 0).color }}>{compGrade(p.scores?.overall || 0).grade}</span>
                        <span style={{ fontSize: 11, color: C.textDim, marginLeft: 6 }}>{p.scores?.overall}/100</span>
                      </div>
                    </Card>
                  ))}
                </div>

                {/* Metrics Table */}
                <div style={{ fontSize: 9, fontWeight: 700, color: C.green, letterSpacing: 1.4, marginBottom: 6 }}>HEAD-TO-HEAD METRICS</div>
                <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, overflow: "auto", marginBottom: 14 }}>
                  <table>
                    <thead><tr>
                      <th style={{ textAlign: "left" }}>Metric</th>
                      {compScores.portfolios.map(p => <th key={p.id} style={{ borderTop: `2px solid ${p.color}` }}>{p.name}</th>)}
                      <th style={{ color: C.amber }}>Winner</th>
                    </tr></thead>
                    <tbody>
                      {[
                        { key: "wtdReturn", label: "1Y Return", pct: true, good: "high" },
                        { key: "wtdSharpe", label: "Sharpe", pct: false, good: "high" },
                        { key: "wtdVol", label: "Volatility", pct: true, good: "low" },
                        { key: "wtdDrawdown", label: "Max DD", pct: true, good: "high" },
                        { key: "wtdYield", label: "Div Yield", pct: true, good: "high" },
                        { key: "wtd1M", label: "1M Return", pct: true, good: "high" },
                        { key: "wtd3M", label: "3M Return", pct: true, good: "high" },
                        { key: "wtd6M", label: "6M Return", pct: true, good: "high" },
                        { key: "wtd3Y", label: "3Y Return", pct: true, good: "high" },
                        { key: "wtd5Y", label: "5Y Return", pct: true, good: "high" },
                      ].map(row => {
                        const w = compScores.winners[row.key];
                        return (
                          <tr key={row.key}>
                            <td style={{ textAlign: "left", fontWeight: 600, color: C.textDim }}>{row.label}</td>
                            {compScores.portfolios.map(p => {
                              const val = p.scores?.metrics?.[row.key];
                              const isW = w?.id === p.id;
                              return (
                                <td key={p.id} style={{
                                  fontWeight: isW ? 700 : 400, fontVariantNumeric: "tabular-nums",
                                  color: isW ? C.green : row.good === "high" ? ((val||0) > 0 ? C.green : C.red) : row.good === "low" ? ((val||0) < 0.15 ? C.green : C.amber) : C.text,
                                  background: isW ? `${C.green}08` : "transparent"
                                }}>
                                  {row.pct ? pctFmt(val) : n(val)}{isW ? " \u2605" : ""}
                                </td>
                              );
                            })}
                            <td>{w && <Pill color={w.color}>{w.name}</Pill>}</td>
                          </tr>
                        );
                      })}
                      <tr style={{ borderTop: `2px solid ${C.accent}` }}>
                        <td style={{ textAlign: "left", fontWeight: 700, color: C.accent, fontSize: 12 }}>OVERALL</td>
                        {compScores.portfolios.map(p => {
                          const g = compGrade(p.scores?.overall || 0);
                          return <td key={p.id} style={{ fontWeight: 700, fontSize: 14 }}><span style={{ color: g.color }}>{g.grade}</span><span style={{ color: C.textDim, fontSize: 10, marginLeft: 4 }}>{p.scores?.overall}</span></td>;
                        })}
                        <td />
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* AI Optimization Results */}
                {compAiResult && (
                  <div>
                    <div style={{ fontSize: 9, fontWeight: 700, color: C.purple, letterSpacing: 1.4, marginBottom: 8 }}>AI OPTIMIZATION ({currentStyle.persona.toUpperCase()})</div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
                      {compAiResult.keyInsight && (
                        <Card title="Key Insight" accent={C.accent} span={2}>
                          <div style={{ fontSize: 12, lineHeight: 1.7, color: C.text, fontFamily: "'IBM Plex Sans', sans-serif" }}>{compAiResult.keyInsight}</div>
                        </Card>
                      )}
                      <Card title="Rankings" accent={C.blue}>
                        {(compAiResult.portfolioRankings || []).map((r, i) => (
                          <div key={i} style={{ padding: "6px 0", borderBottom: `1px solid ${C.border}` }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
                              <span style={{ fontSize: 14, fontWeight: 700, color: i === 0 ? C.green : i === 1 ? C.blue : C.textDim }}>#{r.rank}</span>
                              <span style={{ fontSize: 11, fontWeight: 600, color: C.text }}>{r.name}</span>
                            </div>
                            <div style={{ fontSize: 9, color: C.green }}>+ {(r.strengths || []).join(", ")}</div>
                            <div style={{ fontSize: 9, color: C.red }}>- {(r.weaknesses || []).join(", ")}</div>
                          </div>
                        ))}
                      </Card>
                      <Card title="Swap Recommendations" accent={C.orange}>
                        {(compAiResult.optimizationSwaps || []).map((s, i) => (
                          <div key={i} style={{ padding: "6px 0", borderBottom: `1px solid ${C.border}` }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap", marginBottom: 3 }}>
                              <Pill color={C.red}>SELL {s.sell}</Pill>
                              <span style={{ color: C.textMuted }}>{"\u2192"}</span>
                              <Pill color={C.green}>BUY {s.buy}</Pill>
                              <span style={{ fontSize: 8, color: C.textDim }}>in {s.portfolio}</span>
                            </div>
                            <div style={{ fontSize: 9, color: C.textDim }}>{s.rationale}</div>
                          </div>
                        ))}
                        {(!compAiResult.optimizationSwaps || compAiResult.optimizationSwaps.length === 0) && <div style={{ fontSize: 10, color: C.textDim }}>No swaps recommended</div>}
                      </Card>
                      {compAiResult.blendedRecommendation && (
                        <Card title="Optimal Blend" accent={C.cyan}>
                          <div style={{ fontSize: 11, lineHeight: 1.7, color: C.text, fontFamily: "'IBM Plex Sans', sans-serif" }}>{compAiResult.blendedRecommendation}</div>
                        </Card>
                      )}
                      <Card title="Action Priorities" accent={C.amber}>
                        {(compAiResult.actionPriorities || []).map((a, i) => (
                          <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 6, padding: "4px 0", borderBottom: `1px solid ${C.border}` }}>
                            <span style={{ fontSize: 13, fontWeight: 700, color: a.urgency === "IMMEDIATE" ? C.red : a.urgency === "THIS WEEK" ? C.amber : C.blue }}>P{a.priority}</span>
                            <div>
                              <div style={{ fontSize: 10, color: C.text }}>{a.action}</div>
                              <Pill color={a.urgency === "IMMEDIATE" ? C.red : a.urgency === "THIS WEEK" ? C.amber : C.blue}>{a.urgency}</Pill>
                            </div>
                          </div>
                        ))}
                      </Card>
                      {compAiResult.riskWarnings?.length > 0 && (
                        <Card title="Risk Warnings" accent={C.red}>
                          {compAiResult.riskWarnings.map((w, i) => <div key={i} style={{ fontSize: 10, padding: "3px 0", borderBottom: `1px solid ${C.border}`, color: C.red }}>{"\u26A0"} {w}</div>)}
                        </Card>
                      )}
                    </div>
                  </div>
                )}

                {/* Holdings Detail per Portfolio */}
                <div style={{ fontSize: 9, fontWeight: 700, color: C.accent, letterSpacing: 1.4, marginBottom: 6, marginTop: 14 }}>HOLDINGS DETAIL</div>
                {compScores.portfolios.map(p => {
                  const merged = p.mergedData || ycEnriched || {};
                  return (
                    <div key={p.id} style={{ marginBottom: 14 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                        <div style={{ width: 8, height: 8, borderRadius: "50%", background: p.color }} />
                        <span style={{ fontSize: 11, fontWeight: 600, color: p.color }}>{p.name}</span>
                        <span style={{ fontSize: 9, color: C.textDim }}>{p.holdings.length} holdings</span>
                      </div>
                      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 6, overflow: "auto", maxHeight: 260 }}>
                        <table>
                          <thead><tr>{["Ticker","Wt%","Price","1Y","Vol","Beta","Sharpe","Comp","Signal"].map(h => <th key={h}>{h}</th>)}</tr></thead>
                          <tbody>
                            {p.holdings.map((h, i) => {
                              const d = merged[h.ticker];
                              return (
                                <tr key={i} style={{ background: d?.signal?.includes("BUY") ? `${C.green}06` : d?.signal?.includes("SELL") ? `${C.red}06` : "transparent" }}>
                                  <td style={{ fontWeight: 700, color: p.color }}>{h.ticker}</td>
                                  <td>{(h.weight||0).toFixed(1)}%</td>
                                  <td>{d?.price ? usd(d.price) : "\u2014"}</td>
                                  <td style={{ color: (d?.one_year_return||0) >= 0 ? C.green : C.red }}>{d?.one_year_return != null ? pctFmt(d.one_year_return) : "\u2014"}</td>
                                  <td>{d?.one_year_volatility != null ? pctFmt(d.one_year_volatility) : "\u2014"}</td>
                                  <td>{d?.beta_5_year != null ? n(d.beta_5_year) : "\u2014"}</td>
                                  <td style={{ color: (d?.sharpe||0) > 0.5 ? C.green : C.textDim }}>{d?.sharpe != null ? n(d.sharpe) : "\u2014"}</td>
                                  <td style={{ fontWeight: 700, color: (d?.composite||0) >= 60 ? C.green : (d?.composite||0) <= 40 ? C.red : C.amber }}>{d?.composite || "\u2014"}</td>
                                  <td>{d?.signal ? <Pill color={sigColor(d.signal)}>{d.signal}</Pill> : "\u2014"}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })}

                {/* Bottom action bar */}
                <div style={{ display: "flex", justifyContent: "center", marginTop: 16, gap: 10 }}>
                  <Btn onClick={() => setCompSubView("setup")}>{"\u2190"} EDIT PORTFOLIOS</Btn>
                  <Btn onClick={runComparisonAI} loading={loading.compare} accent={currentStyle.color}>
                    {loading.compare ? `\u27F3 ${progress.message || "ANALYZING..."}` : `\u27F3 RUN ${currentStyle.name.toUpperCase()} AI OPTIMIZATION`}
                  </Btn>
                </div>
              </div>
            )}

            {/* Empty results state */}
            {compSubView === "results" && (!compScores || compScores.portfolios.length === 0) && (
              <div style={{ textAlign: "center", padding: 50, color: C.textMuted }}>
                <div style={{ fontSize: 36, marginBottom: 8, opacity: 0.3 }}>{"\u25A3"}</div>
                <div style={{ fontSize: 12, color: C.textDim }}>Add portfolios and load data to see comparison</div>
                <div style={{ marginTop: 10 }}><Btn onClick={() => setCompSubView("setup")} accent={C.accent}>{"\u2190"} GO TO SETUP</Btn></div>
              </div>
            )}
          </div>
        )}

        {/* â•â•â• EMPTY STATES â•â•â• */}
        {((tab === "daily" && !aiDaily) || (tab === "equity" && !aiEquity && !hasYCData) || (tab === "portfolio" && !aiPortfolio && !hasYCData)) && !isLoading && (
          <div style={{ textAlign: "center", padding: 50, color: C.textMuted }}>
            <div style={{ fontSize: 36, marginBottom: 8, opacity: 0.3 }}>{currentStyle.icon}</div>
            <div style={{ fontSize: 12, color: C.textDim }}>
              {hasYCData ? `YCharts loaded \u2014 click Generate to launch ${currentStyle.persona}` : `Configure YCharts in \u2699, or run AI-only ${currentStyle.name} analysis`}
            </div>
            <div style={{ fontSize: 10, color: C.textMuted, marginTop: 6 }}>
              {currentStyle.persona} will analyze through {currentStyle.name.toLowerCase()} lens with {currentStyle.emphasis.split(",")[0].toLowerCase()} emphasis
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
