# ◇ Marline Wealth Management

**Systematic Portfolio Intelligence Platform**

A comprehensive wealth management system combining an interactive Streamlit dashboard with a React-based AI-powered intelligence platform. Built for data-driven portfolio construction, multi-factor signal analysis, and systematic risk management.

![Python](https://img.shields.io/badge/Python-3.9+-blue) ![Streamlit](https://img.shields.io/badge/Streamlit-1.30+-red) ![React](https://img.shields.io/badge/React-18-61dafb)

---

## System Components

### 1. Streamlit Dashboard (Python)
Interactive web dashboard that reads from the Marline Portfolio System Excel workbook:
- **Portfolio Dashboard** — KPIs, allocation charts, market regime, FSM gauge
- **Asset Analysis** — Holdings table, momentum heatmap, return vs volatility scatter
- **Signal Engine** — Multi-factor composite signals with configurable weights
- **Portfolio Comparison** — Compare up to 5 portfolios with dual belief framework scoring
- **Risk & Rebalancing** — Risk metrics, drift monitoring, allocation band charts
- **Scenario Analysis** — Side-by-side scenario comparison with contribution breakdown

### 2. Intelligence Platform v4 (React/JSX)
AI-powered analysis platform designed to run as a Claude Artifact:
- **Daily Brief** — AI-generated market commentary with YCharts tool access
- **Equity Screener** — Style-aware screening with 12 investor style profiles
- **Portfolio Report** — Agentic AI analysis with systematic signal integration
- **Portfolio Comparison** — Multi-portfolio scoring with belief frameworks and AI optimization
- 8 YCharts tools, web search integration, style-aware scoring engine

### 3. Portfolio System Excel
16-sheet workbook serving as the single source of truth:
- Data Input, Asset Analysis, Dashboard, Signal Engine
- Buffered ETF Strategy, Risk Management, Rebalancing
- Portfolio Construction, Trading Desk, Screening Universe
- Portfolio Forecast, Scenario Compare, YCharts Setup
- Technical Analysis, Investor Lifecycle, Performance Metrics

---

## Quick Start

### Local Development

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/marline-wealth.git
cd marline-wealth

# Install dependencies
pip install -r requirements.txt

# Run the Streamlit app
streamlit run Home.py
```

The app will open at `http://localhost:8501`.

### Deploy to Streamlit Cloud

1. **Push to GitHub** (see instructions below)
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Click **New app**
4. Select your GitHub repo: `YOUR_USERNAME/marline-wealth`
5. Set main file path: `Home.py`
6. Click **Deploy**

The app will be live at `https://YOUR_USERNAME-marline-wealth.streamlit.app`.

---

## GitHub Setup

### First-Time Setup

```bash
cd marline-wealth

# Initialize git
git init
git add .
git commit -m "Initial commit: Marline Wealth Management Platform v4"

# Create GitHub repo (using GitHub CLI)
gh repo create marline-wealth --private --source=. --push

# OR push to an existing repo
git remote add origin https://github.com/YOUR_USERNAME/marline-wealth.git
git branch -M main
git push -u origin main
```

### Making the Repo Private
The portfolio system contains proprietary investment data. To keep it private:
```bash
gh repo edit marline-wealth --visibility private
```

Or set visibility to **Private** in GitHub Settings → Danger Zone.

---

## Project Structure

```
marline-wealth/
├── Home.py                              # Main dashboard (Streamlit entry point)
├── utils.py                             # Shared utilities, data loaders, scoring engine
├── requirements.txt                     # Python dependencies
├── .gitignore
├── .streamlit/
│   └── config.toml                      # Dark theme, Marline branding
├── pages/
│   ├── 1_Asset_Analysis.py             # Holdings metrics & momentum
│   ├── 2_Signal_Engine.py              # Multi-factor signals
│   ├── 3_Portfolio_Comparison.py       # Dual belief framework comparison
│   ├── 4_Risk_Management.py            # Risk metrics & rebalancing
│   └── 5_Scenario_Analysis.py          # Scenario comparison
├── data/
│   ├── Marline_Portfolio_System.xlsx    # 16-sheet portfolio system
│   └── Marline_Sample_YCharts_Export.csv # Sample market data
├── MarlineIntelligencePlatform_v4.jsx   # React AI platform (for Claude Artifacts)
└── README.md
```

---

## Intelligence Platform (React)

The `MarlineIntelligencePlatform_v4.jsx` file is designed to run as a **Claude Artifact** at [claude.ai](https://claude.ai). To use it:

1. Open a conversation with Claude
2. Upload the `.jsx` file or paste its contents
3. Ask Claude to render it as an artifact
4. Configure your YCharts API key (optional) or use AI-powered data fetching

### Features
- **12 Investor Styles** — Balanced, Technical, Fundamental, Contrarian, Defensive, Income, Thematic, Macro, Experimental, Momentum, Quality, Volatility
- **Agentic AI Engine** — Multi-round tool calling with 8 YCharts tools + web search
- **Style-Aware Scoring** — Composite scores adapt to active investor style
- **Portfolio Comparison** — Up to 10 portfolios with belief framework scoring

---

## Data Flow

```
Excel Portfolio System (16 sheets)
    ↓ (read by utils.py)
Streamlit Dashboard (interactive web UI)
    ↓ (shared data model)
Portfolio Comparison Engine (Python scoring)

YCharts API / CSV Export
    ↓ (parsed by React platform)
Intelligence Platform v4 (AI-powered analysis)
    ↓ (style-aware enrichment)
Agentic Reports & Optimization
```

---

## Key Investment Concepts

- **FSM (Factor Signal Model)** — Composite market regime signal
- **DWA (Dorsey Wright)** — Relative strength analysis
- **Buffered ETF Strategy** — VIX-regime-driven allocation to defined outcome products
- **Multi-Factor Signals** — Trend + Technical + Fundamental + DWA composite scoring
- **Dual Belief Framework** — Investor preferences + Management systematic signals
- **Cash Triggers** — MMPR50/MMPR70 defensive positioning rules

---

## License

Proprietary — Marline Wealth Management. Not for redistribution.
