"""
MARLINE WEALTH MANAGEMENT
Systematic Portfolio Intelligence Platform
"""
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from utils import (
    load_data_input, load_asset_analysis, load_dashboard,
    load_risk_management, load_portfolio_construction, load_performance, C
)

st.set_page_config(
    page_title="Marline Wealth Management",
    page_icon="◇",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS
st.markdown("""<style>
    .stApp { background-color: #0A0E14; }
    .metric-card { background: #12171F; border: 1px solid #1E2530; border-radius: 8px;
        padding: 16px; text-align: center; }
    .metric-value { font-size: 28px; font-weight: 700; }
    .metric-label { font-size: 11px; color: #8A94A6; letter-spacing: 1.2px; text-transform: uppercase; }
    .grade-badge { font-size: 36px; font-weight: 700; }
    .signal-pill { display: inline-block; padding: 2px 10px; border-radius: 12px;
        font-size: 11px; font-weight: 600; }
    h1 { letter-spacing: 2px !important; }
    .stSidebar .stMarkdown h2 { color: #00D4AA !important; font-size: 14px; letter-spacing: 1.4px; }
</style>""", unsafe_allow_html=True)

st.sidebar.markdown("## ◇ MARLINE WEALTH")
st.sidebar.markdown("*Systematic Portfolio Intelligence*")
st.sidebar.divider()
st.sidebar.markdown("**Navigation**")
st.sidebar.page_link("Home.py", label="Dashboard", icon="📊")
st.sidebar.page_link("pages/1_Asset_Analysis.py", label="Asset Analysis", icon="🔍")
st.sidebar.page_link("pages/2_Signal_Engine.py", label="Signal Engine", icon="⚡")
st.sidebar.page_link("pages/3_Portfolio_Comparison.py", label="Portfolio Comparison", icon="◧")
st.sidebar.page_link("pages/4_Risk_Management.py", label="Risk & Rebalancing", icon="🛡️")
st.sidebar.page_link("pages/5_Scenario_Analysis.py", label="Scenario Analysis", icon="🔮")
st.sidebar.divider()
st.sidebar.info("**Intelligence Platform v4**\nReact app available as separate download for AI-powered analysis.")

# ═══ HEADER ═══
st.markdown("# ◇ MARLINE WEALTH MANAGEMENT")
st.markdown("*Systematic Portfolio Intelligence Platform v4*")
st.divider()

# Load data
try:
    assumptions, market_data, fsm = load_data_input()
    assets = load_asset_analysis()
    dashboard = load_dashboard()
    risk = load_risk_management()
    allocation = load_portfolio_construction()
    performance = load_performance()
except Exception as e:
    st.error(f"Error loading portfolio system: {e}")
    st.stop()

# ═══ PORTFOLIO OVERVIEW ═══
st.subheader("Portfolio Overview")

col1, col2, col3, col4, col5, col6 = st.columns(6)
port_val = assumptions.get("portfolio_value", 100000)
n_assets = len(assets) if assets is not None else 0
wtd_return = dashboard.get("Weighted Return", 0)
wtd_vol = dashboard.get("Weighted Vol", 0)
sharpe = dashboard.get("Sharpe", 0)

col1.metric("Portfolio Value", f"${port_val:,.0f}")
col2.metric("Assets", n_assets)
col3.metric("Wtd Return", f"{float(wtd_return or 0)*100:.1f}%")
col4.metric("Wtd Vol", f"{float(wtd_vol or 0)*100:.1f}%")
col5.metric("Sharpe Ratio", f"{float(sharpe or 0):.2f}")
col6.metric("VIX Level", f"{market_data.get('vix', 18):.1f}")

# ═══ MARKET REGIME ═══
st.divider()
col_left, col_right = st.columns([1.2, 1])

with col_left:
    st.subheader("Market Regime Indicators")
    regime_data = {
        "Indicator": ["VIX Level", "10Y Treasury", "2Y Treasury", "Yield Curve", "Market Breadth"],
        "Value": [
            f"{market_data.get('vix', 18):.1f}",
            f"{market_data.get('treasury_10y', 0.045)*100:.2f}%",
            f"{market_data.get('treasury_2y', 0.04)*100:.2f}%",
            f"{market_data.get('yield_curve_spread', 0.005)*100:.0f} bps",
            f"{market_data.get('market_breadth', 50):.0f}",
        ],
        "Signal": [
            "🟢 Low" if market_data.get("vix", 18) < 15 else "🟡 Moderate" if market_data.get("vix", 18) < 25 else "🔴 Elevated",
            "Neutral",
            "Neutral",
            "🟢 Positive" if market_data.get("yield_curve_spread", 0) > 0 else "🔴 Inverted",
            "🟡 Neutral" if 40 < market_data.get("market_breadth", 50) < 60 else "🟢 Broad" if market_data.get("market_breadth", 50) >= 60 else "🔴 Narrow",
        ]
    }
    st.dataframe(pd.DataFrame(regime_data), use_container_width=True, hide_index=True)

with col_right:
    st.subheader("FSM Thresholds")
    fsm_vals = [fsm.get("fully_invested", 0.7), fsm.get("caution", 0.5), fsm.get("defensive", 0.3)]
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=market_data.get("market_breadth", 50),
        domain={"x": [0, 1], "y": [0, 1]},
        title={"text": "FSM Score", "font": {"color": "#E8ECF1"}},
        gauge={
            "axis": {"range": [0, 100], "tickcolor": "#8A94A6"},
            "bar": {"color": "#00D4AA"},
            "bgcolor": "#12171F",
            "bordercolor": "#1E2530",
            "steps": [
                {"range": [0, 30], "color": "#FF3D5720"},
                {"range": [30, 50], "color": "#FFB30020"},
                {"range": [50, 70], "color": "#2E8BFF20"},
                {"range": [70, 100], "color": "#00E67620"},
            ],
            "threshold": {"line": {"color": "#00D4AA", "width": 3}, "thickness": 0.8, "value": 50},
        }
    ))
    fig.update_layout(height=260, paper_bgcolor="#0A0E14", font={"color": "#E8ECF1"})
    st.plotly_chart(fig, use_container_width=True)

# ═══ ALLOCATION PIE ═══
st.divider()
col_alloc, col_perf = st.columns(2)

with col_alloc:
    st.subheader("Strategic Allocation")
    if allocation is not None and len(allocation) > 0:
        alloc_clean = allocation[allocation["Current%"].notna() & (allocation["Current%"] > 0)]
        if len(alloc_clean) > 0:
            fig_pie = px.pie(
                alloc_clean, names="Asset Class", values="Current%",
                color_discrete_sequence=["#00D4AA", "#2E8BFF", "#9366FF", "#FF7043", "#00BCD4", "#84CC16", "#FFB300", "#E040FB", "#6366F1", "#14B8A6"],
                hole=0.4,
            )
            fig_pie.update_layout(
                paper_bgcolor="#0A0E14", plot_bgcolor="#12171F",
                font={"color": "#E8ECF1"}, height=350,
                legend={"font": {"size": 10}},
            )
            fig_pie.update_traces(textposition="inside", textinfo="label+percent")
            st.plotly_chart(fig_pie, use_container_width=True)

with col_perf:
    st.subheader("Performance vs Benchmarks")
    if performance is not None and len(performance) > 0:
        st.dataframe(
            performance.style.map(
                lambda v: f"color: {C['green']}" if v == "A" else f"color: {C['blue']}" if v == "B"
                else f"color: {C['amber']}" if v == "C" else f"color: {C['red']}" if v == "D" else "",
                subset=["Grade"] if "Grade" in performance.columns else []
            ),
            use_container_width=True, hide_index=True, height=350,
        )

# ═══ TOP HOLDINGS ═══
st.divider()
st.subheader("Top Holdings by Target Weight")
if assets is not None and len(assets) > 0:
    top = assets.nlargest(10, "Target Wt")[["Ticker", "Class", "Type", "Target Wt", "Ann Return", "Volatility", "Sharpe", "DWA Signal", "Action"]].copy()
    top["Target Wt"] = top["Target Wt"].apply(lambda v: f"{v*100:.1f}%" if pd.notna(v) else "—")
    top["Ann Return"] = top["Ann Return"].apply(lambda v: f"{v*100:.1f}%" if pd.notna(v) else "—")
    top["Volatility"] = top["Volatility"].apply(lambda v: f"{v*100:.1f}%" if pd.notna(v) else "—")
    top["Sharpe"] = top["Sharpe"].apply(lambda v: f"{v:.2f}" if pd.notna(v) else "—")
    st.dataframe(top, use_container_width=True, hide_index=True)

# ═══ RISK QUICK-VIEW ═══
st.divider()
st.subheader("Risk Status")
if risk:
    risk_df = pd.DataFrame(risk)
    def color_status(val):
        if val == "OK":
            return f"color: {C['green']}; font-weight: 700"
        elif val == "WARNING":
            return f"color: {C['amber']}; font-weight: 700"
        elif val == "BREACH":
            return f"color: {C['red']}; font-weight: 700"
        return ""
    st.dataframe(
        risk_df.style.map(color_status, subset=["status"]),
        use_container_width=True, hide_index=True,
    )

st.divider()
st.caption("Marline Wealth Management | Systematic Portfolio Intelligence | Data from Marline Portfolio System Excel")
