"""Scenario Analysis — Compare allocation scenarios with projected returns and risk."""
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from utils import load_scenario_compare, load_performance, C

st.set_page_config(page_title="Scenario Analysis | Marline", page_icon="🔮", layout="wide")
st.markdown("# 🔮 Scenario Analysis")
st.markdown("*Compare allocation scenarios: Current, Conservative, Growth, Max Sharpe, Buffered Tilt*")
st.divider()

scenarios = load_scenario_compare()
performance = load_performance()

if scenarios is None or len(scenarios) == 0:
    st.warning("No scenario data loaded.")
    st.stop()

# Scenario summaries
scenario_names = ["Current", "Conservative", "Growth", "Max Sharpe", "Buffered Tilt"]
scenario_cols = {
    "Current": ("Current Wt%", "Current Contrib"),
    "Conservative": ("Conservative Wt%", "Conservative Contrib"),
    "Growth": ("Growth Wt%", "Growth Contrib"),
    "Max Sharpe": ("Max Sharpe Wt%", "Max Sharpe Contrib"),
    "Buffered Tilt": ("Buffered Tilt Wt%", "Buffered Tilt Contrib"),
}
scenario_colors = [C["accent"], C["blue"], C["green"], C["purple"], C["orange"]]

# Summary metrics
st.subheader("Scenario Summary")
summary_cols = st.columns(5)
for i, (name, (wt_col, contrib_col)) in enumerate(scenario_cols.items()):
    total_return = scenarios[contrib_col].sum() if contrib_col in scenarios.columns else 0
    total_wt = scenarios[wt_col].sum() if wt_col in scenarios.columns else 0
    with summary_cols[i]:
        st.markdown(f"<div style='text-align:center;border-top:3px solid {scenario_colors[i]};padding:10px 0'>"
                    f"<div style='font-size:12px;font-weight:700;color:{scenario_colors[i]}'>{name}</div>"
                    f"<div style='font-size:28px;font-weight:700;color:#E8ECF1'>{total_return*100:.2f}%</div>"
                    f"<div style='font-size:11px;color:#8A94A6'>Expected Return</div>"
                    f"<div style='font-size:11px;color:#5A6478'>{total_wt*100:.1f}% allocated</div>"
                    f"</div>", unsafe_allow_html=True)

# Allocation comparison chart
st.divider()
st.subheader("Allocation Comparison")
fig = go.Figure()
for i, (name, (wt_col, _)) in enumerate(scenario_cols.items()):
    if wt_col in scenarios.columns:
        fig.add_trace(go.Bar(
            name=name, x=scenarios["Asset Class"], y=scenarios[wt_col] * 100,
            marker_color=scenario_colors[i], opacity=0.8,
        ))
fig.update_layout(
    barmode="group", paper_bgcolor="#0A0E14", plot_bgcolor="#12171F",
    font={"color": "#E8ECF1"}, height=400,
    yaxis={"title": "Allocation %", "gridcolor": "#1E2530"},
    legend={"font": {"size": 11}}, margin={"t": 20},
)
st.plotly_chart(fig, use_container_width=True)

# Contribution breakdown
st.divider()
st.subheader("Return Contribution by Asset Class")
fig_contrib = go.Figure()
for i, (name, (_, contrib_col)) in enumerate(scenario_cols.items()):
    if contrib_col in scenarios.columns:
        fig_contrib.add_trace(go.Bar(
            name=name, x=scenarios["Asset Class"], y=scenarios[contrib_col] * 100,
            marker_color=scenario_colors[i], opacity=0.8,
        ))
fig_contrib.update_layout(
    barmode="group", paper_bgcolor="#0A0E14", plot_bgcolor="#12171F",
    font={"color": "#E8ECF1"}, height=350,
    yaxis={"title": "Return Contribution %", "gridcolor": "#1E2530"},
    legend={"font": {"size": 11}}, margin={"t": 20},
)
st.plotly_chart(fig_contrib, use_container_width=True)

# Full data table
st.divider()
st.subheader("Full Scenario Data")
display = scenarios.copy()
for col in display.columns:
    if col != "Asset Class" and display[col].dtype in ["float64", "float32"]:
        display[col] = display[col].apply(lambda v: f"{v*100:.2f}%" if pd.notna(v) else "—")
st.dataframe(display, use_container_width=True, hide_index=True)

# Performance comparison
if performance is not None and len(performance) > 0:
    st.divider()
    st.subheader("Performance vs Benchmarks")
    st.dataframe(performance, use_container_width=True, hide_index=True)
