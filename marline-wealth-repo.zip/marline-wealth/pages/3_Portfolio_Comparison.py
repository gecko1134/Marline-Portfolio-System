"""Portfolio Comparison — Compare up to 5 portfolios with dual belief framework scoring."""
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from utils import (
    load_asset_analysis, load_ycharts_csv, score_portfolio_vs_beliefs, grade_color, C
)

st.set_page_config(page_title="Portfolio Comparison | Marline", page_icon="◧", layout="wide")
st.markdown("# ◧ Portfolio Comparison")
st.markdown("*Compare portfolios through dual belief frameworks — Investor preferences & Management systematic signals*")
st.divider()

PORTFOLIO_COLORS = ["#00D4AA", "#2E8BFF", "#9366FF", "#E040FB", "#FF7043"]

# Load available data
assets = load_asset_analysis()
ycharts = load_ycharts_csv()

# Build lookup from available data
data_lookup = {}
if assets is not None:
    for _, row in assets.iterrows():
        t = row["Ticker"]
        data_lookup[t] = {
            "Return": row.get("Ann Return", 0) or 0,
            "Vol": row.get("Volatility", 0) or 0,
            "Sharpe": row.get("Sharpe", 0) or 0,
            "Beta": row.get("Beta", 0) or 0,
            "MaxDD": row.get("Max DD", 0) or 0,
            "Yield": 0, "1M": row.get("1M Mom", 0) or 0,
            "3M": row.get("3M Mom", 0) or 0,
            "6M": row.get("6M Mom", 0) or 0,
            "Composite": 50,
        }
if ycharts is not None and len(ycharts) > 0:
    for _, row in ycharts.iterrows():
        t = row.get("Ticker", "")
        if t:
            data_lookup[t] = {
                "Return": row.get("1 Year Return", 0) or 0,
                "Vol": row.get("1Y Volatility", 0) or 0,
                "Sharpe": 0, "Beta": row.get("Beta", 0) or 0,
                "MaxDD": row.get("Max Drawdown", 0) or 0,
                "Yield": row.get("Dividend Yield", 0) or 0,
                "1M": row.get("1 Month Return", 0) or 0,
                "3M": row.get("3 Month Return", 0) or 0,
                "6M": row.get("6 Month Return", 0) or 0,
                "Composite": 50,
            }

# ═══ PORTFOLIO INPUT ═══
st.subheader("Enter Portfolios")
n_portfolios = st.slider("Number of portfolios", 2, 5, 2)

portfolios = []
cols = st.columns(n_portfolios)
for i in range(n_portfolios):
    with cols[i]:
        name = st.text_input(f"Name", f"Portfolio {chr(65 + i)}", key=f"pname_{i}")
        st.markdown(f"<div style='width:100%;height:3px;background:{PORTFOLIO_COLORS[i]};border-radius:2px;margin-bottom:8px'></div>", unsafe_allow_html=True)
        raw = st.text_area(
            "Paste holdings (Ticker, Weight%)",
            placeholder="SPY, 25\nQQQ, 15\nAGG, 20\nGLD, 10\nDBMF, 10",
            height=150, key=f"phold_{i}",
        )
        holdings = []
        if raw.strip():
            for line in raw.strip().split("\n"):
                parts = [p.strip() for p in line.replace("\t", ",").split(",") if p.strip()]
                if len(parts) >= 2:
                    ticker = parts[0].upper().strip()
                    try:
                        weight = float(parts[1].replace("%", "").replace("$", ""))
                    except ValueError:
                        continue
                    if ticker and weight > 0:
                        holdings.append({"Ticker": ticker, "Weight": weight})

        tw = sum(h["Weight"] for h in holdings)
        if tw > 0 and tw <= 1.05:
            for h in holdings:
                h["Weight"] *= 100
            tw *= 100

        st.caption(f"{len(holdings)} holdings | {tw:.1f}% total")
        portfolios.append({"name": name, "color": PORTFOLIO_COLORS[i], "holdings": holdings})

# ═══ BELIEF FRAMEWORKS ═══
st.divider()
st.subheader("Belief Frameworks")
bcol1, bcol2 = st.columns(2)

with bcol1:
    st.markdown(f"**🔵 Investor Beliefs**")
    risk_tol = st.select_slider("Risk Tolerance", ["conservative", "moderate", "aggressive"], value="moderate")
    income = st.select_slider("Income Need", ["none", "moderate", "primary"], value="none")
    horizon = st.select_slider("Time Horizon", ["short", "medium", "long"], value="medium")

with bcol2:
    st.markdown(f"**🟣 Management Beliefs**")
    regime = st.select_slider("Regime View", ["bearish", "neutral", "bullish"], value="neutral")
    fsm = st.select_slider("FSM Signal", ["defensive", "caution", "invested"], value="invested")
    vol_regime = st.select_slider("Vol Regime", ["elevated", "moderate", "low"], value="moderate")

investor_beliefs = {"riskTolerance": risk_tol, "incomeNeed": income, "timeHorizon": horizon}
mgmt_beliefs = {"regimeView": regime, "fsmSignal": fsm, "volatilityRegime": vol_regime}

# ═══ RUN COMPARISON ═══
st.divider()
if st.button("🔄 RUN COMPARISON", type="primary", use_container_width=True):
    valid_portfolios = [p for p in portfolios if len(p["holdings"]) > 0]
    if len(valid_portfolios) < 2:
        st.error("Enter at least 2 portfolios with holdings to compare.")
        st.stop()

    results = []
    for p in valid_portfolios:
        rows = []
        for h in p["holdings"]:
            d = data_lookup.get(h["Ticker"], {})
            rows.append({
                "Ticker": h["Ticker"], "Weight": h["Weight"],
                **{k: d.get(k, 0) for k in ["Return", "Vol", "Beta", "MaxDD", "Yield", "Sharpe", "1M", "3M", "6M", "Composite"]}
            })
        df = pd.DataFrame(rows)
        scores = score_portfolio_vs_beliefs(df, investor_beliefs, mgmt_beliefs)
        results.append({**p, "scores": scores, "df": df})

    # ═══ WINNER BANNER ═══
    best = max(results, key=lambda r: r["scores"]["overall"] if r["scores"] else 0)
    st.markdown(f"""
    <div style='text-align:center;padding:20px;background:linear-gradient(135deg,{best["color"]}08,{best["color"]}03);
        border:1px solid {best["color"]}40;border-radius:12px;margin-bottom:20px'>
        <div style='font-size:12px;color:#8A94A6;letter-spacing:2px'>OVERALL RECOMMENDATION</div>
        <div style='font-size:32px;font-weight:700;color:{best["color"]}'>★ {best["name"]}</div>
        <div style='font-size:14px;color:#E8ECF1'>
            Score: {best["scores"]["overall"]}/100 | Grade: {best["scores"]["grade"]} |
            Investor: {best["scores"]["investorTotal"]} | Management: {best["scores"]["managementTotal"]}
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ═══ GRADE CARDS ═══
    st.subheader("Belief Framework Scores")
    grade_cols = st.columns(len(results))
    for i, r in enumerate(results):
        s = r["scores"]
        gc = grade_color(s["grade"])
        with grade_cols[i]:
            st.markdown(f"<div style='text-align:center;border-top:3px solid {r['color']};padding-top:10px'>"
                        f"<div style='font-weight:700;color:{r['color']}'>{r['name']}</div>"
                        f"<div style='font-size:48px;font-weight:700;color:{gc}'>{s['grade']}</div>"
                        f"<div style='font-size:18px;color:#E8ECF1'>{s['overall']}/100</div>"
                        f"</div>", unsafe_allow_html=True)

            st.markdown("**Investor Scores**")
            for k, v in s["investor"].items():
                label = k.replace("Alignment", "").replace("alignment", "")
                bar_color = C["green"] if v >= 70 else C["amber"] if v >= 50 else C["red"]
                st.progress(v / 100, text=f"{label}: {v}")

            st.markdown("**Management Scores**")
            for k, v in s["management"].items():
                label = k.replace("Alignment", "").replace("alignment", "").replace("Score", "")
                st.progress(v / 100, text=f"{label}: {v}")

    # ═══ HEAD-TO-HEAD METRICS ═══
    st.divider()
    st.subheader("Head-to-Head Metrics")
    metric_rows = [
        ("1Y Return", "wtdReturn", True), ("Sharpe", "wtdSharpe", True),
        ("Volatility", "wtdVol", False), ("Max Drawdown", "wtdDrawdown", True),
        ("Dividend Yield", "wtdYield", True), ("1M Momentum", "wtd1M", True),
        ("3M Momentum", "wtd3M", True), ("6M Momentum", "wtd6M", True),
    ]
    table_data = {"Metric": []}
    for r in results:
        table_data[r["name"]] = []
    table_data["Winner"] = []

    for label, key, higher_better in metric_rows:
        table_data["Metric"].append(label)
        vals = []
        for r in results:
            v = r["scores"]["metrics"].get(key, 0)
            vals.append(v)
            if key in ("wtdVol",):
                table_data[r["name"]].append(f"{v*100:.1f}%")
            elif key == "wtdSharpe":
                table_data[r["name"]].append(f"{v:.2f}")
            else:
                table_data[r["name"]].append(f"{v*100:.1f}%")

        best_idx = np.argmax(vals) if higher_better else np.argmin(vals)
        table_data["Winner"].append(results[best_idx]["name"])

    st.dataframe(pd.DataFrame(table_data), use_container_width=True, hide_index=True)

    # ═══ RADAR CHART ═══
    st.divider()
    st.subheader("Score Radar")
    categories = ["Risk Aligned", "Income Aligned", "Horizon Aligned", "Diversification",
                   "Momentum", "Risk-Adj Quality", "DD Resilience", "Regime Fit", "Composite"]
    fig_radar = go.Figure()
    for r in results:
        s = r["scores"]
        vals = list(s["investor"].values()) + list(s["management"].values())
        vals.append(vals[0])  # close the loop
        fig_radar.add_trace(go.Scatterpolar(
            r=vals, theta=categories + [categories[0]],
            fill="toself", fillcolor=f"{r['color']}15",
            line={"color": r["color"], "width": 2},
            name=r["name"],
        ))
    fig_radar.update_layout(
        polar={"radialaxis": {"visible": True, "range": [0, 100], "gridcolor": "#1E2530"},
               "angularaxis": {"gridcolor": "#1E2530"}},
        paper_bgcolor="#0A0E14", font={"color": "#E8ECF1"}, height=450,
        legend={"font": {"size": 11}}, showlegend=True,
    )
    st.plotly_chart(fig_radar, use_container_width=True)

    # ═══ HOLDINGS DETAIL ═══
    st.divider()
    st.subheader("Holdings Detail")
    for r in results:
        with st.expander(f"📋 {r['name']} ({len(r['holdings'])} holdings)", expanded=False):
            st.dataframe(r["df"], use_container_width=True, hide_index=True)

else:
    st.info("Enter portfolio holdings above and click **RUN COMPARISON** to see results.")
