"""Asset Analysis — Holdings metrics, signals, and momentum charts."""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils import load_asset_analysis, load_ycharts_csv, C

st.set_page_config(page_title="Asset Analysis | Marline", page_icon="🔍", layout="wide")
st.markdown("# 🔍 Asset Analysis")
st.markdown("*Security-level metrics, DWA signals, and momentum analysis*")
st.divider()

assets = load_asset_analysis()
ycharts = load_ycharts_csv()

if assets is None or len(assets) == 0:
    st.warning("No asset data loaded from portfolio system.")
    st.stop()

# Filter controls
col1, col2, col3 = st.columns(3)
with col1:
    classes = ["All"] + sorted(assets["Class"].dropna().unique().tolist())
    sel_class = st.selectbox("Asset Class", classes)
with col2:
    signals = ["All"] + sorted(assets["DWA Signal"].dropna().unique().tolist())
    sel_signal = st.selectbox("Signal Filter", signals)
with col3:
    sort_by = st.selectbox("Sort By", ["Target Wt", "Ann Return", "Sharpe", "Volatility", "Beta", "1M Mom", "DWA Score"])

filtered = assets.copy()
if sel_class != "All":
    filtered = filtered[filtered["Class"] == sel_class]
if sel_signal != "All":
    filtered = filtered[filtered["DWA Signal"] == sel_signal]
filtered = filtered.sort_values(sort_by, ascending=(sort_by == "Volatility"))

# Signal distribution
st.subheader("Signal Distribution")
if "DWA Signal" in filtered.columns:
    signal_counts = filtered["DWA Signal"].value_counts()
    col_s1, col_s2, col_s3, col_s4, col_s5 = st.columns(5)
    for col, sig, color in [
        (col_s1, "STRONG BUY", C["green"]), (col_s2, "BUY", C["cyan"]),
        (col_s3, "HOLD", C["amber"]), (col_s4, "SELL", C["orange"]), (col_s5, "STRONG SELL", C["red"])
    ]:
        col.metric(sig, signal_counts.get(sig, 0))

st.divider()

# Holdings table
st.subheader(f"Holdings ({len(filtered)} assets)")
display_cols = ["Ticker", "Class", "Type", "Ann Return", "Volatility", "Sharpe", "Beta", "Max DD",
                "1M Mom", "3M Mom", "6M Mom", "DWA Score", "DWA Signal", "Target Wt", "Current Wt", "Action"]
display = filtered[[c for c in display_cols if c in filtered.columns]].copy()

def format_pct(val):
    return f"{val*100:.1f}%" if pd.notna(val) else "—"

for col in ["Ann Return", "Volatility", "Max DD", "1M Mom", "3M Mom", "6M Mom", "Target Wt", "Current Wt"]:
    if col in display.columns:
        display[col] = display[col].apply(format_pct)

if "Sharpe" in display.columns:
    display["Sharpe"] = display["Sharpe"].apply(lambda v: f"{v:.2f}" if pd.notna(v) else "—")
if "Beta" in display.columns:
    display["Beta"] = display["Beta"].apply(lambda v: f"{v:.2f}" if pd.notna(v) else "—")
if "DWA Score" in display.columns:
    display["DWA Score"] = display["DWA Score"].apply(lambda v: f"{v:.0f}" if pd.notna(v) else "—")

st.dataframe(display, use_container_width=True, hide_index=True, height=500)

# Charts
st.divider()
col_chart1, col_chart2 = st.columns(2)

with col_chart1:
    st.subheader("Return vs Volatility")
    chart_data = filtered[["Ticker", "Ann Return", "Volatility", "Target Wt"]].dropna()
    if len(chart_data) > 0:
        fig = px.scatter(
            chart_data, x="Volatility", y="Ann Return", text="Ticker",
            size="Target Wt", size_max=25,
            color_discrete_sequence=[C["accent"]],
        )
        fig.update_traces(textposition="top center", textfont_size=9)
        fig.update_layout(
            paper_bgcolor="#0A0E14", plot_bgcolor="#12171F",
            font={"color": "#E8ECF1"}, height=400,
            xaxis={"title": "Volatility", "gridcolor": "#1E2530"},
            yaxis={"title": "Annualized Return", "gridcolor": "#1E2530"},
        )
        st.plotly_chart(fig, use_container_width=True)

with col_chart2:
    st.subheader("Momentum Heatmap")
    mom_data = filtered[["Ticker", "1M Mom", "3M Mom", "6M Mom", "12M Mom"]].set_index("Ticker").dropna()
    if len(mom_data) > 0:
        fig_heat = go.Figure(data=go.Heatmap(
            z=mom_data.values * 100,
            x=["1M", "3M", "6M", "12M"],
            y=mom_data.index.tolist(),
            colorscale=[[0, C["red"]], [0.5, "#1E2530"], [1, C["green"]]],
            zmid=0, text=[[f"{v*100:.1f}%" for v in row] for row in mom_data.values],
            texttemplate="%{text}", textfont={"size": 9},
        ))
        fig_heat.update_layout(
            paper_bgcolor="#0A0E14", plot_bgcolor="#12171F",
            font={"color": "#E8ECF1"}, height=400,
            yaxis={"autorange": "reversed"},
        )
        st.plotly_chart(fig_heat, use_container_width=True)

# YCharts supplement
if ycharts is not None and len(ycharts) > 0:
    st.divider()
    with st.expander("📈 YCharts Live Data (Sample Export)", expanded=False):
        st.dataframe(ycharts, use_container_width=True, hide_index=True)
