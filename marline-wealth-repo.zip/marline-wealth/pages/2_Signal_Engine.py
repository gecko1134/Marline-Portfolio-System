"""Signal Engine — Multi-factor composite signal generation and analysis."""
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from utils import load_signal_engine, load_asset_analysis, C

st.set_page_config(page_title="Signal Engine | Marline", page_icon="⚡", layout="wide")
st.markdown("# ⚡ Signal Engine")
st.markdown("*Multi-factor composite signals: Trend + Technical + Fundamental + DWA*")
st.divider()

weights, signals = load_signal_engine()
assets = load_asset_analysis()

# Factor Weights
st.subheader("Factor Weights")
col1, col2, col3, col4 = st.columns(4)
w_trend = col1.number_input("Trend Weight", 0, 100, int(weights.get("Trend", 50)), step=5)
w_tech = col2.number_input("Technical Weight", 0, 100, int(weights.get("Technical", 0)), step=5)
w_fund = col3.number_input("Fundamental Weight", 0, 100, int(weights.get("Fundamental", 0)), step=5)
w_dwa = col4.number_input("DWA Weight", 0, 100, int(weights.get("DWA", 0)), step=5)
total_w = w_trend + w_tech + w_fund + w_dwa
if total_w != 100:
    st.warning(f"Weights sum to {total_w}% — should be 100%")

# Weight visualization
fig_w = go.Figure(data=[go.Bar(
    x=["Trend", "Technical", "Fundamental", "DWA"],
    y=[w_trend, w_tech, w_fund, w_dwa],
    marker_color=[C["accent"], C["blue"], C["purple"], C["orange"]],
    text=[f"{v}%" for v in [w_trend, w_tech, w_fund, w_dwa]],
    textposition="outside",
)])
fig_w.update_layout(
    paper_bgcolor="#0A0E14", plot_bgcolor="#12171F",
    font={"color": "#E8ECF1"}, height=200, yaxis_range=[0, 100],
    margin={"t": 20, "b": 30}, yaxis={"gridcolor": "#1E2530"},
)
st.plotly_chart(fig_w, use_container_width=True)

# Signal Thresholds
st.divider()
st.subheader("Signal Thresholds")
threshold_data = {
    "Signal": ["STRONG BUY", "BUY", "HOLD", "SELL", "STRONG SELL"],
    "Composite Score": ["≥70", "≥60", "45–59", "<45", "<35"],
    "Factor Rule": ["3+ factors ≥60", "2+ factors ≥60", "Mixed", "≤1 factor ≥60", "0–1 factors"],
    "Action": ["Overweight aggressively", "Add / Initiate", "Maintain weight", "Trim / Reduce", "Exit / Replace"],
    "Color": [C["green"], C["cyan"], C["amber"], C["orange"], C["red"]],
}
st.dataframe(
    pd.DataFrame(threshold_data)[["Signal", "Composite Score", "Factor Rule", "Action"]],
    use_container_width=True, hide_index=True,
)

# Composite Signals Table
st.divider()
st.subheader("Composite Signals by Ticker")
if signals:
    sig_df = pd.DataFrame(signals)
    st.dataframe(sig_df, use_container_width=True, hide_index=True, height=500)
elif assets is not None and len(assets) > 0:
    # Build signals from asset analysis data if signal engine sheet is sparse
    sig_data = assets[["Ticker", "DWA Score", "DWA Signal", "Ann Return", "1M Mom", "3M Mom", "6M Mom"]].copy()
    sig_data["Trend Score"] = ((sig_data["1M Mom"].fillna(0) * 0.4 + sig_data["3M Mom"].fillna(0) * 0.3 + sig_data["6M Mom"].fillna(0) * 0.3) * 100 + 50).clip(0, 100).round(0)
    sig_data = sig_data.rename(columns={"DWA Score": "DWA", "DWA Signal": "Signal"})
    st.dataframe(sig_data, use_container_width=True, hide_index=True, height=500)

# Signal Distribution Chart
st.divider()
st.subheader("Signal Distribution")
if assets is not None and "DWA Signal" in assets.columns:
    counts = assets["DWA Signal"].value_counts().reindex(["STRONG BUY", "BUY", "HOLD", "SELL", "STRONG SELL"]).fillna(0)
    fig_dist = go.Figure(data=[go.Bar(
        x=counts.index, y=counts.values,
        marker_color=[C["green"], C["cyan"], C["amber"], C["orange"], C["red"]],
        text=counts.values.astype(int), textposition="outside",
    )])
    fig_dist.update_layout(
        paper_bgcolor="#0A0E14", plot_bgcolor="#12171F",
        font={"color": "#E8ECF1"}, height=300,
        margin={"t": 20}, yaxis={"gridcolor": "#1E2530"},
    )
    st.plotly_chart(fig_dist, use_container_width=True)
