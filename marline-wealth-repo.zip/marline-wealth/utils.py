"""Marline Wealth Management — Shared utilities for Streamlit app."""
import pandas as pd
import numpy as np
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
EXCEL_PATH = DATA_DIR / "Marline_Portfolio_System.xlsx"
YCHARTS_PATH = DATA_DIR / "Marline_Sample_YCharts_Export.csv"

# Marline color palette
C = {
    "bg": "#0A0E14", "card": "#12171F", "border": "#1E2530",
    "text": "#E8ECF1", "dim": "#8A94A6", "muted": "#5A6478",
    "accent": "#00D4AA", "green": "#00E676", "red": "#FF3D57",
    "amber": "#FFB300", "blue": "#2E8BFF", "cyan": "#00BCD4",
    "purple": "#9366FF", "orange": "#FF7043",
}


def load_excel(sheet_name=None):
    """Load sheet(s) from the portfolio system Excel."""
    if sheet_name:
        return pd.read_excel(EXCEL_PATH, sheet_name=sheet_name, header=None)
    return pd.read_excel(EXCEL_PATH, sheet_name=None, header=None)


def load_data_input():
    """Parse the Data Input sheet into structured assumptions."""
    df = load_excel("Data Input")
    assumptions = {}
    market_data = {}
    fsm = {}
    for i, row in df.iterrows():
        label = str(row.iloc[0]).strip() if pd.notna(row.iloc[0]) else ""
        val = row.iloc[1] if len(row) > 1 and pd.notna(row.iloc[1]) else None
        if not label:
            continue
        if label == "Risk-Free Rate":
            assumptions["risk_free_rate"] = float(val) if val else 0.045
        elif label == "Benchmark Return":
            assumptions["benchmark_return"] = float(val) if val else 0.10
        elif label == "Benchmark Vol":
            assumptions["benchmark_vol"] = float(val) if val else 0.16
        elif label == "Portfolio Value":
            assumptions["portfolio_value"] = float(val) if val else 100000
        elif label == "Rebalance Band":
            assumptions["rebalance_band"] = float(val) if val else 0.05
        elif label == "Max Single Asset":
            assumptions["max_single_asset"] = float(val) if val else 0.30
        elif label == "VIX Level":
            market_data["vix"] = float(val) if val else 18.0
        elif "10-Year Treasury" in label:
            market_data["treasury_10y"] = float(val) if val else 0.045
        elif "2-Year Treasury" in label:
            market_data["treasury_2y"] = float(val) if val else 0.04
        elif "Yield Curve" in label:
            market_data["yield_curve_spread"] = float(val) if val else 0.005
        elif "Market Breadth" in label:
            market_data["market_breadth"] = float(val) if val else 50
        elif "Fully Invested" in label:
            fsm["fully_invested"] = float(val) if val else 0.70
        elif "Caution" in label:
            fsm["caution"] = float(val) if val else 0.50
        elif "Defensive" in label:
            fsm["defensive"] = float(val) if val else 0.30
    return assumptions, market_data, fsm


def load_asset_analysis():
    """Parse the Asset Analysis sheet into holdings DataFrame."""
    df = load_excel("Asset Analysis")
    # Header row is row 2 (0-indexed)
    headers = df.iloc[2].tolist()
    data = df.iloc[3:].copy()
    data.columns = headers
    data = data[data["Ticker"].notna() & ~data["Ticker"].isin(["TOTALS", "AVERAGES", "SIGNAL COUNTS"])]
    data = data.reset_index(drop=True)
    # Convert numeric columns
    num_cols = ["Ann Return", "Volatility", "Sharpe", "Sortino", "Beta", "Max DD",
                "1M Mom", "3M Mom", "6M Mom", "12M Mom", "DWA Score", "RS Rank",
                "Target Wt", "Current Wt", "Drift"]
    for col in num_cols:
        if col in data.columns:
            data[col] = pd.to_numeric(data[col], errors="coerce")
    return data


def load_dashboard():
    """Parse the Dashboard sheet."""
    df = load_excel("Dashboard")
    metrics = {}
    headers_row = df.iloc[3].tolist() if len(df) > 3 else []
    values_row = df.iloc[4].tolist() if len(df) > 4 else []
    for h, v in zip(headers_row, values_row):
        if pd.notna(h) and pd.notna(v):
            metrics[str(h).strip()] = v
    return metrics


def load_signal_engine():
    """Parse the Signal Engine sheet."""
    df = load_excel("Signal Engine")
    # Weights from row 3
    weights = {}
    row3 = df.iloc[3].tolist()
    for i in range(0, len(row3) - 1, 2):
        if pd.notna(row3[i]):
            weights[str(row3[i]).strip()] = float(row3[i + 1]) if pd.notna(row3[i + 1]) else 0
    # Signals from row 14 onward
    sig_header = df.iloc[14].tolist() if len(df) > 14 else []
    signals = []
    for i in range(15, len(df)):
        row = df.iloc[i].tolist()
        if pd.notna(row[0]) and str(row[0]).strip() not in ["", "TOTALS", "AVERAGES"]:
            entry = {}
            for j, h in enumerate(sig_header):
                if pd.notna(h) and j < len(row):
                    entry[str(h).strip()] = row[j]
            signals.append(entry)
    return weights, signals


def load_risk_management():
    """Parse Risk Management sheet."""
    df = load_excel("Risk Management")
    metrics = []
    for i in range(4, len(df)):
        row = df.iloc[i].tolist()
        if pd.notna(row[0]) and str(row[0]).strip():
            metrics.append({
                "metric": str(row[0]).strip(),
                "value": row[1] if len(row) > 1 else None,
                "threshold": row[2] if len(row) > 2 else None,
                "status": str(row[3]).strip() if len(row) > 3 and pd.notna(row[3]) else "N/A"
            })
    return metrics


def load_rebalancing():
    """Parse Rebalancing sheet."""
    df = load_excel("Rebalancing")
    headers = df.iloc[2].tolist()
    data = df.iloc[3:].copy()
    data.columns = headers
    data = data[data["Ticker"].notna() & ~data["Ticker"].isin(["TOTALS", "AVERAGES"])].reset_index(drop=True)
    num_cols = ["Target%", "Current%", "Drift", "Shares", "$ Amount"]
    for col in num_cols:
        if col in data.columns:
            data[col] = pd.to_numeric(data[col], errors="coerce")
    return data


def load_portfolio_construction():
    """Parse Portfolio Construction sheet."""
    df = load_excel("Portfolio Construction")
    headers = df.iloc[2].tolist()
    data = df.iloc[3:].copy()
    data.columns = headers
    data = data[data["Asset Class"].notna()].reset_index(drop=True)
    for col in ["Min%", "Target%", "Max%", "Current%", "Deviation"]:
        if col in data.columns:
            data[col] = pd.to_numeric(data[col], errors="coerce")
    return data


def load_buffered_etf():
    """Parse Buffered ETF Strategy sheet."""
    df = load_excel("Buffered ETF Strategy")
    regime_data = []
    for i in range(4, min(len(df), 15)):
        row = df.iloc[i].tolist()
        if pd.notna(row[0]) and str(row[0]).strip():
            regime_data.append({
                "component": str(row[0]).strip(),
                "input": row[1] if len(row) > 1 else None,
                "score": row[2] if len(row) > 2 else None,
                "max": row[3] if len(row) > 3 else None,
                "logic": str(row[4]).strip() if len(row) > 4 and pd.notna(row[4]) else "",
            })
    return regime_data


def load_scenario_compare():
    """Parse Scenario Compare sheet."""
    df = load_excel("Scenario Compare")
    headers = df.iloc[3].tolist()
    data = df.iloc[4:].copy()
    data.columns = headers
    data = data[data["Asset Class"].notna()].reset_index(drop=True)
    for col in data.columns:
        if col != "Asset Class":
            data[col] = pd.to_numeric(data[col], errors="coerce")
    return data


def load_performance():
    """Parse Performance Metrics sheet."""
    df = load_excel("Performance Metrics")
    headers = df.iloc[3].tolist()
    data = df.iloc[4:].copy()
    data.columns = headers
    data = data[data["Metric"].notna()].reset_index(drop=True)
    return data


def load_ycharts_csv():
    """Load the sample YCharts export CSV."""
    if YCHARTS_PATH.exists():
        return pd.read_csv(YCHARTS_PATH)
    return pd.DataFrame()


# — Scoring engine (Python port of React logic) —

def score_portfolio_vs_beliefs(holdings_df, investor_beliefs, mgmt_beliefs):
    """Score a portfolio against investor and management belief frameworks.
    holdings_df: DataFrame with columns [Ticker, Weight, Return, Vol, Beta, MaxDD, Yield, Sharpe, 1M, 3M, 6M, 3Y, 5Y, Composite]
    """
    if holdings_df is None or len(holdings_df) == 0:
        return None

    total_w = holdings_df["Weight"].sum() or 100
    w = holdings_df["Weight"] / total_w

    metrics = {
        "wtdReturn": (holdings_df.get("Return", 0) * w).sum(),
        "wtdVol": (holdings_df.get("Vol", 0) * w).sum(),
        "wtdBeta": (holdings_df.get("Beta", 0) * w).sum(),
        "wtdDrawdown": (holdings_df.get("MaxDD", 0) * w).sum(),
        "wtdYield": (holdings_df.get("Yield", 0) * w).sum(),
        "wtdSharpe": (holdings_df.get("Sharpe", 0) * w).sum(),
        "wtd1M": (holdings_df.get("1M", 0) * w).sum(),
        "wtd3M": (holdings_df.get("3M", 0) * w).sum(),
        "wtd6M": (holdings_df.get("6M", 0) * w).sum(),
        "avgComposite": holdings_df.get("Composite", pd.Series([50])).mean(),
    }

    clamp = lambda v, lo, hi: min(max(v, lo), hi)

    # Investor scores
    investor = {}
    rp = investor_beliefs.get("riskTolerance", "moderate")
    if rp == "conservative":
        investor["riskAlignment"] = round(clamp(100 - abs(metrics["wtdVol"] * 100) * 3 - abs(metrics["wtdDrawdown"] * 100) * 2, 0, 100))
    elif rp == "aggressive":
        investor["riskAlignment"] = round(clamp(metrics["wtdReturn"] * 200 + 40, 0, 100))
    else:
        investor["riskAlignment"] = round(clamp(70 + metrics["wtdSharpe"] * 20 - abs(metrics["wtdDrawdown"] * 50), 0, 100))

    ip = investor_beliefs.get("incomeNeed", "none")
    if ip == "primary":
        investor["incomeAlignment"] = round(clamp(metrics["wtdYield"] * 100 * 8, 0, 100))
    elif ip == "moderate":
        investor["incomeAlignment"] = round(clamp(50 + metrics["wtdYield"] * 100 * 5, 0, 100))
    else:
        investor["incomeAlignment"] = 70

    hp = investor_beliefs.get("timeHorizon", "medium")
    if hp == "long":
        investor["horizonAlignment"] = round(clamp(50 + metrics["wtdReturn"] * 150, 0, 100))
    elif hp == "short":
        investor["horizonAlignment"] = round(clamp(80 - metrics["wtdVol"] * 100 * 2.5, 0, 100))
    else:
        investor["horizonAlignment"] = round(clamp(60 + metrics["wtdSharpe"] * 25, 0, 100))

    max_wt = holdings_df["Weight"].max() if len(holdings_df) > 0 else 0
    investor["diversification"] = round(clamp(100 - (max_wt - 10) * 2 + min(len(holdings_df), 20) * 2, 0, 100))

    # Management scores
    management = {}
    management["momentumAlignment"] = round(clamp(50 + metrics["wtd1M"] * 500 + metrics["wtd3M"] * 200 + metrics["wtd6M"] * 100, 0, 100))
    management["riskAdjQuality"] = round(clamp(metrics["wtdSharpe"] * 40 + 40, 0, 100))
    management["drawdownResilience"] = round(clamp(100 + metrics["wtdDrawdown"] * 200, 0, 100))

    rv = mgmt_beliefs.get("regimeView", "neutral")
    if rv == "bullish":
        management["regimeFit"] = round(clamp(50 + metrics["wtdBeta"] * 30 + metrics["wtdReturn"] * 100, 0, 100))
    elif rv == "bearish":
        management["regimeFit"] = round(clamp(80 - metrics["wtdBeta"] * 50 + metrics["wtdYield"] * 300, 0, 100))
    else:
        management["regimeFit"] = round(clamp(60 + metrics["wtdSharpe"] * 25, 0, 100))

    management["compositeScore"] = round(clamp(metrics["avgComposite"], 0, 100))

    inv_total = round(np.mean(list(investor.values())))
    mgmt_total = round(np.mean(list(management.values())))
    overall = round(inv_total * 0.5 + mgmt_total * 0.5)

    return {
        "investor": investor, "management": management,
        "investorTotal": inv_total, "managementTotal": mgmt_total,
        "overall": overall, "metrics": metrics,
        "grade": "A" if overall >= 85 else "B" if overall >= 70 else "C" if overall >= 55 else "D",
    }


def grade_color(grade):
    return {"A": C["green"], "B": C["blue"], "C": C["amber"], "D": C["red"]}.get(grade, C["dim"])
